using System.Reflection;
using Ipc.Application.Contracts;
using Ipc.Application.ParcelFlow;
using Ipc.Application.Sportmaster;
using Ipc.Assembly;
using Ipc.Platform;

// Audit-only orchestration: use the unmodified repository's HTTP peer and RCS factory.
// The only injected behavior is a held left camera capture to deterministically
// exercise legal independent-position scheduling; no production endpoints are used.
var repo = "/workspace/scratch/56081ee5bcf2/importer-pc-audit03";
var root = Path.Combine("/workspace/scratch/56081ee5bcf2/audit03-work/root/rcs-order-probe", "run-" + Wire.Id());
Directory.CreateDirectory(root);
var verification = Assembly.Load("Ipc.Application.Verification");
var rcs = verification.GetType("SportmasterRcs")!;
var peerType = rcs.GetNestedType("Peer", BindingFlags.NonPublic)!;
await using var peer = (IAsyncDisposable)Activator.CreateInstance(peerType, true)!;
var endpoint = (string)peerType.GetProperty("Endpoint")!.GetValue(peer)!;
var binding = (CapabilityBinding)rcs.GetMethod("Binding", BindingFlags.Static | BindingFlags.NonPublic)!.Invoke(null, [endpoint])!;
var config = Wire.Decode<ParcelConfiguration>(File.ReadAllText(Path.Combine(repo, "config/sportmaster/business.json"))) with { Wcs = binding, TimeoutMs = 5000 };
CapabilityBinding Camera(string position) => new("camera", "reference-camera", "1.0.0", "audit.camera." + position,
    config.Topology!.Readers.Single(x => x.DeviceId.EndsWith("." + position, StringComparison.Ordinal)).DeviceId, "PARCEL-REFERENCE-v1", []);
var leftCamera = Camera("left"); var rightCamera = Camera("right");
config = config with { Images = new(leftCamera, null), CapabilityInstances = [binding, config.MaintenanceLogin!, leftCamera, rightCamera],
    Topology = config.Topology! with { Positions = [config.Topology.Positions[0], config.Topology.Positions[1] with { CameraInstanceId = rightCamera.InstanceId }] } };
var configDir = Path.Combine(root, "config"); Directory.CreateDirectory(configDir);
ExtensionStore.AtomicWrite(Path.Combine(configDir, "business.json"), config);
var launch = new BusinessLaunch(configDir, Path.Combine(root, "data"), null, null);
var originalFactory = (IParcelCapabilityFactory)Activator.CreateInstance(rcs.GetNestedType("Factory", BindingFlags.NonPublic)!, new ParcelCapabilityFactory(launch))!;
var factory = new HoldFactory(originalFactory);
await using var app = new ParcelRuntime(launch, new SportmasterFlow(), factory);
await app.StartAsync(default);
async Task<ParcelSnapshot> Wait(Func<ParcelSnapshot, bool> ready)
{
    for (int i = 0; i < 300; i++) { var s = await app.SnapshotAsync(); if (ready(s)) return s; await Task.Delay(10); }
    throw new Exception("Unexpected probe timeout: " + Wire.Encode(await app.SnapshotAsync()));
}
try
{
    if (!app.EmitReferenceAt("left", "audit-left-first", "SYNTH-0001", "audit-left-event")) throw new Exception("Left not queued");
    await factory.Entered.Task.WaitAsync(TimeSpan.FromSeconds(2));
    if (!app.EmitReferenceAt("right", "audit-right-second", "SYNTH-0001", "audit-right-event")) throw new Exception("Right not queued");
    var rightFirst = await Wait(x => x.Operations.Any(o => o.PositionId == "right" && o.State == ParcelState.SlotResolved));
    Console.WriteLine("Right completed while left capture pending: " + Wire.Encode(rightFirst.Operations.Select(o => new { o.PositionId, o.State, WireId = o.Wcs?.Request.IntegrationRequest?.RequestId })));
    factory.Release.TrySetResult();
    var final = await Wait(x => x.Operations.Any(o => o.PositionId == "left" && o.State is ParcelState.Blocked or ParcelState.SlotResolved));
    var left = final.Operations.Single(o => o.PositionId == "left");
    var right = final.Operations.Single(o => o.PositionId == "right");
    var result = new { SourceSha = "ec698bd4e11d06c13c097c77f90cc5ce145ab3ea", Expected = "Both independently admitted positions resolve a slot with distinct original request IDs", Actual = final,
        DefectReproduced = left.State == ParcelState.Blocked && left.Wcs is null && left.Reason!.Contains("must exceed durable original allocation") && right.State == ParcelState.SlotResolved,
        Scope = "Simulation + actual RCS HTTP client and repository peer + optional acquisition; held camera only; no hardware" };
    File.WriteAllText(Path.Combine(root, "result.json"), Wire.Encode(result));
    Console.WriteLine("Result=" + Path.Combine(root, "result.json"));
    Console.WriteLine("Left=" + left.State + "; WCS intent=" + (left.Wcs is null ? "none" : "present") + "; Reason=" + left.Reason);
    Console.WriteLine(result.DefectReproduced ? "CONFIRMED_DEFECT: valid delayed left work blocked by unrelated right allocation" : "NOT_REPRODUCED");
    if (!result.DefectReproduced) Environment.ExitCode = 2;
}
finally { factory.Release.TrySetResult(); }

sealed class HoldFactory(IParcelCapabilityFactory inner) : IParcelCapabilityFactory
{
    public TaskCompletionSource Entered { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
    public TaskCompletionSource Release { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
    public ParcelConfiguration Normalize(ParcelConfiguration c) => inner.Normalize(c);
    public void Validate(ParcelConfiguration c) => inner.Validate(c);
    public CapabilityRequirements Requirements(CapabilityBinding b) => inner.Requirements(b);
    public ParcelPorts Create(ParcelConfiguration c)
    {
        var p = inner.Create(c); var held = new HeldCamera(p.Camera!, this);
        return p with { Camera = held, Devices = p.Devices!.ToDictionary(x => x.Key, x => x.Value.InstanceId == held.InstanceId ? held : x.Value) };
    }
    public ValueTask DisposeAsync() => inner.DisposeAsync();
}
sealed class HeldCamera(IImageCamera inner, HoldFactory owner) : IImageCamera
{
    public string InstanceId => inner.InstanceId;
    public Task StartAsync(CancellationToken t) => inner.StartAsync(t);
    public Task<CapabilityHealth> HealthAsync(CancellationToken t) => inner.HealthAsync(t);
    public Task ReconnectAsync(CancellationToken t) => inner.ReconnectAsync(t);
    public async Task<StageReply> CaptureAsync(FrozenRequest r, CancellationToken t) { owner.Entered.TrySetResult(); await owner.Release.Task.WaitAsync(t); return await inner.CaptureAsync(r, t); }
    public Task<StageReply?> QueryAsync(FrozenRequest r, CancellationToken t) => inner.QueryAsync(r, t);
    public Task StopAsync(CancellationToken t) => inner.StopAsync(t);
    public ValueTask DisposeAsync() => inner.DisposeAsync();
}
