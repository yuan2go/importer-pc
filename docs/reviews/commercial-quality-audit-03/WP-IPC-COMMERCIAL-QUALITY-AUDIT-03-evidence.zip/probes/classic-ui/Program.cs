using Ipc.Application.Contracts;
using Ipc.Application.ParcelFlow;
using Ipc.Application.ParcelFlow.Desktop;
using Ipc.Application.Sportmaster;
using Ipc.Application.Sportmaster.Desktop;
using Ipc.Assembly;
using Ipc.Platform;
using System.Text.Json;

var repo = args[0]; var evidence = args[1];
var config = Path.Combine(evidence, "configuration"); Directory.CreateDirectory(config);
File.Copy(Path.Combine(repo, "config/sportmaster/business.json"), Path.Combine(config, "business.json"), false);
var launch = new BusinessLaunch(config, Path.Combine(evidence, "data"), null, null);
await using var app = new ParcelRuntime(launch, new SportmasterFlow(), new ParcelCapabilityFactory(launch));
try
{
 await app.StartAsync(CancellationToken.None);
 var source = new FaultSource(app);
 var classic = new ParcelViewModel(source, "Sportmaster classic", "camera -> WCS");
 var alternate = new SupplyStationViewModel(source);
 if (!app.EmitReferenceAt("left", "audit-classic-entity", "AUDIT-0001", "audit-classic-observation")) throw new Exception("Reference admission refused");
 ParcelSnapshot s;
 for (var i = 0; ; i++) { s = await app.SnapshotAsync(); if (s.Operations.Any(o=>o.State == ParcelState.SlotResolved)) break; if (i > 150) throw new Exception("Reference WCS did not resolve"); await Task.Delay(20); }
 await classic.RefreshAsync(); await alternate.RefreshDisplayAsync();
 var before = new { ClassicAdmit=classic.CanAdmit, ClassicStatus=classic.Status, ClassicSlot=classic.CurrentSlot, AlternateFresh=alternate.Fresh, AlternateWorkspace=alternate.CanUseWorkspace };
 s = await app.SnapshotAsync(); var pause = await app.CommandAsync(new(Wire.Id(), s.Revision, "Pause"));
 var actual = await app.SnapshotAsync();
 if (!actual.Paused) throw new Exception("Underlying real Application was not paused");
 source.Fail=true;
 await classic.RunAsync(()=>Task.CompletedTask);
 try { await alternate.RefreshDisplayAsync(); } catch(IOException) { }
 var afterFailure = new { ActualPaused=actual.Paused, ActualAdmit=actual.Availability!.Admit, ClassicAdmit=classic.CanAdmit, ClassicStatus=classic.Status, ClassicSlot=classic.CurrentSlot, ClassicMessage=classic.Message, ClassicSnapshotRevision=classic.Snapshot!.Revision, ActualRevision=actual.Revision, AlternateFresh=alternate.Fresh, AlternateWorkspace=alternate.CanUseWorkspace, AlternateReadStatus=alternate.ReadStatus };
 await classic.CommandAsync("Resume");
 var command = new { Result=source.LastCommand!.Status, source.LastCommand.Reason, ActualStillPaused=(await app.SnapshotAsync()).Paused };
 source.Fail=false; await classic.RefreshAsync(); await alternate.RefreshDisplayAsync();
 var recovered = new { ClassicAdmit=classic.CanAdmit, ClassicStatus=classic.Status, AlternateFresh=alternate.Fresh };
 var result=new { Scope="Real ParcelRuntime, reference WCS, original compiled classic and alternate view-models; synthetic Snapshot IOException only. No WPF/Windows/device execution.", Baseline="ec698bd4e11d06c13c097c77f90cc5ce145ab3ea", Before=before, AfterSnapshotFailure=afterFailure, ExistingBusinessGuard=command, Recovered=recovered };
 var json=JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}); Console.WriteLine(json); File.WriteAllText(Path.Combine(evidence,"classic-stale-result.json"),json);
 if (!before.ClassicAdmit || !afterFailure.ClassicAdmit || afterFailure.AlternateFresh || afterFailure.AlternateWorkspace || !command.ActualStillPaused || command.Result!="Conflict") throw new Exception("Probe result differs from the suspected defect/guard");
}
finally { await app.StopAsync(CancellationToken.None); }
sealed class FaultSource(IParcelApplication inner) : IParcelApplication
{
 public bool Fail; public BusinessReceipt? LastCommand;
 public Task<ParcelSnapshot> SnapshotAsync()=>Fail ? Task.FromException<ParcelSnapshot>(new IOException("audit synthetic snapshot read failure")) : inner.SnapshotAsync();
 public Task<ParcelHistoryPage> HistoryAsync(long beforeSequence=long.MaxValue,int limit=50)=>inner.HistoryAsync(beforeSequence,limit);
 public Task<ParcelOperation?> OperationAsync(string id)=>inner.OperationAsync(id);
 public async Task<BusinessReceipt> CommandAsync(BusinessCommand c){LastCommand=await inner.CommandAsync(c);return LastCommand;}
 public Task<BusinessProjection> QueryAsync()=>inner.QueryAsync();
 public Task<BusinessReceipt> LoginAsync(string subject,string proof)=>inner.LoginAsync(subject,proof);
 public Task<BusinessReceipt> LogoutAsync()=>inner.LogoutAsync();
 public Task<BusinessReceipt> AuthorizeMaintenanceAsync(string subject,string proof)=>inner.AuthorizeMaintenanceAsync(subject,proof);
 public Task<CapabilityCatalog> CapabilitiesAsync()=>inner.CapabilitiesAsync();
 public Task<BusinessReceipt> ManageCapabilityAsync(string action,string identity)=>inner.ManageCapabilityAsync(action,identity);
 public Task<BusinessReceipt> InstallCapabilityAsync(string file,string sha256)=>inner.InstallCapabilityAsync(file,sha256);
 public Task<BusinessReceipt> ValidateConfigurationAsync(ParcelConfiguration candidate)=>inner.ValidateConfigurationAsync(candidate);
 public Task<BusinessReceipt> StageConfigurationAsync(long revision,ParcelConfiguration candidate,string? reason=null)=>inner.StageConfigurationAsync(revision,candidate,reason);
 public Task<BusinessReceipt> ReconcileAsync(string id,string? stage=null)=>inner.ReconcileAsync(id,stage);
 public Task<BusinessReceipt> ReconnectAsync()=>inner.ReconnectAsync();
 public Task<BusinessReceipt> BackupAsync(string destination)=>inner.BackupAsync(destination);
 public bool EmitReference(string admission,string code,string source)=>inner.EmitReference(admission,code,source);
 public bool EmitReferenceWeight(WeightMeasurement measurement)=>inner.EmitReferenceWeight(measurement);
 public bool EmitReferenceAt(string position,string admission,string code,string source)=>inner.EmitReferenceAt(position,admission,code,source);
 public Task<BusinessReceipt> ReconnectDeviceAsync(string device)=>inner.ReconnectDeviceAsync(device);
}
