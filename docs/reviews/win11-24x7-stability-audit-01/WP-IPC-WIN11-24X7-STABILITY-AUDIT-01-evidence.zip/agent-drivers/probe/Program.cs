using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Ipc.Drivers.Hikrobot;
using Ipc.Platform;

var results = new List<object>();
var started = DateTimeOffset.UtcNow;
void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
HikrobotReader Reader(FakeApi api, Lease lease, int capacity = 128) => new(
    new("audit", "audit.reader", new Dictionary<string, string> { ["device.ip"] = "192.0.2.1", ["entity.mode"] = "trigger", ["queue.capacity"] = capacity.ToString() }), api, _ => lease);

// These scenarios use the exact production driver sources and a controlled API double.
// No native DLL is loaded and no camera is contacted. A blocked double is NOT proof
// that the vendor DLL hangs; it reveals the host contract if a call does not return.
{
    var api = new FakeApi { BlockFirstEnumerate = true }; var lease = new Lease();
    await using var reader = Reader(api, lease);
    using var cancellation = new CancellationTokenSource();
    var health = new ConcurrentQueue<DeviceHealthConfirmation>();
    var task = reader.StartControlledAsync("audit-start", _ => true, health.Enqueue, cancellation.Token);
    Require(api.Entered.Wait(5000), "Initial Enumerate did not enter");
    cancellation.Cancel();
    await Task.Delay(300);
    var completedWhileBlocked = task.IsCompleted;
    api.Release.Set();
    await task.WaitAsync(TimeSpan.FromSeconds(5));
    results.Add(new { Name = "sdk-start-cancel-after-native-entry", TokenCancelled = cancellation.IsCancellationRequested,
        CompletedWithin300Ms = completedWhileBlocked, CompletedSuccessfullyAfterRelease = task.IsCompletedSuccessfully,
        ReadyPublishedAfterCancellation = health.Any(x => x.Health == DeviceHealth.Ready),
        Scope = "CONTROLLED_API_DOUBLE; exact production source; no actual SDK" });
    Require(!completedWhileBlocked && task.IsCompletedSuccessfully, "Expected cancellation gap was not observed");
}
{
    var api = new FakeApi(); var lease = new Lease();
    await using var reader = Reader(api, lease);
    await reader.StartControlledAsync("audit-stop", _ => true, _ => { }, CancellationToken.None);
    api.BlockHealth = true;
    Require(api.Entered.Wait(5000), "Heartbeat Enumerate did not enter");
    using var cancellation = new CancellationTokenSource(100);
    var stopwatch = Stopwatch.StartNew();
    var task = reader.StopAsync(cancellation.Token);
    await Task.Delay(400);
    var completedWhileBlocked = task.IsCompleted;
    var retained = lease.Disposals == 0;
    api.Release.Set();
    await task.WaitAsync(TimeSpan.FromSeconds(5));
    results.Add(new { Name = "sdk-stop-cancel-during-blocked-health", TokenCancelled = cancellation.IsCancellationRequested,
        CompletedWithin400Ms = completedWhileBlocked, OwnershipRetainedWhileBlocked = retained,
        CompletedSuccessfullyAfterRelease = task.IsCompletedSuccessfully, ElapsedMs = stopwatch.Elapsed.TotalMilliseconds,
        Scope = "CONTROLLED_API_DOUBLE; exact production source; no actual SDK" });
    Require(!completedWhileBlocked && retained, "Expected stop cancellation gap was not observed");
}
{
    var api = new FakeApi(); var lease = new Lease();
    await using var reader = Reader(api, lease, 1);
    using var entered = new ManualResetEventSlim(); using var release = new ManualResetEventSlim();
    var health = new ConcurrentQueue<DeviceHealthConfirmation>(); var delivered = 0;
    await reader.StartControlledAsync("audit-overflow", _ => { entered.Set(); release.Wait(); Interlocked.Increment(ref delivered); return true; }, health.Enqueue, CancellationToken.None);
    api.Emit(1); Require(entered.Wait(5000), "Receiver did not enter");
    api.Emit(2); api.Emit(3);
    var fault = health.Last(x => x.Health == DeviceHealth.Faulted);
    var stopping = reader.StopAsync(CancellationToken.None);
    release.Set(); await stopping.WaitAsync(TimeSpan.FromSeconds(5));
    results.Add(new { Name = "sdk-overflow-accounting-and-health-evidence", reader.FramesReceived, reader.FramesRejected,
        Delivered = delivered, UnaccountedInExposedCounters = reader.FramesReceived - reader.FramesRejected - delivered,
        DriverPrivateFailure = reader.LastFailure, PublishedHealthSource = fault.Source,
        PublishedHealthContainsFailureReason = fault.Source.Contains("queue", StringComparison.OrdinalIgnoreCase),
        Scope = "CONTROLLED_API_DOUBLE; no real camera; source counters are process-memory only" });
    Require(reader.FramesReceived == 3 && reader.FramesRejected == 1 && delivered == 1, "Overflow accounting shape changed");
}
Console.WriteLine(JsonSerializer.Serialize(new { SourceCommit = "c91559f6f981a9f2c9f89bd5afc271089f0e9d8e", StartedUtc = started, EndedUtc = DateTimeOffset.UtcNow,
    ActualSdk = "NOT_RUN", Windows = "NOT_RUN", Result = "REPRODUCED_CONTROLLED_CONTRACT_GAPS", Scenarios = results }, new JsonSerializerOptions { WriteIndented = true }));

sealed class Lease : IDisposable { public int Disposals; public void Dispose() => Disposals++; }
sealed class FakeApi : IHikrobotApi
{
    public bool BlockFirstEnumerate; public volatile bool BlockHealth;
    public readonly ManualResetEventSlim Entered = new(); public readonly ManualResetEventSlim Release = new();
    int enumerations; Action<HikFrame>? frame;
    public HikDevice[] Enumerate()
    {
        var call = Interlocked.Increment(ref enumerations);
        if (BlockFirstEnumerate && call == 1 || BlockHealth && call > 1) { Entered.Set(); Release.Wait(); }
        return [new("192.0.2.1", "synthetic-audit-camera", "fake", "fake", [])];
    }
    public void Create(HikDevice device) { }
    public void Open() { }
    public uint TriggerMode() => 1;
    public void Register(Action<HikFrame> callback, Action<Exception> failure, Encoding encoding) => frame = callback;
    public void Emit(uint sequence) => frame!(new(sequence, sequence, 0, 0, 0, sequence, ["AUDIT-" + sequence]));
    public void Start() { }
    public void Stop() { }
    public void Close() { }
    public void Destroy() { }
}
