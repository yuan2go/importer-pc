using Ipc.Application.Contracts;
using Ipc.Application.ParcelFlow;
using Ipc.Application.Sportmaster;
using Ipc.Application.DirectPlc;
using Ipc.Application.WcsToPlc;
using Ipc.Assembly;
using Ipc.Platform;

var workspace = "/workspace/scratch/56081ee5bcf2/importer-pc-audit03";
var root = Path.Combine("/workspace/scratch/56081ee5bcf2/audit03-work/business", "run-" + Wire.Id());
Directory.CreateDirectory(root);
Console.WriteLine("EvidenceRoot=" + root);
Console.WriteLine("Baseline=ec698bd4e11d06c13c097c77f90cc5ce145ab3ea; public ParcelRuntime/ParcelCapabilityFactory; reference capabilities only");
ParcelConfiguration Config(string id) => Wire.Decode<ParcelConfiguration>(File.ReadAllText(Path.Combine(workspace,"config",id,"business.json")));
CapabilityBinding Scale(string id) => new("weight", "reference-weight", "1.0.0", id, "reference://weight/"+id, "PARCEL-REFERENCE-v1", []);
async Task<ParcelRuntime> Open(ParcelConfiguration c, string run)
{
    var directory = Path.Combine(root, run, "config"); Directory.CreateDirectory(directory);
    ExtensionStore.AtomicWrite(Path.Combine(directory,"business.json"), c);
    var launch = new BusinessLaunch(directory,Path.Combine(root,run,"data"),null,null);
    FlowDefinition flow = c.ApplicationId switch { "sportmaster" => new SportmasterFlow(), "direct-plc" => new DirectPlcFlow(), _ => new WcsToPlcFlow() };
    var runtime = new ParcelRuntime(launch, flow, new ParcelCapabilityFactory(launch));
    try { await runtime.StartAsync(CancellationToken.None); return runtime; } catch { await runtime.DisposeAsync(); throw; }
}
async Task<ParcelSnapshot> Wait(ParcelRuntime app, Func<ParcelSnapshot,bool> predicate)
{
    var deadline = DateTimeOffset.UtcNow.AddSeconds(4);
    while (DateTimeOffset.UtcNow < deadline) { var s=await app.SnapshotAsync(); if(predicate(s))return s; await Task.Delay(10); }
    throw new Exception("Probe timeout: "+Wire.Encode(await app.SnapshotAsync()));
}
void Save(string name, object value) => ExtensionStore.AtomicWrite(Path.Combine(root,name+".json"),value);

foreach (var application in new[] { "direct-plc", "wcs-to-plc" })
{
    var scale=Scale(application+".audit.scale");
    var c=Config(application) with { Scale=scale, Weight=new(WeightSource.Measured,WeightUnit.Kg,3,MaximumAgeMs:3000,WaitTimeoutMs:5000), WeightValidity=WeightValidity.AtAssociation };
    await using var app=await Open(c,"unsettled-identity-"+application);
    await Wait(app,s=>s.Availability!.Admit);
    if(!app.EmitReference("same-entity","ORIGINAL-CODE","event-original"))throw new Exception("first input refused");
    var initial=await Wait(app,s=>s.Operations.SingleOrDefault()?.State==ParcelState.WaitingWeight);
    if(!app.EmitReference("same-entity","CONTRADICTORY-CODE","event-contradictory"))throw new Exception("second input refused at callback");
    var afterConflict=await Wait(app,s=>s.Revision>initial.Revision);
    var m=new WeightMeasurement(Wire.Id(),"same-entity",scale.Target,2.345m,WeightUnit.Kg,3,MeasurementQuality.Valid,true,DateTimeOffset.UtcNow);
    if(!app.EmitReferenceWeight(m))throw new Exception("weight refused at callback");
    var final=await Wait(app,s=>s.Operations.Single().State==ParcelState.PlcAccepted||s.IdentityConflicts!.Length>0||s.BlockingReasons.Any(x=>x.Contains("worker failed")));
    var op=final.Operations.Single();
    var evidence=new { Application=application, Before=initial, AfterContradictoryObservation=afterConflict, AfterWeight=final,
      ConflictCount=final.IdentityConflicts!.Length, PlcAttempts=op.Plc?.Attempts, DeliveredCode=op.Plc is null?null:Wire.Decode<ParcelPayload>(op.Plc.Request.Payload).ParcelCode };
    Save("unsettled-identity-"+application,evidence);
    Console.WriteLine(Wire.Encode(new { Scenario="Contradictory observation while WaitingWeight", Application=application,
      afterConflict.Revision, Conflicts=final.IdentityConflicts!.Length, Final=op.State, PlcAttempts=op.Plc?.Attempts,
      DeliveredCode=evidence.DeliveredCode, Reproduced=final.IdentityConflicts.Length==0&&op.Plc?.Attempts==1 }));
}

{
    var leftScale=Scale("left.audit.scale"); var rightScale=Scale("right.audit.scale");
    var standard=Config("sportmaster");
    var c=standard with { Scale=leftScale, CapabilityInstances=[leftScale,rightScale,standard.Wcs!,standard.MaintenanceLogin!],
        Weight=new(WeightSource.Measured,WeightUnit.Kg,3,MaximumAgeMs:3000,WaitTimeoutMs:5000), WeightValidity=WeightValidity.AtAssociation,
        Topology=standard.Topology! with { Positions=[standard.Topology!.Positions[0] with { ScaleInstanceId=leftScale.InstanceId }, standard.Topology.Positions[1] with { ScaleInstanceId=rightScale.InstanceId }] } };
    var app=await Open(c,"measurement-isolation");
    try
    {
        await Wait(app,s=>s.Availability!.Admit);
        app.EmitReferenceAt("left","left-original","LEFT-CODE","left-original-event");
        app.EmitReferenceAt("right","right-original","RIGHT-CODE","right-original-event");
        await Wait(app,s=>s.Operations.Length==2&&s.Operations.All(o=>o.State==ParcelState.WaitingWeight));
        var measurement=new WeightMeasurement(Wire.Id(),"left-original",leftScale.Target,2.345m,WeightUnit.Kg,3,MeasurementQuality.Valid,true,DateTimeOffset.UtcNow);
        app.EmitReferenceWeight(measurement);
        var before=await Wait(app,s=>s.Operations.Single(o=>o.PositionId=="left").State==ParcelState.SlotResolved);
        var emitted=app.EmitReferenceWeight(measurement with { Value=3.456m });
        var after=await Wait(app,s=>s.BlockingReasons.Any(x=>x.Contains("worker failed")));
        var rightEmission=app.EmitReferenceWeight(new(Wire.Id(),"right-original",rightScale.Target,4.567m,WeightUnit.Kg,3,MeasurementQuality.Valid,true,DateTimeOffset.UtcNow));
        Save("measurement-isolation",new { Before=before, After=after, emitted, RightEmission=rightEmission });
        Console.WriteLine(Wire.Encode(new { Scenario="Left weight identity reused with changed value", Emitted=emitted,
            after.State, after.BlockingReasons, RightEmission=rightEmission, RightWcs=after.Operations.Single(o=>o.PositionId=="right").Wcs,
            Reproduced=after.BlockingReasons.Any(x=>x.Contains("worker failed"))&&!rightEmission }));
    }
    finally
    {
        try { await app.DisposeAsync(); }
        catch(Exception ex) { Console.WriteLine("Expected terminal-worker cleanup report: "+ex.GetType().Name+": "+ex.Message+"; resourcesReleased="+!app.HasUnreleasedResources); }
    }
}
Console.WriteLine("Probe complete: no business/config/test/design repository files modified; no device access.");
