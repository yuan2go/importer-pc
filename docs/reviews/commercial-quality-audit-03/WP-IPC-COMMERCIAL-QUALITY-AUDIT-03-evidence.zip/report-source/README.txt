报告生成源说明

本目录包含完整报告正文记录及ReportLab生成脚本。最终PDF单独交付；身份见report-identity.json。生成脚本以本次固定SHA隔离仓库读取对应源码，并读取已保存release-artifact-table.json。
脚本使用Python的reportlab与静态Noto Sans SC字体（Regular wght400、SemiBold wght600；字体源为 https://github.com/google/fonts/tree/main/ofl/notosanssc）。字体未作为独立资产交付。原审查中使用fontTools从该公开变量字体生成静态字体。重建报告时调整ROOT及字体路径；报告日期、PDF内部元数据和输出路径可造成PDF字节变化，不能据此认定审查内容或业务实现改变。
报告截图仅用于版面QA，非Windows/WPF/设备图。报告中的全部源码URL固定于审查SHA；source-index.json及source-excerpts.txt保存精确行及源文件hash。
