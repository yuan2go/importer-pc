WP-IPC-COMMERCIAL-QUALITY-AUDIT-03 审查证据说明

固定源码：ec698bd4e11d06c13c097c77f90cc5ce145ab3ea
仓库：https://github.com/yuan2go/importer-pc
精确源码链接前缀：https://github.com/yuan2go/importer-pc/blob/ec698bd4e11d06c13c097c77f90cc5ce145ab3ea/
克隆：2026-10-19 09:30:08 +08:00（01:30:08 UTC）；切到origin/main detached：09:30:38 +08:00（01:30:38 UTC）。实际git reflog、环境、SDK与本次整理时clean状态见baseline.json和environment/。

范围
只读固定main代码、现行文档、构建配置、公开发布产物与其已有证据。允许的隔离构建/必要验证使用Linux Ubuntu 24.04、.NET SDK 10.0.402、runtime 10.0.13及合成输入。本目录没有修改任何业务代码、配置、既有测试或设计，也没有提交、推送、PR操作或生产设备操作。证据整理仅复制既有文件、计算身份和静态元数据；没有重新测试或新增探针。

目录
baseline.json：固定源码、reflog时间、环境和工作树身份。
environment/：实际dotnet --info、os-release、reflog和空的clean porcelain输出。
original-verification/：根审查执行的restore/build及三组原有定向验证原日志。
probes/business/：F01/F02独立探针最终源码、两次已有构建日志、成功完成的probe-confirmed.log和完整结果JSON。
probes/rcs-order/：F03实际RCS HTTP客户端/仓库loopback夹具，延迟左位采图的定向编排与唯一run结果。
probes/classic-ui/：F04原编译ViewModel与实际ParcelRuntime的快照异常探针；没有WPF/Windows窗口运行。
probes/referenced-dlls.json：全部Probe显式或glob引用的实际Release DLL哈希，及探针自身产物/SQLite依赖哈希；不复制二进制。
setup-not-product-failures/：保留原环境/夹具设置失败，不把它们计为产品失败。
release-artifacts/：实际Windows发行ZIP的CRC/内部hash/闭包比较、发布清单、页面元数据、清单及提取指南/包manifest。原104170521字节ZIP不在证据包内，来源和hash可用于重新取得核验。
review-notes/：三个独立分工的原审查笔记。子审查候选建议的证据强度与正式问题不同，正式F01–F05概括见evidence-summary.json。
static-analysis/：csproj静态ProjectReference并集无环结果和F05有效指南原行/代码依据。
copy-manifest.json：每个复制文件原绝对路径、相对路径、字节数、SHA和分类。最终整包校验由主审查人在加入最终报告及索引后统一生成。

怎样解释PASS与CONFIRMED_DEFECT
原application-architecture、parcel-recovery-p2、sportmaster-rcs组PASS，只证明原用例实际检查范围；不能说明新增交错反例被覆盖。独立探针运行完成/退出成功表示成功观察目标行为：CONFIRMED_DEFECT是已确认产品问题，不是产品通过。
F01：DirectPlc和WcsToPlc在同实体矛盾条码观察后ConflictCount仍为0，原码PLC意图仍有一次发送；不等于证明真实PLC已动作或发生实际错分。
F02：左秤同测量ID不同内容引发全局Blocked，右秤后续有效回调被拒；原已保存重量不被覆盖。
F03：右位先准备RCS号后，较早准入但采图迟到的左位因全局高水位阻断；使用合成采图延迟与本机HTTP服务。
F04：实际应用已暂停而classic仍投影旧Ready/格口；原应用CAS/命令守卫仍拒绝过期动作，不能声称守卫已被绕过。alternate在同样异常下标记快照失效。
F05：当前维护指南ABI和普通旧库升级规则内部矛盾，属于当前文档问题；不以旧SHA或旧PASS否定历史记录。

原失败的分类
1. original sportmaster-rcs第一次在TCP socket创建时得到Permission denied，见setup-not-product-failures/rcs-sandbox-socket/。这是沙箱阻止本机测试监听，未到产品HTTP行为。允许loopback的执行环境中，同一原组随后PASS，原失败没有删除或改写。
2. business第一次独立DLL直引用探针没有找到libe_sqlite3，属于独立探针依赖解析设置；明确LD_LIBRARY_PATH到已有Linux native目录后继续。
3. business第二次双秤合成配置缺少必需完整角色镜像，被产品正确拒绝；只修改探针合成配置后形成最终probe-confirmed结果。两次早期日志保持原字节，当前Program.cs为最终探针源码，不能把最终源码冒称早期已修改前快照。

复现条件与参考命令
以下是复现步骤，不是声称日志内已包含原执行argv的签名记录。应先新建固定SHA隔离checkout；确保AGENTS/README/INDEX约束、SDK/锁文件、无未提交业务变更。所有输出放新的临时目录，禁止指向生产目录/设备/客户地址。RCS组及F03需允许127.0.0.1测试监听。

<DOTNET> = 实际10.0.402 dotnet绝对路径
<REPO> = 固定ec698bd4...的隔离源码绝对路径
<VERIFY> = <REPO>/tests/Ipc.Application.Verification/bin/Release/net10.0
<PROBE> = 从本证据复制到新工作目录的对应探针项目
<NEW_RESULTS> = 全新隔离结果目录

<DOTNET> restore <REPO>/tests/Ipc.Application.Verification/Ipc.Application.Verification.csproj -p:RestoreLockedMode=true
<DOTNET> build <REPO>/tests/Ipc.Application.Verification/Ipc.Application.Verification.csproj -c Release --no-restore -m:1 -nr:false
<DOTNET> <VERIFY>/Ipc.Application.Verification.dll <REPO> --application-architecture
<DOTNET> <VERIFY>/Ipc.Application.Verification.dll <REPO> --parcel-recovery-p2
<DOTNET> <VERIFY>/Ipc.Application.Verification.dll <REPO> --sportmaster-rcs

探针保留本次原绝对路径。重新运行时，在复制出的Probe.csproj及Program.cs中只替换原workspace/repo/输出根为新的对应绝对路径；不要更改断言、行为、SDK或业务源码来取得相同结果。business/F03输出根由Program.cs中的新路径+run-GUID生成；classic的Program使用命令参数。直接引用的原仓库Release DLL见probes/referenced-dlls.json；经典VM类型来自原验证项目编译链接，不是本探针复制重写业务类。

<DOTNET> build <PROBE>/Probe.csproj -c Release -m:1 -nr:false
DOTNET_ROOT=<DOTNET所在目录> LD_LIBRARY_PATH=<VERIFY>/runtimes/linux-x64/native <DOTNET> <PROBE>/bin/Release/net10.0/Probe.dll
classic探针最后一行另附参数：<REPO> <NEW_RESULTS>

本次classic原记录为Debug探针自身构建、引用Release业务DLL；其余探针自身Release。若需逐字节对照原Probe哈希，应采用原Configuration与路径映射/构建输入，不能把因构建路径/PDB/源码绝对路径变化产生的hash差异直接解释成业务不同。使用复现源码时保持原证据目录不可变，另存替换后的副本及运行结果。

验证层级
静态代码/文档与发行物检查已执行；Linux隔离构建和三组既有参考验证已执行；四项运行缺陷按各自合成范围复现。Windows真实UI、Dispatcher/HWND、DPI/触控、安装/UAC/ACL、真实SDK、PLC/WCS/RCS合同、真实实体关联和现场验收没有由本轮完成。Windows延期仍保留，延期不等于商用免验。NOT_RUN/BLOCKED不能从源码或参考PASS改成已验证。

本包不含SDK、NuGet缓存、bin/obj、原Windows发布ZIP或整个repo；没有客户秘密、真实生产设备数据或私钥。原始来源文字中保留的绝对路径是本次临时审查位置，不是用户生产安装路径。

最终报告与索引
本包另含source-index.json / source-excerpts.txt（102处固定行范围）、report-source/（完整正文和生成源、PDF版面验证）、report-identity.json。最终PDF另行交付，共31页。SHA256SUMS覆盖本证据包除自身之外的全部文件；可在解压根目录执行 sha256sum -c SHA256SUMS。原文件复制身份见copy-manifest.json；没有把探针CONFIRMED_DEFECT当作原测试PASS。
