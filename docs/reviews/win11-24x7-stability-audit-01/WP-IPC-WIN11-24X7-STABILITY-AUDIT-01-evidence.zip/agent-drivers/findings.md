# 驱动、原生 SDK 与 RCS 独立审查

固定源码：`c91559f6f981a9f2c9f89bd5afc271089f0e9d8e`。以下行号均以该提交为准。只读源码与既有证据；新探针在仓库外，未改业务文件、既有测试或历史证据。

## 结论

TCP、原生海康 SDK 和参考手工输入必须分别验收。TCP 的拆粘包、严格编码、接入围栏与取消排空已经有实质保护；真实海康路径仍存在可复现的取消契约缺口、驱动故障诊断/输入计数缺口，以及静态确定的单侧启动失败扩大为整个 Application 启动失败。RCS 对原请求身份、迟到/错配响应和不明结果采取保守保护是正确的，但 `Query=false` 下没有自动或人工权威结果接入途径，普通超时可造成长期本位阻断。这是交付所需的业务恢复合同缺口，不能靠重发、清账或心跳恢复解决。

## 实际链路、线程和所有权

1. `ParcelCapabilityFactory.cs:389,422` 按 Effective 配置构造 `tcp-line` 或精确已安装的 Reader 扩展及内建/扩展 RCS。设备身份和位置由拓扑绑定，网络接口编号或 UI 焦点不参与左右映射。
2. TCP：`TcpLineObservationSource.cs:50–90` 用 lifecycle 信号量串行 Start/Stop；5 秒 ConnectAsync budget；`76` 在后台启动唯一读取循环，`94` 单连接字节缓冲 1024、行缓冲最多 4097；`113–135` 严格 LF/CRLF、UTF-8、长度和字符检查后生成新 Epoch/Sequence/SourceEventId。`132–135` 不跨应用回调持驱动锁。
3. 海康：`HikrobotReader.cs:70–87` 后台调用 native 初始化；`NativeMethods.cs:141–154` 回调委托字段保持引用，并在 callbackGate 计数在途回调。`CopyFrame:41–69` 在回调有效期内拷贝有限码数据；`OnFrame:99–120` 在 gate 下校验注册、触发计数和16个通道边界，写入有界 Channel；消费任务 `122–134` 调用应用入队。
4. `ObservationSession.cs:27–34` 固定注册 Epoch；`ReconnectAsync:39–41` 先换代次，完整停止旧源再 Start。`AcceptSequence:13–18` 在当前应用聚合 gate 内被调用，因此现调用链不是并行读改 Sequence。
5. `ParcelRuntime.cs:150–160,220–277` 每位置独立 Channel/消费者，入队共享 overloadSync；消费者共用聚合 gate，SQL/状态在 gate 内，外部 HTTP 经 `ParcelGuards.cs:46–51` 释放 gate 等待，返回后重新取得。单侧网络等待不持有聚合 gate。队列溢出在 `240–245` 持久独立标记，不继续假成功。
6. `ParcelStages.cs:36–57` 冻结请求拷贝、T2、接收责任预登记后外呼，Effective.TimeoutMs 的链接 token 传给 HTTP；`SportmasterRcsTaskService.cs:29–37` 单个复用 HttpClient，禁重定向/代理/cookie，最多8连接，5分钟连接寿命；读取回应上限256KiB (`122–138`)。
7. 回应 `RcsDestinationProtocol.cs:31–64` 校验 requestId/index/command/字段、成功/拒绝矛盾及拆包条码；`ParcelStages.cs:83–94,99–136` 先存独立原件，再同事务应用 T3，校验内部请求ID/hash与已有终态。不能以物理完成替代取得格口。
8. RCS 心跳 `RcsHeartbeat.cs:36–84` 一个 PeriodicTimer 串行轮询，每次预算不超过3秒和所配置周期，失败不重发旧心跳；与取格口持久编号分开。2xx只说明HTTP，未伪造业务确认。

## 主要问题

### DR-01：SDK 操作超时不能终止或释放已开始的 native 调用——高，条件阻断

**触发：** SDK 的枚举、打开、参数读取或 Stop/Close/Destroy 在设备/驱动异常下长时间不返回。

**源码：** `HikrobotReader.cs:70–87` 的 token 仅传给 Task.Run 调度；已经运行的 delegate 不再检查 token。`StopAsync:172–177` 只在取得 lifecycle 时使用 token，随后 `StopCore:179–200` 无 token；`182` 无界等待健康任务，`187,192–193` 无界等待同步 native 操作。`NativeMethods.cs:90–108` 全部实例共用 enumerationGate，且每个 Reader 的 `Heartbeat:139–149` 每秒重新枚举。

**传播：** 一侧 native 枚举卡住可使另一侧枚举也卡在全局锁；两侧健康租约过期，随后位置拒绝准入。启动按 Reader 顺序等待 (`ParcelRuntime.cs:163–174`)，可能卡住整个启动；应用停止按来源顺序调用 (`ParcelCommands.cs:207–217`)，可能无法到达后续来源/端口和资源释放。UI是否仍能画面响应取决于上层异步等待，但这已经是生命周期无法完成，不能称恢复成功。

**本轮证据：** `probe-stdout.log` 的实际生产源码+受控 FakeApi 探针复现：初始化进入枚举后取消，300ms不完成，解除受控阻塞后仍成功并发布Ready；健康枚举受控阻塞时 Stop token100ms，400ms不返回，解除后才正常停止。租约保留为有效保护，没有重复建连/强行销毁。探针不是厂商 SDK 卡死实测。

**修复方向：** 明确每个 SDK 调用的厂商时限/可取消性和异常行为；使取消后的状态回执与所有权真实一致，明确未排空不能重新创建。增加独立于 SDK 线程的 in-flight/超时可观测性。若目标厂商调用没有可证明的有界返回或实机注入证明 native 故障影响进程，才为该原生边界增加可控独立进程监督，保留 Epoch、原输入责任、不得自动重发；不能仅套一层 WaitAsync 然后释放原句柄。

**必要验证：** 复用现有停止失败/保有测试；增补进入 native 后取消、超预算后返回、双 Reader 共享枚举异常、重复停/重连；真实SDK目标设备验证 Stop、拔网/掉电和回调寿命。真实 native crash/hang、24h SDK 负载均 NOT_RUN。

### DR-02：SDK 单侧缺相机可阻断全部启动，TCP 的单侧隔离不能背书 SDK——高，静态证实

**触发：** 海康一侧相机未上电、枚举不到指定IP/序列号；另一侧正常。

`HikrobotReader.cs:72–73` 抛普通 IOException，清理后仍原样抛出 (`89–95`)；`ParcelRuntime.cs:163–171` 仅捕捉 TCP 已分类的 ObservationConnectionException。该错误落到全局启动 catch (`192–200`) 并关闭接纳，未继续正常另一侧。TCP 已在 `TcpLineObservationSource.cs:79–87` 将可隔离 ConnectFailure/Timeout 明确分类。运行时的一侧正常返回的 SDK 健康失败则会 Fault 本侧，不能混同为必然两侧停。

**修复方向：** 只将已经围栏并确实清理完资源的相机传输/缺失故障分类为按位失败；SDK版本/ABI/装配失败、资源未排空仍维持全局失败。保留启动输入去向和另一侧全部共享能力守卫。

**必要验证：** 相机缺失且资源清理成功、Open失败且清理失败、另一侧继续、重连不换另一侧Epoch。真实双SDK设备 NOT_RUN。

### DR-03：SDK 故障已显示 Faulted，但原因与丢失输入范围未进入宿主诊断/持久账——高，探针复现+静态证实

`HikrobotReader.cs:119` 满队列帧只 Fault，不增 FramesRejected；`128` fault后已排队帧被跳过并只增加内存计数；`167` 保存 LastFailure，但 `Confirm:155–160` 只发送固定 Source，未发送失败原因或计数。接口 `DeviceCapabilities.cs:20–38` 没有读取 LastFailure/计数端口，全仓只有独立 Probe/自测读这些属性。宿主 `ParcelHealth.cs:7–10` 持久诊断所得仅是 Faulted+固定Source。

**本轮复现：** driver queue capacity=1；第一帧receiver受控阻塞，第二帧入队，第三帧溢出。最终 FramesReceived=3、实际调用receiver=1、FramesRejected=1。还有1帧未在这些计数中归属；已队列帧没有逐笔业务InputObserved。公开给宿主的Source=`SDK:hikrobot-idmvs:audit`，没有“queue full”原因。

**后果：** 不会继续假装Ready，但现场难以区分SDK异常、触发计数反转、驱动队列满或宿主拒收；无法按业务目标核对驱动接纳、拒收和未决范围。不能把“有界队列+Faulted”写成已完成无损背压闭环。

**修复方向：** 复用健康/日志端口输出有界、脱敏的错误类别、注册代次、源序号和累计/区间计数；对故障后无法交付的驱动接纳范围建立明确待检查责任和可恢复状态。不要在 native 回调同步写数据库或逐帧刷盘，不为保流畅静默丢弃。

### DR-04：RCS 不明结果没有闭环处置合同——高，静态证实的业务恢复缺口

**触发：** 请求已经发送但结果超时、回应不完整、HTTP错误或身份不匹配。

`SportmasterRcsTaskService.cs:99–117,122–138` 和 `ParcelStages.cs:60–79,127–131` 保留 Unknown；`ParcelCapabilityFactory.cs:260` 声明 Query=false，`QueryAsync:71–75` 不发原请求，`ParcelStages.cs:20–21` 拒绝权威核对；`ParcelGuards.cs:21–24` 不允许将Unknown按“未提交”弃置。`PositionReady:10–13` 和 `CanAdmit:26–28` 阻止同位后续实体。重启保持Unknown，不能清除责任。

**范围：** 单笔业务HTTP超时不会直接设置 heartbeatFailure。若共享心跳持续成功，Unknown只阻本位；共享心跳失败后 `HealthAsync:55–59` 与 `MonitorAsync` 更新公共WCS健康，两个位置的新准入都受 `AdmissionCapabilitiesReady:60–65` 阻断。后续2xx恢复公共HTTP就绪，但原Unknown仍在。

**裁决：** 现保护避免重复任务，是正确设计；然而如果现场预期网络恢复后可按流程恢复业务，则当前缺少权威查询/结果导入/对账处置合同及其实现。需要与RCS取得原requestId的可靠结果或经批准的处置证据接入方案；不建议自动POST重发、改ID重投或清库。应将此作为生产恢复验收门槛，不写成进程死锁。

### DR-05：TCP 静默断网没有远端存活证明——中至高，静态边界/现场待验

`TcpLineObservationSource.cs:145–172` 每秒续期本地连接状态；唯一 Read 在 `101–105` 判断错误/EOF。没有应用心跳，也没有配置 Socket KeepAlive。对静默黑洞且无流量，旧TCP连接可持续被标为本地Ready；Source 已诚实写明 LocalTransportOnly。不能从最近无包裹推断故障，也不能从本地timer续期推断远端相机在线。

**建议：** 依据实际设备协议决定可用的连接层探测或设备侧权威信号，记录本地连接/最近字节/最近有效观察/业务进展分别的时效。对有持续独立触发节拍的工况建立无进展告警，正常空闲不误报。需要隔离环境静默黑洞实验；不能凭空加相机应用报文。

## RCS 编号容量：与 MaximumOperations 分开

`request-id-base` 与 `request-id-count` 均必填，无默认。`RcsTaskOptions.cs:17–36`、`SportmasterRcsTaskService.cs:63–67` 定义区间 `(base, base+count]`。仓库合成样例 `config/sportmaster/rcs.parameters.json:8–9` 为 base=1,000,000,000,000、count=1,000,000；不是现场配置，也不是产品自动默认。

`ParcelIntegrationIds.cs:8–20` 根据永久 owner/restore 高水位分配；普通归档和清理不重用；`22–49` 在备份恢复时退役已知原范围的未用尾部，避免源机器曾发送而旧备份不知道的编号被复用。剩余可分配量应按 `max(0, range.Last - max(range.First-1,durableFloor))` 计算。心跳ID不消耗此范围，但必须不重叠。

假设从完整一百万额度开始、没有退役、每接纳包裹均分配1个T1编号：双位合计1/s约11.57天、2/s约5.79天、10/s约1.16天。只是算术预算，不是吞吐或运行时长实测。恢复、高基值、历史分配均可能缩短。

耗尽时 `ParcelRuntime.cs:417–438` 在外呼前形成 PreparationBlocked，没有Wcs意图/attempt；持久保留实体，worker不崩溃。原流程可暂停检查、AbandonUnsubmitted处置未提交实体后，由管理模式经完整候选/CAS配置新分配的不重叠且高于永久高水位的范围并受控激活。必须取得服务端分区约定；不能清库或回调到旧范围。缺少可见的剩余额度/预计耗尽日期预警，建议加入交付容量预算和到期操作演练。

## 资源上界不能只数“队列128”

驱动默认128条、允许1..1024（HikrobotReader.cs:52–53），每帧最多300条×4096字节（NativeMethods.cs:51–66）。只考察驱动队列：若128帧均各含300条独立、全ASCII、无末尾NUL的4096字符字符串，仅UTF-16字符载荷的算术值为 `128 × 300 × 4096 × 2 = 314,572,800` 字节，即每相机约300MiB。这是合法最大载荷的理论预算，未扣除可能的字符串共享，不含对象/数组开销、native缓冲或GC临时分配；不是工作集、实际常态占用或泄漏实测。

已核对应用入口 `ParcelRuntime.cs:234–236` 会限制候选数/单条长度并标记超限；`BarcodeFiltering.cs:10` 的实际常数分别为300和4096。入口数组复制、字符串完整切片与跨队列所有权可能共享引用，不能把上下游各自容量简单相加当进程内存上界；本报告不提供双SDK加应用队列总内存数字。通常单个短条码远低于上述极值。应按现场候选数/条码长度和IPC预算设置总字节/队列策略，并实际采集队列高水位与托管/进程资源趋势。

## 已验证与未验证矩阵

|风险/能力|本轮或可复用证据|仍缺证据|
|---|---|---|
|原生缓冲/委托/stop失败保有|源码、现有 Probe.Verification 及本轮FakeApi|真实长时回调、拔网、Stop阻塞、native异常|
|SDK开始后取消、Stop取消|本轮1.78秒受控运行复现缺口，含构建5.16秒|真实SDK是否/何时发生无限调用|
|SDK满队列输入与诊断|本轮3帧合成复现计数/公开原因缺口|真实峰值及完整补偿操作|
|TCP拆粘包、首帧/单侧连接|现有定向测试/源码，父审查执行结果另记|Windows11真实双相机、静默断网、线缆/网卡|
|RCS身份、迟到、有限回复|源码与父审查实际 sportmaster-rcs 套件|真实RCS合同/时延/超时后结果核对|
|负载发生器可用|本轮3.09秒脚本协议自测|实际应用连接、24h/72h、WPF与设备负载|

## 证据文件

`probe/Program.cs`、`probe/Probe.csproj` 链接原源码，不修改驱动；`probe-execution.json` 保存命令、UTC、退出码、source哈希；`probe-stdout.log` 保存三个复现场景；`probe-stderr.log`为空。`loopback_load.py`、`fixture_smoke.py` 与 `fixture-smoke-execution.json` 为独立合成测试工具及其自测。首次在受限沙箱绑定127.0.0.1失败，保留在 `fixture-smoke-evidence/`、`fixture-listen-retry/`；取得仅loopback执行环境后自测通过，原失败不删改。
