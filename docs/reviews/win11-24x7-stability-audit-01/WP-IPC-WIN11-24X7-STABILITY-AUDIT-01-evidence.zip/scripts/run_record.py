#!/usr/bin/env python3
"""Run one isolated audit command and retain timestamps, argv, output and exit identity."""
import argparse, datetime, hashlib, json, os, pathlib, platform, subprocess, time
p=argparse.ArgumentParser(); p.add_argument('--name',required=True); p.add_argument('--out',required=True); p.add_argument('--cwd',required=True); p.add_argument('--timeout',type=float,default=300); p.add_argument('command',nargs=argparse.REMAINDER); a=p.parse_args()
command=a.command[1:] if a.command[:1]==['--'] else a.command
out=pathlib.Path(a.out); out.mkdir(parents=True,exist_ok=True)
env=os.environ.copy(); env.update({'DOTNET_ROOT':'/tmp/ipc-audit-dotnet','DOTNET_CLI_HOME':'/workspace/scratch/4d42c7c75922/audit-cache/dotnet-home','NUGET_PACKAGES':'/workspace/scratch/4d42c7c75922/audit-cache/nuget','DOTNET_NOLOGO':'1','DOTNET_CLI_TELEMETRY_OPTOUT':'1','DOTNET_SKIP_FIRST_TIME_EXPERIENCE':'1','PATH':'/tmp/ipc-audit-dotnet:'+env.get('PATH','')})
start=datetime.datetime.now(datetime.timezone.utc); tick=time.monotonic(); timed_out=False
with open(out/(a.name+'.log'),'wb') as log:
    proc=subprocess.Popen(command,cwd=a.cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try: code=proc.wait(timeout=a.timeout)
    except subprocess.TimeoutExpired:
        import signal
        timed_out=True; os.killpg(proc.pid,signal.SIGTERM)
        try: code=proc.wait(timeout=5)
        except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); code=proc.wait()
end=datetime.datetime.now(datetime.timezone.utc)
record={'name':a.name,'command':command,'cwd':a.cwd,'start_utc':start.isoformat(),'end_utc':end.isoformat(),'duration_seconds':time.monotonic()-tick,'exit_code':code,'timed_out':timed_out,'environment_class':'LINUX_ISOLATED_MANAGED_NOT_WINDOWS_NOT_DEVICE','os':platform.platform(),'log_sha256':hashlib.sha256((out/(a.name+'.log')).read_bytes()).hexdigest()}
(out/(a.name+'.json')).write_text(json.dumps(record,indent=2),encoding='utf-8'); print(json.dumps(record)); print((out/(a.name+'.log')).read_text(errors='replace')[-10000:]); raise SystemExit(124 if timed_out else code)
