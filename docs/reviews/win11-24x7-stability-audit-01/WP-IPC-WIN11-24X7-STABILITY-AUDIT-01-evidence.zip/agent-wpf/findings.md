# WPF、日志、Windows 运维独立只读审查

基线：`c91559f6f981a9f2c9f89bd5afc271089f0e9d8e`。本子审查只读取源码、设计、原始证据和官方诊断工具文档。当前 Linux 环境没有 Windows 原生 WPF；新增采集器已用 Linux PowerShell7.6.8 解析通过（0 errors），Windows 原生验证和脚本执行仍 **NOT_RUN**。未改业务、现有测试、设计或历史证据。

## 结论

- 主作业窗口已有异步服务边界、轮询防重叠、过期快照守卫、同一业务实例多页共享及关窗排空；没有依据断言“UI 每笔业务都同步网络/数据库”。
- 尚有可达的 UI 同步 I/O 漏口；管理状态检查处于快照读取前置路径，日志查询的权威检查在移出 UI 之前执行。
- 每窗 500ms 全量快照及高频投影/通知仍然消耗全局业务 gate、CPU 和分配；资源上升不等于泄漏，必须与核心容量/SQL路径合并测量。
- 当前可见原生性能证据为旧源码、300 笔串行合成输入和约 24 秒的 1/2 窗空闲样本。它反映成本但不证明当前 main、实际双位输入或 24 小时稳定。
- 未发现生产部署中的独立 UI/业务进展 watchdog、崩溃/挂起转储配置与明确的电源/会话/更新运行政策。当前 Fresh 机制依赖同一 UI Dispatcher，不能证明 UI 自身健康。

## 风险清单（供总审合并排序）

### UI-01：日志服务的授权前置检查仍在 UI 线程同步执行

**类型：静态证实可达；实际迟滞量与目标机后果待验证。建议 P1/P2，依现场 UI 预算。**

- UI调用：`src/Ipc.Application.ParcelFlow.Desktop/SoftwareLogPage.cs:135-143,156-166,187-192`，await 之前的方法同步前缀运行在 UI。
- 运行时：`ParcelAdministration.cs:9,31-36`，三个日志接口先 `var logs = Logs`，`Logs` 先 `Management.Require()`，随后才 Task.Run。
- 授权：`LocalManagementMode.cs:114-132`。本地路径持锁、读取 credential 文件；受保护部署已进入管理模式时走 `RemoteStatus()`。
- RPC：`ManagementModeBroker.Protocol.cs:28-39,70-79` 同步 `.GetAwaiter().GetResult()`，Status 总 token 500ms / Connect 100ms；`RequireServer` 和根路径规范化/SCM等同步检查并非都由该 token 中断。
- 后果：日志查询/上下文/导出点击时可卡住整个 WPF Dispatcher，左右位显示和输入响应同时延迟；业务线程通常仍运行。它是 UI 无响应风险，不应混同 OS 死机。
- 修复：把完整的权威检查和日志服务进入放在后台统一边界；保留操作前/扫描中/最终发布前的授权复核及取消；不要缓存授权为永久可用。
- 必要测试：真实 HWND、已安装管理服务及普通账户；受控让 Status 达到500ms、文件慢读、失效/重启，主窗口 UI 调度与业务输入仍符合预算。对每条日志调用复用相同测试，不重复全套业务回归。

辅助同步 I/O：`ShellWindow.xaml.cs:94-98`、`SupplyStationWindow.xaml.cs:94-98` 同步保存布局；`StationDisplayPreferences.cs:19-43` 首次/站点切换读取和应用显示偏好；`PresentationPreferences.cs:14-25,28-45` 有4KiB上限，但磁盘迟滞不受长度上限保证。频率低，宜在同一后台边界修复，不应夸成已发生长期卡死。

### UI-02：快照/显示轮询仍放大业务锁和常驻工作集成本

**类型：当前静态证实；性能量级存在旧原生实测；当前 main/真实负载未量化。建议与存储审查 P1 合并。**

- `SupplyStationWindow.xaml.cs:12,52-65`、`ShellWindow.xaml.cs:27,57-65`：每个窗口独立500ms轮询；单窗口防重叠，但双窗成本相加。
- `ParcelViewModel.cs:139-159`：先读管理模式、再读全量快照；`DesktopServiceCalls.cs:8-18` 将服务调用 Task.Run并跟踪，故不是全量SQL直接跑UI。
- `ParcelCommands.cs:7-44`：全局 gate 内聚合容量/历史/未决，再完整 JSON encode/decode；主 runtime agent 已确认容量多次遍历、PendingCommands全命令JSON扫描等底层成本。
- `ParcelViewModel.cs:23` 每份快照发多项通知；`ParcelSnapshotValidity.cs:47-52` 每次 Fresh 更新也 NotifyTargets；`ParcelTargets.cs:212-219` 每次重新计算完整详情/配置字符串，虽相同则不发文本通知，但序列化计算仍发生。
- `SupplyStationViewModel.cs:229-280` 在 UI 上两位各筛选、排序全部常驻作业；显示值有缓存比较，Recent 只在显示事实变化时替换，不能误称每轮强制替换全部表格。
- 修复：优先复用同一权威，按版本发布精简作业快照；昂贵容量/命令统计维护为可信索引或增量投影；字段/选中详情按需；不要把背景 Task.Run当作消除共享 gate 成本。
- 必要验证：预置 1天/7天/目标留存量历史与真实常驻上限，独立双位节拍，1/2窗+历史查询/日志/页面切换。测 gate 等待、快照实际耗时、UI排队/操作延迟、吞吐与最老队列；不能只测空闲。

### UI-03：无独立可验证的 UI 与业务进展监督闭环

**类型：证据不足和生产观测缺口；不是静态断言必崩。建议 P1 交付门槛。**

- `ParcelSnapshotValidity.cs:13-16,47-52` 有3秒 wallclock+monotonic失效机制；但其属性通知由同一 DispatcherTimer驱动。UI线程卡住后屏幕旧格口/旧状态不会因 getter内部时效检查自动重绘。
- 同一逻辑收到新的 snapshot只证明读取/投影完成，不能证明设备/业务在推进，需独立输入/接纳/结果账。
- 对 `src/`、`scripts/` 搜索 `DispatcherUnhandledException/UnhandledException/UnobservedTaskException/LocalDumps/ProcDump/MiniDump/watchdog` 无生产命中；也无独立窗口探针或原生挂起转储落盘流程。应用运行时健康监测有其保护，不应当成独立进程监测。
- 修复：有限额外观察者分开监测 UI调度、业务推进及后台worker、资源/存储；触发后保留线程/转储/事件日志并明确人工动作。观察者不控制设备、不自动重发、不以周期重启替代修复。
- 本子任务新增独立 `Collect-Win11Stability.ps1`：外部 WM_NULL粗探针+进程/文件规模指标。明确不能测精确Dispatcher或业务、永不自动PASS，当前Windows NOT_RUN。

### UI-04：关闭路径预算不覆盖全部 Dispose；日志任务所有权不完整

**类型：静态可达设计缺口；磁盘挂起/关闭竞争待验证。与 runtime agent 合并。**

- `SupplyStationWindow.xaml.cs:135-151` 与 `ShellWindow.xaml.cs:114-128` 先禁用窗口；UI drain 5秒，但随后 StopOwner没有外层期限。
- `Ipc.Desktop/ParcelApp.xaml.cs:144-149` 5秒 token只交给 StopAsync，随后 DisposeAsync无 token。
- `ParcelCommands.cs:263-265` 最后等 `RuntimeJournal.DisposeAsync()`；`RuntimeJournal.cs:43,103` ApppendAllTextAsync无取消，Dispose等worker。
- 磁盘/文件调用若长期不返回，关闭可能一直停在禁用窗口。这不说明正常磁盘必死锁；也不能“超时后照常释放租约”以制造双主。
- 软件日志 Query/Context/Export由 `ParcelAdministration.cs:31-36` 独立 Task.Run，但没有加入runtime的auxiliary或ViewModel pendingCalls。`SoftwareLogPage.cs:101,117-119` 页面卸载会取消，`SoftwareLogReader.Dispose`会取消/关闭查询stream；尚无await活动导出的统一排空。与有显式runtime aux跟踪的历史导出不同。
- 修复：完整I/O所有权、停止状态与失败收敛；关闭失败保留诊断和操作路径；停止仅取消等候不假称底层IO已结束。日志导出取消/完成/异常清理纳入应用或页面拥有的统一任务组。
- 必要测试：单独关窗时慢日志导出、磁盘写挂起/失败、取消清理；等待5秒后的状态能理解且未提前释放持久资源。Windows真实文件系统路径验证，非仅Task.Delay替身。

### OPS-01：当前 OS 运行指引与功能门禁冲突，目标运行条件未完整验证

**类型：静态证实冲突 + 目标条件证据不足；P1交付门槛/P2文档整改。**

- 当前实际 `WindowsClientCompatibility.cs:14-25`：原生x64、Windows内核10.0 build14393起可启动；19045/22000+为优先功能目标。新指南 `docs/runtime/windows-client-compatibility-01.md:3-25`说明Win10 22H2/Win11与厂商支持分开。
- 旧当前指南 `docs/runtime/windows-application-delivery.md:29`与 `scripts/application.ps1:15-16`仍为build26100+，脚本实际拒绝低于此值；原生GUI和显式高级脚本结果可能不一致。**本轮只记录，不改历史**。
- 原生性能环境为Windows11 Home build22631、.NET10.0.13、8 logical processors，非用户目标IPC；仓库说明该Home23H2已出支持期，主报告需以微软官方生命周期另核对。CI Windows Server2025也不等于Windows11终端资格（父审已实际核实日志）。
- 未找到生产当前指南明确规定锁屏、RDP断开/分辨率切换、休眠、电源恢复、维护更新重启窗口。窗口 `SetViewport` 有800×420保护并会请求Pause (`ParcelPresentation.cs:79-90`、窗口UpdateViewport)；显示环境变化可以合法触发业务暂停，必须实测/解释，不能当纯UI视觉变化。
- 最小条件：现场实际Edition/build支持期、硬件/磁盘/网卡与功耗、账户/ACL、SDK位数/版本/固件、扩展身份、更新维护政策、最小化/锁屏/RDP/跨屏矩阵。没有证据就标NOT_RUN，不自动关闭更新或安全防护。

## 现有保护有效的源码依据

|保护|路径与意义|边界|
|---|---|---|
|业务实例不随页切换重建|`Presentation.cs:9-14` 同一application传入；`SupplyStationWindow.xaml.cs:29-32,75-80`缓存页面；classic同理|未实际反复切窗做句柄趋势测试|
|轮询不重入|两个窗口的pendingRefresh.IsCompleted守卫|每窗独立，多个窗口可并发请求shared gate|
|UI服务调用在后台|`DesktopServiceCalls.cs:8-18`|日志接口前缀、展示偏好仍例外|
|异步迟到读取不覆盖新意图|`ParcelViewModel.cs:139-159`读取代次；`ParcelTargets.cs:59-96`历史代次/筛选签名|不能减少数据库完整查询成本|
|陈旧/错误状态不显示为有效任务|`ParcelSnapshotValidity.cs:13-34`；`SupplyStationViewModel.cs:145-153`同时核本位操作、观察Epoch/SourceEventId/AdmissionId、请求ID/payloadhash|UI卡住无法执行失效重绘；真实设备链另验|
|日志查询有界与权限保护|`SoftwareLogReader.cs:15-17,33-76,121-189`：最多4个selection、10分钟有效、每源16MiB、单行256KiB、200条页、上下文前后各200、regex单条25ms、查询20s、导出5min、原文件对象固定、不覆盖源|文件/同步权限检查不全可取消，扫描所有保留日志；不代表并发作业延迟已合格|
|历史读独立连接|`ParcelHistoryQuery.cs:124-154`后台读连接，Stop跟踪auxiliary|聚合全历史无时限/token，WAL读快照与磁盘竞争需规模验证|
|关闭保持资源责任|窗口停止timer/禁止重复Close，任务排空、失败不伪关闭|Dispose底层不可中断IO边界仍在|

## 原性能证据读回（不是本轮新测试）

来源 `docs/runtime/evidence/sportmaster-audit-remediation-01/performance-result.json` 的 SourceCommit/FixtureSourceCommit均 `934fd4af6a5b5587021892c0f9df169510115db8`，不是本轮 main。对应 `R02-performance.json` 记录：

|样本|值|可得结论|
|---|---:|---|
|300笔逐笔等待前一结果的输入到自身终态|P50 179.20ms，P95 662.49ms，P99 980.59ms，最大1419.97ms|合成单笔链延迟；不能算峰值吞吐或独立输入负载|
|快照 P50，0/50/199/300总作业|1.80/38.99/138.30/67.08ms|300时已归档199，常驻101；工作集会归档下降，不是单调无界增长|
|199常驻快照JSON|1,470,717字节|当前架构完整克隆具有显著分配成本|
|NativeRefresh 30次|P95 167.94ms，max178.88ms；23,052通知|旧原生窗口刷新有成本；无当前目标预算|
|1窗空闲实际24.043s|累计分配441,028,200 B；CPU2390.625ms；Private Bytes150,548,480→134,860,800|分配高但Private Bytes下降，不能报告已证明泄漏|
|2窗空闲实际24.286s|累计分配946,166,096 B；CPU5515.625ms；Private Bytes166,338,560→149,811,200|双窗成本升高；仍非长稳|
|UI heartbeat gap|1窗P99 67.04ms，max72.34；2窗P99 67.24，max70.08|包含50ms定时等待和量化；不是纯Dispatcher排队分布|

对应夹具 `tests/Ipc.Desktop.UiVerification/AuditPerformance.cs:35-55`逐笔发送并轮询至终态；`:109-130`空闲400×50ms采样且Limit明示非长期。原数据没有声称24小时，通过不能迁移到新main/真实SDK。

## 最少必要后验

1. 完整固定Release+交付组合+普通账户+Windows11具体build+目标IPC；TCP与真实SDK分别立项。当前基线每种路径先做短时自身结果/故障冒烟，不能跨驱动背书。
2. 修复共享gate与历史/日志可达阻塞后，双位独立时钟负载≥24小时；设置实测节拍、峰值和合理背压，交错历史查询/grep/上下文/导出/页面切换、双窗关闭。
3. 资源要比较预热后多个窗口的趋势，不仅首尾；基准包含正常高吞吐、空闲和可恢复故障后回落。以单位业务量字节增长/CPU成本及磁盘计划外推，单独标外推。
4. 独立恢复实验：管理服务故障、磁盘写失败/不足、日志查询取消、关窗停止、锁屏/RDP/最小化/显示变化；不把重启后的段接成连续通过。
5. 当前交付的采集器只提供外部粗UI与OS资源证据；精确Dispatcher、队列年龄、业务守恒仍必须补充，绝不因采集脚本跑完自动PASS。

## 官方工具资料

- https://learn.microsoft.com/en/dotnet/core/diagnostics/dotnet-counters ：附着现有PID、采集System.Runtime、输出CSV、同账户权限。
- https://learn.microsoft.com/en-us/sysinternals/downloads/procdump ：`-h`窗口至少5秒不响应、`-e`未处理异常、`-n`限制转储数；不用`-k`结束进程。

这两份官方文档本轮已联网查阅。父审若要采用网络引用ID，需自行open上述URL；代码与证据建议使用固定SHA GitHub永久链接。
