using System.Reflection;
using System.Threading.Channels;
using System.Diagnostics;
using System.Text.Json;
using System.Security.Cryptography;
using Ipc.Application.Contracts;
using Ipc.Application.ParcelFlow;
using Ipc.Application.Sportmaster;
using Ipc.Assembly;
using Ipc.Platform;
using Microsoft.Data.Sqlite;

class Program {
 const BindingFlags Hidden=BindingFlags.Instance|BindingFlags.NonPublic;
 static readonly string Repo="/workspace/scratch/4d42c7c75922/importer-pc-audit";
 static string Output="";
 static object? Field(object obj,string name)=>obj.GetType().GetField(name,Hidden)!.GetValue(obj);
 static async Task<ParcelSnapshot> Wait(ParcelRuntime app,Func<ParcelSnapshot,bool> pred) {
  for(int i=0;i<150;i++) { var s=await app.SnapshotAsync().WaitAsync(TimeSpan.FromSeconds(3)); if(pred(s))return s;await Task.Delay(20); }
  throw new Exception("Timed out waiting for synthetic runtime state");
 }
 static async Task Authorize(ParcelRuntime app) {
  var admin=(IWorkstationAdministration)app; string p="Audit-"+Guid.NewGuid().ToString("N");
  if(!(await admin.ManagementModeStatusAsync()).Configured) await admin.ConfigureManagementPasswordAsync(p);
  if(!await admin.EnterManagementModeAsync(p))throw new Exception("Synthetic management failed");
 }
 static BusinessLaunch Launch(string name) {
  var dir=Path.Combine(Output,name);Directory.CreateDirectory(dir);
  File.Copy(Path.Combine(Repo,"config/sportmaster/business.json"),Path.Combine(dir,"business.json"));
  return new(dir,Path.Combine(dir,"data"),null,null);
 }
 static ParcelRuntime Create(BusinessLaunch launch,IParcelCapabilityFactory factory) {
  var app=new ParcelRuntime(launch,new SportmasterFlow(),factory);
  typeof(ParcelRuntime).GetProperty("RuntimeIdentityPreflight",Hidden)!.SetValue(app,(Action)(()=>{}));
  return app;
 }
 static async Task<object> JournalProbe() {
  var launch=Launch("journal");await using var app=Create(launch,new ParcelCapabilityFactory(launch));
  await app.StartAsync(default);var before=await Wait(app,s=>s.Availability?.Admit==true);
  var journal=(RuntimeJournal)Field(app,"journal")!;
  int burst=5000; var sw=Stopwatch.StartNew();
  for(int i=0;i<burst;i++)journal.Write(new{At=DateTimeOffset.UtcNow,Event="IndependentAuditPressure",N=i,Detail="synthetic diagnostic burst; no business input"});
  var burstMs=sw.Elapsed.TotalMilliseconds;
  var blocked=await Wait(app,s=>s.BlockingReasons.Any(x=>x.Contains("journal queue full")));
  var queue=(Channel<object>)Field(journal,"queue")!;
  for(int i=0;i<500&&queue.Reader.Count>0;i++)await Task.Delay(10);
  var after=await app.SnapshotAsync();
  var pause=await app.CommandAsync(new(Wire.Id(),after.Revision,"Pause"));
  var paused=await app.SnapshotAsync();
  var resume=await app.CommandAsync(new(Wire.Id(),paused.Revision,"Resume"));
  var final=await app.SnapshotAsync();
  return new{BeforeAdmit=before.Availability!.Admit,Burst=burst,BurstMs=burstMs,QueueRemaining=queue.Reader.Count,
   Failure=Field(app,"failure"),Accepting=Field(app,"accepting"),AfterDrainedAdmit=after.Availability!.Admit,Pause=pause,Resume=resume,
   BothPositionsBlocked=final.Positions!.All(p=>!p.Admit),Snapshot=final.BlockingReasons,
   Interpretation="Synthetic metadata burst reproduces sticky global admission closure after log backlog clears. This does not measure field trigger frequency or justify dropping business events."};
 }
 static async Task<object> IngressProbe() {
  var launch=Launch("ingress");var factory=new DelayFactory(new ParcelCapabilityFactory(launch));var app=Create(launch,factory);
  typeof(ParcelRuntime).GetProperty("Boundary",Hidden)!.SetValue(app,(Action<string>)(point=>{if(point=="AfterRawDurable")throw new IOException("AUDIT-INJECTED single worker T3 interruption after durable first raw");}));
  await app.StartAsync(default);await Wait(app,s=>s.Availability?.Admit==true);
  bool first=app.EmitReferenceAt("left","audit-first","0001","audit-source-first");
  await factory.Entered.Task.WaitAsync(TimeSpan.FromSeconds(3));
  bool second=app.EmitReferenceAt("left","audit-queued","0002","audit-source-queued");
  var queues=(Dictionary<string,Channel<object>>)Field(app,"positionQueues")!;
  int queuedBeforeFailure=queues["left"].Reader.Count;
  factory.Release.TrySetResult();
  var failed=await Wait(app,s=>s.BlockingReasons.Any(x=>x.Contains("Application worker failed")));
  int queuedAfterFailure=queues["left"].Reader.Count;var pendingAfterFailure=Field(app,"pendingObservations");var activeDespiteFailure=app.HasActiveWork;
  var dbPath=Path.Combine(launch.DataRoot,"Simulation","reference-17","sportmaster","sportmaster.db");
  int Count(string sql) {using var db=new SqliteConnection("Data Source="+dbPath+";Mode=ReadOnly;Pooling=False");db.Open();using var cmd=db.CreateCommand();cmd.CommandText=sql;return Convert.ToInt32(cmd.ExecuteScalar());}
  int secondAudit=Count("SELECT count(*) FROM parcel_audit WHERE detail LIKE '%audit-queued%' OR detail LIKE '%audit-source-queued%'");
  int secondOperation=Count("SELECT count(*) FROM parcel_history_index WHERE admission='audit-queued'");
  string? disposalError=null;try{await app.DisposeAsync();}catch(Exception ex){disposalError=ex.GetType().Name+": "+ex.Message;}
  bool resourcesReleased=!app.HasUnreleasedResources;
  await using var restarted=Create(launch,new ParcelCapabilityFactory(launch));await restarted.StartAsync(default);var restart=await restarted.SnapshotAsync();
  int restartSecondAudit=Count("SELECT count(*) FROM parcel_audit WHERE detail LIKE '%audit-queued%' OR detail LIKE '%audit-source-queued%'");
  return new{FirstSourceEmit=first,SecondSourceEmit=second,QueueBeforeFailure=queuedBeforeFailure,QueueAfterFailure=queuedAfterFailure,PendingAfterFailure=pendingAfterFailure,
   FailedState=failed.State,HasActiveWorkDespiteOneFailedWorker=activeDespiteFailure,SecondAuditRows=secondAudit,SecondOperationRows=secondOperation,
   DisposalError=disposalError,ResourcesReleased=resourcesReleased,SecondAuditRowsAfterRestart=restartSecondAudit,
   RestartOperations=restart.Operations.Select(o=>new{o.AdmissionId,o.State,Wcs=o.Wcs?.State}).ToArray(),RestartReasons=restart.BlockingReasons,
   Interpretation="Second source callback returned true and occupied RAM queue, but was never business-admitted. Worker exit leaves it without a durable per-input accepted/rejected/pending record; after restart it is absent. First raw is recovered locally. Does not claim a business-admitted second entity was lost."};
 }
 static async Task Main(string[] args) {
  Output=args[0];if(Directory.Exists(Output))throw new Exception("Choose a new output directory");Directory.CreateDirectory(Output);
  var start=DateTimeOffset.UtcNow;var sw=Stopwatch.StartNew();
  var result=new{SourceCommit="c91559f6f981a9f2c9f89bd5afc271089f0e9d8e",StartedUtc=start,Scope="Linux .NET10 Release; compiled production DLLs; synthetic manual readers/reference service only; not TCP/Hikrobot/RCS/WPF/Win11 or soak",
   Journal=await JournalProbe(),Ingress=await IngressProbe(),EndedUtc=DateTimeOffset.UtcNow,DurationSeconds=sw.Elapsed.TotalSeconds,
   Runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,OS=System.Runtime.InteropServices.RuntimeInformation.OSDescription,
   Assemblies=AppDomain.CurrentDomain.GetAssemblies().Where(a=>a.GetName().Name!.StartsWith("Ipc.")).Select(a=>new{Name=a.GetName().Name,Path=a.Location,Sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location)))}).ToArray()};
  var text=JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true,Converters={new System.Text.Json.Serialization.JsonStringEnumConverter()}});File.WriteAllText(Path.Combine(Output,"result.json"),text);Console.WriteLine(text);
 }
 sealed class DelayFactory(ParcelCapabilityFactory inner):IParcelCapabilityFactory {
  public TaskCompletionSource Entered{get;}=new(TaskCreationOptions.RunContinuationsAsynchronously);
  public TaskCompletionSource Release{get;}=new(TaskCreationOptions.RunContinuationsAsynchronously);
  public ParcelConfiguration Normalize(ParcelConfiguration c)=>inner.Normalize(c);
  public void Validate(ParcelConfiguration c)=>inner.Validate(c);
  public ParcelPorts Create(ParcelConfiguration c){var p=inner.Create(c);return p with{Wcs=new DelayedWcs(p.Wcs!,Entered,Release)};}
  public ValueTask DisposeAsync()=>inner.DisposeAsync();
 }
 sealed class DelayedWcs(IWcsPort inner,TaskCompletionSource entered,TaskCompletionSource release):IWcsPort {
  public string InstanceId=>inner.InstanceId;
  public Task StartAsync(CancellationToken t)=>inner.StartAsync(t);
  public Task<CapabilityHealth> HealthAsync(CancellationToken t)=>inner.HealthAsync(t);
  public Task ReconnectAsync(CancellationToken t)=>inner.ReconnectAsync(t);
  public async Task<StageReply> ResolveSlotAsync(FrozenRequest r,CancellationToken t){entered.TrySetResult();await release.Task.WaitAsync(TimeSpan.FromSeconds(3));return await inner.ResolveSlotAsync(r,t);}
  public Task<StageReply?> QueryAsync(FrozenRequest r,CancellationToken t)=>inner.QueryAsync(r,t);
  public Task StopAsync(CancellationToken t)=>inner.StopAsync(t);
  public ValueTask DisposeAsync()=>inner.DisposeAsync();
 }
}
