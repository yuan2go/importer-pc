# Runtime / Storage 风险—证据—缺失证据（固定 c91559f6）

|风险/主张|当前代码/已有证据|本轮必要验证|剩余边界|
|---|---|---|---|
|诊断队列瞬时满可停整个业务且无法 Resume|RuntimeJournal.cs:8,102 容量256/TryWrite失败回调；ParcelRuntime.cs:103 failure非空并accepting=0；ParcelGuards.cs:7-9/26 关闭左右准入；未找到运行中清failure路径|独立RuntimeJournal突发或受控日志锁探针，再核运行同一回调路径|触发所需真实节拍/磁盘慢时间需Windows实测；不声称正常低负载必发生|
|已入队输入在该位worker持久化异常时无逐笔去向|ParcelRuntime.cs:237-245只入内存队列；247-277异常退出worker，不排空未处理队列/逐笔拒绝；Stop在ParcelCommands.cs:220-244仅complete/await，不处理faulted reader剩余项|合成首笔RCS延迟，入队第二笔，再在AfterRawDurable注入IOException，检查第二笔InputObserved/责任缺失|属于入队接收而非业务Admitted；进程强杀丢内存更是未验；不得把接口返回true解释为业务完成|
|正常累计件数耗尽MaximumOperations|当前实现已修复：ParcelHistory.cs:182-193按未归档责任计数；终态自动归档，ResidentHistory默认200|复用已有AQ04必要断言；无需再次编造总件数10000停机测试|完整历史和所有审计仍一直增加；磁盘容量另算|
|快照成本随resident及归档/命令规模增加|SnapshotAsync持gate (ParcelCommands.cs:7-44)，反复遍历resident/PendingReceipts；ArchivedCount count(*) (ParcelHistory.cs:81-82)，PendingCommands json_extract无索引 (Repository:376-380)；旧R02仅300件、同位闭环节拍|SQL query plan与合成5k/50k/100k规模计时；只证明查询机理，不能冒充Windows/.NET应用指标|目标硬件、大库实际快照P99、业务队列age与UI延迟|
|历史搜索/统计耗时及WAL读事务|ParcelHistoryQuery.cs:26-27独立连接+读事务；Source/Conditions JSON predicates34-38；Metrics62-69全匹配聚合，无取消；ReadHistoryAsync130-143无并发上限；Export2min只在Page之间检查取消|同上SQL规模；多读/取消/低速磁盘需Windows验证|脱离gate有效，不能直接说历史查询同步卡UI；I/O与WAL竞争仍共享|
|原始账无限增长最终磁盘保留阻断|Archive同库保存原JSON/raw、永久身份/审计；ParcelStorageCapacity:10-20一秒刷新，默认MinimumFreeBytes64MiB|只核容量守卫及实测单位件数据成本，剩余天数采用明确假设|完整恢复集迁卷是当前设计，不能清库恢复；必须现场给磁盘/保留期预算|
|无人值守自动备份不执行|ParcelScheduledBackup:28要求Paused+ManagementAuthorized+externalWaits==0；在gate内同步CreateBackup；到期且运行时仅Pending|静态可证；不必要重跑已有备份一致性验证|需用户定义业务连续运行与可批准维护窗口；现实现不应标为24小时运行中自动备份|
|启动成本随全部历史增长|Repository构造96-97每次RepairTerminalRecoveryFlags/InitializeIntegrationRequestHistory；IntegrationIds:71-77全量UpgradeOperations/逐笔核对owners；History:16-28全历史JSON验证；ValidateRawInventory289-307每raw/archive读哈希|SQL规模探针+后续原生10万/100万历史冷启动|非steady-state泄漏；恢复时长/启动预算尚未给定|

更新：日志粘滞全局阻断与worker故障遗留入队输入已由probe-run-02复现；HasActiveWork仍true也已复现。SQL规模原始结果见sql-scale-result.json。详见findings.md；其余Windows/真实设备长稳仍NOT_RUN。
