"""Read-only-source SQL experiment. Synthetic rows; not an application/Win11 soak."""
from pathlib import Path
import sqlite3,json,time,datetime,hashlib,re,platform,os
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/scratch/4d42c7c75922/importer-pc-audit')
path=ROOT/'synthetic-scale.db'
if path.exists(): raise RuntimeError('Use a new evidence directory; preserve existing output')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
source_path=REPO/'src/Ipc.Application.ParcelFlow/ParcelRepository.cs'
source=source_path.read_text()
migrations=re.findall(r'new\((\d+), """\n(.*?)\n\s*"""\)',source,re.S)
assert len(migrations)==8,len(migrations)
db=sqlite3.connect(path)
db.execute('PRAGMA journal_mode=WAL')
db.execute('PRAGMA synchronous=FULL')
for version,sql in migrations: db.executescript(sql)
source_join=' FROM parcel_history_index h JOIN (SELECT id,body,NULL AS hash,0 AS archived FROM parcel_operations UNION ALL SELECT id,body,body_hash,1 FROM parcel_archives) o ON o.id=h.id '
conditions=" WHERE h.seq<=$upper AND ($code IS NULL OR json_extract(o.body,'$.ParcelCode')=$code) AND ($position IS NULL OR h.position=$position) AND ($state IS NULL OR json_extract(o.body,'$.State')=$state) AND ($from IS NULL OR julianday(json_extract(o.body,'$.ObservedAt'))>=julianday($from)) AND ($to IS NULL OR julianday(json_extract(o.body,'$.ObservedAt'))<julianday($to)) AND ($request IS NULL OR json_extract(o.body,'$.Wcs.Request.Id')=$request OR json_extract(o.body,'$.Plc.Request.Id')=$request OR json_extract(o.body,'$.Upload.Request.Id')=$request OR json_extract(o.body,'$.Capture.Request.Id')=$request)"
metrics="SELECT count(*),coalesce(sum(json_extract(o.body,'$.Wcs.Request.Id') IS NOT NULL),0),coalesce(sum(json_extract(o.body,'$.Wcs.State')='Accepted'),0),coalesce(sum(json_extract(o.body,'$.Wcs.State')='Unknown' OR json_extract(o.body,'$.Plc.State')='Unknown' OR json_extract(o.body,'$.Upload.State')='Unknown' OR json_extract(o.body,'$.Capture.State')='Unknown'),0),coalesce(sum(json_extract(o.body,'$.State')='PhysicalCompleted'),0),coalesce(sum(coalesce(json_extract(o.body,'$.Wcs.Attempts'),0)+coalesce(json_extract(o.body,'$.Plc.Attempts'),0)+coalesce(json_extract(o.body,'$.Upload.Attempts'),0)+coalesce(json_extract(o.body,'$.Capture.Attempts'),0)),0)"+source_join+conditions
page="SELECT h.seq,o.archived,o.body,o.hash"+source_join+conditions+" AND h.seq<$before ORDER BY h.seq DESC LIMIT $limit"
queries={
 'archive_count':('SELECT count(*) FROM parcel_archives',{}),
 'history_metrics_all':(metrics,dict(upper=999999999,code=None,position=None,state=None,**{'from':None,'to':None,'request':None})),
 'history_page_missing_barcode':(page,dict(upper=999999999,code='NEVER_MATCH',position=None,state=None,**{'from':None,'to':None,'request':None,'before':999999999,'limit':51})),
 'pending_commands_none':("SELECT id FROM parcel_commands WHERE json_extract(receipt,'$.Status')='Pending' ORDER BY rowid DESC LIMIT 32",{}),
 'startup_recovery_required_none':("SELECT id,body,body_hash FROM parcel_archives WHERE id>$after AND json_extract(body,'$.RecoveryRequired')=1 ORDER BY id LIMIT 1",{'after':''}),
}
plans={name:list(db.execute('EXPLAIN QUERY PLAN '+sql,args)) for name,(sql,args) in queries.items()}
rows=[]; existing=0
for n in [5000,50000,100000]:
 tic=time.perf_counter()
 for i in range(existing,n):
  ident=f'{i:032x}'; position='left' if i%2==0 else 'right'
  body=json.dumps({'Id':ident,'ParcelCode':f'{i:016d}','PositionId':position,'State':'SlotResolved','ObservedAt':'2026-10-24T00:00:00+00:00','RecoveryRequired':False,'Wcs':{'State':'Accepted','Attempts':1,'Request':{'Id':'r'+ident,'IntegrationRequest':{'RequestId':i+1}}},'FrozenConfiguration':{'SyntheticPadding':'p'*1024}},separators=(',',':'))
  db.execute('INSERT INTO parcel_archives VALUES (?,?,?,?,?,?)',(ident,'a'+ident,'o'+ident,body,hashlib.sha256(body.encode()).hexdigest(),'2026-10-24T00:00:00+00:00'))
  db.execute('INSERT INTO parcel_history_index(id,admission,observation,position) VALUES (?,?,?,?)',(ident,'a'+ident,'o'+ident,position))
  # Command-volume experiment is distinct: 1 synthetic completed command per operation,
  # not a statement about production command/event frequency.
  db.execute('INSERT INTO parcel_commands VALUES (?,?,?)',(ident,'hash',json.dumps({'Status':'Persisted','Reason':'synthetic completed command','Revision':i})))
 db.commit(); existing=n
 insert_s=time.perf_counter()-tic
 measures={}
 for name,(sql,args) in queries.items():
  samples=[]; count=0; result=None
  for _ in range(5):
   tic=time.perf_counter(); result=list(db.execute(sql,args)); samples.append((time.perf_counter()-tic)*1000)
  measures[name]={'samples_ms':samples,'median_ms':sorted(samples)[2],'max_ms':max(samples),'rows_returned':len(result),'scalar':result[0][0] if result and name in ['archive_count','history_metrics_all'] else None}
 rows.append({'synthetic_archives':n,'synthetic_completed_commands':n,'insert_seconds':insert_s,'database_bytes':path.stat().st_size,'wal_bytes':Path(str(path)+'-wal').stat().st_size,'queries':measures})
 print(json.dumps(rows[-1]),flush=True)
result={'source_commit':'c91559f6f981a9f2c9f89bd5afc271089f0e9d8e','started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':platform.python_version(),'sqlite':sqlite3.sqlite_version,'os':platform.platform(),'scope':'Synthetic exact-migration / query-shape SQLite experiment on Linux/Python; NOT .NET/Win11/24-hour application run. Operation bodies contain artificial padding; storage bytes are NOT production bytes per operation. Command count experiment uses independent artificial completed-command volume. Sequential query timings; no field load or concurrency.','source_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),'plans':plans,'datasets':rows}
(ROOT/'sql-scale-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
db.close()
