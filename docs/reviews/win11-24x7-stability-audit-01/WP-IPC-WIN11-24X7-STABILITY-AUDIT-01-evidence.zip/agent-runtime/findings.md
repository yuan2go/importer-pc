# Runtime / Storage 独立审查结果

基线：`c91559f6f981a9f2c9f89bd5afc271089f0e9d8e`。本文件只记录此次只读审查；未修改生产源码、既有测试或历史证据。源码文件路径均相对此固定仓库。父审查应把本文件与驱动、WPF、交付环境结论合并。

## 结论

运行时/存储部分**存在需要修复的代码阻断**，并非仅缺少24小时证据。两个独立合成故障探针复现：诊断队列一次积压导致双位准入永久关闭；一个已成功进入内存队列但未业务准入的输入，在同位工作线程持久化故障后被遗留，正常释放并重启后无逐笔去向。前者影响可恢复性，后者违反本次任务的“每笔输入有可核对接纳、拒绝、完成或未决去向”门槛。

这不等于宣称已验证的每笔业务实体会丢失。发生故障的首笔业务原件被正确保留，重启后本地恢复为 `SlotResolved`；未盲目重发。`failure` 可由快照读到，不能写成“后台死亡完全无人发现”；但 `HasActiveWork` 在一位worker已fault、另一位等待时仍为true，不能作为业务健康证明。

## 实际链路与锁/资源所有权

|环节|实际实现与约束|传播边界|
|---|---|---|
|驱动回调入口|ObservationSession:23–35以设备/epoch过滤；ParcelRuntime:220–245在`overloadSync`内复制有界候选并`TryWrite`，默认每位64|正常入队不等待RCS；满队列同步持久化overload marker，慢磁盘会卡回调|
|同位处理|ParcelRuntime:247–277每位独立worker；取出项后获取全局`gate`，同位串行|存储/投影共用gate；一个worker非预期异常把全局accepting清零|
|新输入判定|Runtime:279–337检查注册/时效、永久身份、重复/冲突、健康、准入及容量；`InputObserved`与实体一起入事务|旧epoch/重复不产生新外呼；排队超龄输入明确Rejected；新输入失败不借旧格口|
|RCS/其他外部调用|Stages:25、50–57，经ExternalPortAsync/ExternalAsync释放gate，冻结请求；T2先持久化，调用结束重新取gate|网络等待不独占业务gate；共享RCS健康影响两个依赖位；同位仍等待其自身结果|
|T3与原件|Repository:261–282原回执FileStream WriteThrough/Flush后更新RawDurable；Stages:83–94保存原件再ApplyReply与事务提交|DB/文件I/O在业务gate内，慢磁盘影响两位和快照；保持未知责任而不假成功|
|状态快照|Commands:7–44在gate内检查守卫、查最新记录/容量、整对象JSON encode/decode|后台读取仍竞争同一gate；不是纯内存无锁只读快照|
|历史/导出|HistoryQuery:130–156取得路径后Task.Run+独立只读连接/事务；export有2分钟、10万条、64MiB预算|不会长时间占业务gate；共享磁盘与WAL读事务仍可能影响运行；单条SQL没有取消|
|维护/备份|Guards:72–85每100ms取得gate后处理过期、归档、容量、overload与备份；ScheduledBackup:28要求暂停+管理授权|后台维护不是独立于协调锁；运行中计划备份只保持Pending|
|停止|Commands:198–267先关准入、取消、停来源、Complete队列、等worker/auxiliary/external，再停/释放ports/DB/leases|超时保留所有权防双活有效；faulted reader遗留项无排空/记录路径；Dispose最终无deadline|

## 主要问题（按影响排序）

### RT-01：故障工作线程遗留已接收的内存输入（建议P0，已复现）

**触发**：同位第一笔正在RCS阶段，第二笔已通过驱动callback返回true进入Channel；第一笔在原始回执已经落盘、T3前发生IOException。

**路径**：`ParcelRuntime.cs:237–245`只入内存；`:247–277`异常退出整个本位worker，catch只记录failure并全局关闭接收；`ParcelCommands.cs:220–267`只Complete/等待worker，再释放资源，没有处理该faulted reader队列中的剩余项。

**本轮证据**：`probe-run-02/result.json` 中 `FirstSourceEmit=true`、`SecondSourceEmit=true`；故障前后队列均1，`PendingAfterFailure=1`；第二笔 `parcel_audit=0`、`parcel_history_index=0`；Dispose报告终结错误但`ResourcesReleased=true`；重启后第二笔仍为0条账，只有第一笔被正确恢复。第二笔**并未被业务Admitted**，应准确称“来源接收/内存入队后未有逐笔持久去向”。

**业务后果**：操作员无法从恢复账回答该输入到底处理、拒绝还是待重扫，不能保证完整复盘。强杀/断电前的未落账窗口也是同类缺口，但本轮没有另做强杀实验。

**修复边界**：复用现有输入事实与恢复机制，明确“来源接收”和“持久准入”语义；故障围栏后将已排队输入转成可追踪拒绝/未决，并保留具体事件/来源范围。无法写账时应保留显式未清偿责任并禁止声称已完成排空；需要跨进程终止保证时必须设计有界持久接收责任，结合实际协议的确认/回压能力，不可以增加第二套业务状态机或把丢弃叫恢复。未知请求不能重发。

**必要验收**：复用该两笔故障探针；在首笔T1/T2/raw/T3关键边界检查所有源输入去向、同位队列排空与恢复；已落raw本地恢复且无网络重发。回退保留原账及未决，新迁移须显式兼容；不能删queue/删库恢复。

### RT-02：普通诊断队列满导致全局永久阻断（建议P1，已复现）

**触发**：日志写入短时慢、普通信息/异常日志爆发，256条诊断队列满。

**路径**：`RuntimeJournal.cs:8,102` TryWrite失败调用failure；`ParcelRuntime.cs:103`把`failure`设为错误并`accepting=0`；`ParcelGuards.cs:7–9,26`同时阻断双位；不存在运行中清除该failure/重新打开accepting的路径。

**本轮证据**：对真实RuntimeJournal注入5000条合成metadata突发。此前Admit=true，排空后QueueRemaining=0，但Accepting仍0、Admit=false，两个位均拒绝。Pause命令持久化成功，Resume被守卫拒绝。见 `probe-run-02/result.json`。这证明触发后的语义，**不证明5000/ms是现场可信负载**，真实触发概率仍需目标磁盘/节拍验证。

**修复方向**：区分必须持久的业务审计与允许有界降级的运行诊断；若某类诊断失败要求停机，应有持久可解释原因、恢复核验和受控恢复，不能用一个不可复位字符串永久锁死全部业务。普通高频重复metadata可有界聚合/限流且保留计数与首末时间；不得吞掉业务事件、异常根因或未决责任。

### RT-03：满队列故障路径把同步磁盘I/O带入双位共用回调锁（建议P1，静态证实）

`ParcelRuntime.cs:220,239–244`在`overloadSync`内持久化marker；`ExtensionStore.cs:31–37`是同步WriteThrough+Flush(true)+Move。`ParcelGuards.cs:78–80`维护线程取得全局gate后调用`RecoverOverloadAcknowledgement`；`ParcelOverload.cs:9–10,15–18`也等待overloadSync/读磁盘。

单侧队列满叠加慢/挂磁盘，可依次阻塞原SDK/TCP callback、另一位入队及持gate的维护，最终连快照也被延迟。这不是已证实的锁环死锁，是明确可达的无界I/O阻塞传播。已有ResourceRisks证明“满队列不等待WCS”，没有覆盖marker落盘的慢I/O。

建议把“立即在内存围栏关闭相关准入”与“有界持久化故障责任”分离，回调不能持共用锁做Flush；持久化失败应保留原责任、明确升级与诊断，不能丢弃marker。只需新增慢marker/失败marker定向测试与另一侧响应/原件核对。

### RT-04：快照与历史查询仍有规模相关成本（建议P1容量门槛，静态+SQL实验；不是内存泄漏证明）

- Snapshot在gate内反复计算CapacityAvailable/ArchiveEligible；`ParcelHistory.cs:182–186`按resident逐项查`PendingReceipts`，后者有state索引，**不能误称每次全历史扫描**。但重复SQL与JSON克隆的成本明显受resident影响。
- `ParcelHistory.cs:81–82`每快照count全部归档；`ParcelRepository.cs:376–380`每快照用JSON状态过滤完成命令表，未有适配索引。独立SQL plan显示命令表扫描。
- `ParcelHistoryQuery.cs:34–38,62–69`把全部resident/archive JSON与历史索引join后按JSON字段筛选、汇总；无条码/时间/状态的结构化查询索引。`ReadHistoryAsync:130–143`没有取消参数、查询deadline或全局并发上限。历史读tx从构造持续到Page/Metrics/Export结束（:23–27,119），大/慢查询可持WAL读视图。
- Export虽然有两分钟预算（:81），单次Page为同步SQL（:89），只有Page返回后才能观察取消，不是底层SQL硬超时。

**SQL微实验**：使用该仓库8份原迁移SQL，在Linux Python SQLite **3.53.1**建立人工JSON历史，分别5k/50k/100k归档。相同查询形状全量Metrics中位为63.35/752.23/1463.85ms；无匹配条码Page为8.88/91.04/178.92ms；独立10万条完成命令Pending扫描39.08ms；10万归档count约0.98ms。查询计划与5次原始样本保存在`sql-scale-result.json`。这些不是Win11/.NET包指标；fixture有人工padding，不能拿数据库体积算真实每件成本。Count当前量级并非主热点，不应优先做无依据优化。

**建议**：先在实际目标设备给最大历史量与响应预算，再对实际热点增加版本化结构索引/增量计数，减小运行快照到当前位与必要责任，并保持详情按需；新增有界查询、取消与并发预算、WAL/磁盘监测。避免以全量快照/计数频繁扫描历史；保留完整原件与稳定筛选边界。

### RT-05：原账永续增长与备份运维尚无给定容量闭环（建议P1交付条件，静态证实）

默认`ResidentHistory=200`、`MaximumOperations=10000`、每位queue64、`TimeoutMs=1500`、磁盘reserve64MiB（`SystemParameterDefaults.cs:6–8`、`config/sportmaster/business.json:36–38,81–83`）。

`ParcelHistory.cs:118–175`归档在同一DB保留完整作业JSON、回执raw及永久身份；原审计/已完成命令继续累积。这有利于责任追溯，**不是磁盘回收**。容量监测每秒更新，低reserve关闭准入/Resume（StorageCapacity:10–20）。默认64MiB只是技术值，不足以证明现场WAL/故障爆发/恢复预算。

当前运维设计明确通过完整恢复集迁到更大卷保持历史（`docs/runtime/architecture-quality-closure-01.md:16–22`），没有受批准自动删除责任数据策略。可运行时长应按 `可用增长空间/(每件实测增量×双位总件/秒×86400 + 日固定增量)`算，并扣备份、WAL最坏增长和系统余量。本轮没有足够真实单位件数据，不能给“可运行多少天”实测结论。

计划备份并非无人值守业务运行中备份：`ParcelScheduledBackup.cs:28`只有Paused+管理授权+externalWaits==0才执行；运行24小时不进入该窗口，过期计划一直Pending。达到MaximumSets时保留全部备份并报容量失败，不轮换删除（:34–45）。必须在交付说明中约定可批准维护窗口、备份完成监督、恢复演练和迁卷预算。

### RT-06：启动/恢复成本随历史增长；一次性的历史修复在每次启动重扫（建议P2，静态证实）

`ParcelRepository.cs:96–97`每次打开库调用RepairTerminalRecoveryFlags、InitializeIntegrationRequestHistory；`ParcelTerminalRecovery.cs:76–121`对JSON RecoveryRequired全量寻找；`ParcelHistory.cs:16–28`全历史数值ID验证；`ParcelIntegrationIds.cs:71–77`遍历UpgradeOperations反序列化全部历史并逐项核对永久IDowner；`:22–31`再读历史binding；`Repository.cs:288–307`逐件检查回执原件。这些大部分流式有界，不是把全部历史放进内存，但冷启动恢复时间无规模预算。

应按真实大库验证启动恢复时间，迁移/完整完整性复核与日常启动快速检查有证据地分层，不能跳过原责任/损坏核验。若保持全量扫描，应明确启动最长时长、进度与独立监督，不能把几秒空库启动推广到数百万件。

### RT-07：后台聚合存活指标不足（建议P1，已复现）

`ParcelRuntime.cs:57,160`以Task.WhenAll未完成来表示HasActiveWork。当左worker异常、右worker仍等Channel时仍true。本轮故障探针已复现。可见failure与Blocked守卫有效，应保留并加入每位任务终态/最后进展/队列年龄，而不是只展示聚合任务是否完成。

### RT-08：最终Dispose无deadline，挂起I/O可拖住关窗（建议P1/P2，静态证实）

`ParcelCommands.cs:248–265`Dispose用CancellationToken.None重做Stop并等待RuntimeJournal；`RuntimeJournal.cs:43,103`日志append不带token，Dispose等worker。慢/卡住的文件I/O可导致关窗无限等待。不要用超时后释放仍在使用的资源来“修复”，应有明确未停妥状态、隔离诊断与操作规则。WPF子审查另提供窗口禁用传播链。

## 已确认有效的保护，不能误报为仍存在的旧问题

1. **MaximumOperations不是总历史额度。** `CapacityAvailable`只计不可归档责任；终态按高水位自动归档，默认200resident。已有AQ04测试明确验证小容量连续新实体。保留字段名易误导，但“正常累计10000件必停”不成立。
2. 同位单worker有序；双位独立队列；外部调用期间释放aggregate gate，单个RCS网络等待不必拖另一位。共享RCS/存储故障影响双位是实际依赖关系。
3. 新输入冻结自身原配置/请求、T2先落发送尝试，raw durable后T3；请求ID/内容/响应身份校验、旧epoch隔离、历史身份索引永久保留；未知不自动重发。探针首笔raw恢复证明一条真实保护有效。
4. 停止超时保留port/database/lease所有权，避免另一个owner双活；不能把有意保留资源直接判为泄漏。需要明确未停妥与有界监督。
5. 日志约4个5MB轮转文件，查询最多4个10分钟selection，单文件16MiB、单行256KiB、页200、正则25ms、查询20s、导出5min，并保持源文件对象与权限检查。这些是实际边界，不能说日志查询完全无界。
6. 历史分页/CSV导出与主业务gate分离，并有稳定UpperSequence和导出回执；其剩余问题是SQL大规模成本/取消与I/O，不是把导出全放UI线程。
7. SQLite WAL、FULL同步、busy_timeout=5000、pooling=false、事务与同库原账明确，备份调用SQLite备份API而非直接复制活动DB。

## 本轮执行证据与限制

- `probe-run-01`：执行0.8665秒、进程退出0；应用内部0.7718秒。发现报告中`HasActiveWork`在Dispose后取值，不能据该字段作健康结论；原证据完整保留。
- `probe-run-02`：只修正上述采样时机及枚举文字，复跑同一小探针；05:40:44.502Z–05:40:45.323Z，进程0.8211秒、退出0，应用内部0.7178秒。UTC+8为13:40。没有重跑其他不相关套件。
- `probe/build-2.log` / `build-3.log`：隔离探针Release构建成功0警告0错误。最初build.log失败是未配置DOTNET_CLI_HOME导致根目录只读，已经改为探针独立目录；不是产品构建失败。
- 所加载12个Ipc程序集（含Verification测试程序集）与父代理冻结基线Release输出逐项SHA256相同：`loaded-dll-source-comparison.json`。生产源码无改动。
- SQL规模微实验：05:38:32.507Z–05:38:50.117Z，约17.61秒；Python SQLite3.53.1，人工预置数据，不能折算成运行天数或宣称同等业务负载。
- Windows11/WPF实际负载、真实TCP/海康SDK/RCS、目标硬件、24h/72h、磁盘挂起、WAL在真实并发下峰值仍 **NOT_RUN**。

## 修复工作包建议

|优先|修改边界|验收|回退|
|---|---|---|---|
|P0 输入故障闭环|现有Enqueue/ProcessIngress/Stop及InputObserved责任链，必要时追加受控持久接收协议|两个输入T3故障与受控Stop/重启后逐笔可核对；无未知重发，无错格口，无静默丢队列|保留旧原件；若schema变化须正式迁移、备份与旧读者拒绝，不回滚业务事实|
|P1 诊断与存储故障隔离|RuntimeJournal故障分类、bounded metadata、业务可恢复故障状态；overload marker写入所有权|日志突发排空后正确恢复或明确可操作恢复；慢marker不能阻塞两位callback及全局gate；业务审计责任保留|开关只能控制已定义诊断策略，不能绕过业务持久化；保留旧日志/故障原件|
|P1 有界运行投影/查询|Snapshot最小事实、容量/未决索引、历史查询执行取消/并发预算、WAL可观测性|目标resident与10万/百万历史（规模由现场保留期决定）下P99/UI/输入排队满足预算，导出取消和跨日不压死业务|版本化DB迁移；原API/字段兼容；停止相关新查询功能可回退，不能丢历史|
|P1 交付容量与备份|文档先澄清“归档不是回收”“计划备份须维护窗口”，再实现已确认的备份政策/报警|按实测每件增量给磁盘余量与维护时限；完整恢复演练，无双活、无自动重发|保留全部旧恢复集及SourceCommit；迁卷先验证再切换|
|P1 任务监督与停机诊断|每位worker终态/进度/queue age、日志/存储任务health、独立dump监督与关窗状态|故障后能区分活进程/死worker/阻断/挂起；超时保留所有权但界面能解释下一步|监督故障不能成为新的无界队列/刷盘热点；不使用定时重启掩盖|

后续修改前更新过期当前指引，保留本报告及历史原证据身份；测试仅覆盖这些实际改动与关键恢复边界。


最终复核限定：探针RuntimeIdentityPreflight为隔离no-op，manual/reference端口，不覆盖生产启动身份门禁。R01是AfterRawDurable合成故障；真实T3/原件存储异常进入同一消费者退出路径由静态代码确认，真实磁盘故障NOT_RUN。直接runtime.Dispose报告终结错误并释放，不等于WPF首次关窗验证。R02恢复需结束并新建实例，不能绝对称必须重启进程。余量检查至少间隔1秒，实际受gate/I/O影响，非1秒发现SLA。
