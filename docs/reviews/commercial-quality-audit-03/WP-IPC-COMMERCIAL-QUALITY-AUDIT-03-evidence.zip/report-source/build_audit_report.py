from pathlib import Path
import json, re, hashlib, html, subprocess, datetime
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents

ROOT=Path('/workspace/scratch/56081ee5bcf2')
REPO=ROOT/'importer-pc-audit03'
OUT=ROOT/'output/pdf/WP-IPC-COMMERCIAL-QUALITY-AUDIT-03.pdf'
WORK=ROOT/'audit03-work'
SHA='ec698bd4e11d06c13c097c77f90cc5ce145ab3ea'
RELEASE='21e6cae3c9e20f34fc9429812e48e7f95e455fb9'
ZIPHASH='54ce02ece4e88dd352687f446d72448f4fda2cabc16cf9e11e47a616e01c97a1'
BASE='https://github.com/yuan2go/importer-pc/blob/'+SHA+'/'
FONT=WORK/'root/fonts'
pdfmetrics.registerFont(TTFont('NotoSC',str(FONT/'NotoSansSC-Regular.ttf')))
pdfmetrics.registerFont(TTFont('NotoSCBold',str(FONT/'NotoSansSC-SemiBold.ttf')))
pdfmetrics.registerFontFamily('NotoSC',normal='NotoSC',bold='NotoSCBold',italic='NotoSC',boldItalic='NotoSCBold')
INK=colors.HexColor('#192C3D'); TEAL=colors.HexColor('#176676'); LIGHT=colors.HexColor('#ECF3F5'); GREY=colors.HexColor('#5E6F7C')
W,H=A4; M=43; CW=W-2*M
sty={
 'body':ParagraphStyle('body',fontName='NotoSC',fontSize=9.1,leading=14.1,textColor=INK,spaceAfter=6,wordWrap='CJK'),
 'small':ParagraphStyle('small',fontName='NotoSC',fontSize=7.6,leading=11.4,textColor=GREY,spaceAfter=5,wordWrap='CJK'),
 'table':ParagraphStyle('table',fontName='NotoSC',fontSize=8,leading=12.2,textColor=INK,wordWrap='CJK'),
 'th':ParagraphStyle('th',fontName='NotoSCBold',fontSize=8.1,leading=12.3,textColor=colors.white,wordWrap='CJK'),
 'h1':ParagraphStyle('h1',fontName='NotoSCBold',fontSize=17,leading=24,textColor=INK,spaceBefore=0,spaceAfter=13,keepWithNext=True,wordWrap='CJK'),
 'h2':ParagraphStyle('h2',fontName='NotoSCBold',fontSize=11.5,leading=17,textColor=TEAL,spaceBefore=9,spaceAfter=7,keepWithNext=True,wordWrap='CJK'),
 'cover':ParagraphStyle('cover',fontName='NotoSCBold',fontSize=27,leading=38,textColor=INK,spaceAfter=19,wordWrap='CJK'),
 'label':ParagraphStyle('label',fontName='NotoSCBold',fontSize=10,leading=15,textColor=TEAL,spaceAfter=10),
 'toc':ParagraphStyle('toc',fontName='NotoSC',fontSize=9.6,leading=18,textColor=INK,leftIndent=0,firstLineIndent=0,spaceBefore=6,wordWrap='CJK'),
}
story=[]
content=[]
def esc(x): return html.escape(str(x)).replace('\n','<br/>')
def rich(x):
 t=esc(x)
 return re.sub(r'\[(S\d+)\]',lambda m:'<link href="#src-'+m.group(1)+'" color="#176676">['+m.group(1)+']</link>',t)
def para(text,style='body'):
 content.append({'type':'paragraph','style':style,'text':text})
 story.append(Paragraph(rich(text),sty[style]))
def h1(title):
 story.append(PageBreak())
 content.append({'type':'section','title':title})
 story.append(Paragraph(esc(title),sty['h1']))
def h2(title):
 content.append({'type':'subsection','title':title})
 story.append(Paragraph(esc(title),sty['h2']))
def tab(headers,rows,widths=None):
 content.append({'type':'table','headers':headers,'rows':rows})
 arr=[[Paragraph(esc(c),sty['th']) for c in headers]]
 arr.extend([[Paragraph(rich(c),sty['table']) for c in row] for row in rows])
 widths=[CW*w/sum(widths) for w in widths] if widths else [CW/len(headers)]*len(headers)
 t=Table(arr,colWidths=widths,repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),0.4,TEAL),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,LIGHT]),('LINEBELOW',(0,1),(-1,-1),0.3,colors.HexColor('#DAE3E7'))]))
 story.extend([t,Spacer(1,8)])
def callout(title,text):
 a=Table([[Paragraph(esc(title),sty['h2'])],[Paragraph(rich(text),sty['body'])]],colWidths=[CW])
 a.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),0.5,colors.HexColor('#C9DBDF')),('LEFTPADDING',(0,0),(-1,-1),11),('RIGHTPADDING',(0,0),(-1,-1),11),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
 story.extend([a,Spacer(1,10)])
 content.append({'type':'callout','title':title,'text':text})

# Each source is verified against the detached audit tree and is reproduced as an
# immutable, numbered excerpt in the evidence bundle. Ranges intentionally stay
# close to the actual claim; historical reports remain explicitly historical.
sources={
 'S01':('审查入口与当前版本', [('AGENTS.md',1,95),('README.md',1,115),('docs/INDEX.md',1,42)]),
 'S02':('四类职责、受控扩展与已确认设计', [('docs/design/framework.md',1,120),('docs/design/framework-decisions.md',1,105),('docs/design/controlled-extensions.md',1,100),('docs/design/application-capability-19.md',1,90)]),
 'S03':('当前投递位与独立性', [('docs/design/application-architecture-22.md',1,100),('docs/runtime/application-architecture-22.md',1,95)]),
 'S04':('三个独立 Application', [('src/Ipc.Application.Sportmaster/Application.cs',1,44),('src/Ipc.Application.DirectPlc/Application.cs',1,28),('src/Ipc.Application.WcsToPlc/Application.cs',1,44),('src/Ipc.Application.ParcelFlow/FlowDefinition.cs',1,64)]),
 'S05':('装配与构建选择', [('Directory.Build.props',1,45),('src/Ipc.Assembly/Ipc.Assembly.csproj',1,40),('src/Ipc.Assembly/ParcelAssembly.cs',1,65),('src/Ipc.Desktop/Ipc.Desktop.csproj',1,65)]),
 'S06':('启动、队列、观察、重量、T1 准备', [('src/Ipc.Application.ParcelFlow/ParcelRuntime.cs',50,335)]),
 'S07':('准入与外部调用锁边界', [('src/Ipc.Application.ParcelFlow/ParcelGuards.cs',1,79),('src/Ipc.Application.ParcelFlow/ParcelConflicts.cs',1,75),('src/Ipc.Application.ParcelFlow/ParcelImages.cs',1,65)]),
 'S08':('数据库迁移、提交、测量身份', [('src/Ipc.Application.ParcelFlow/ParcelRepository.cs',1,38),('src/Ipc.Application.ParcelFlow/ParcelRepository.cs',75,106),('src/Ipc.Application.ParcelFlow/ParcelRepository.cs',134,257),('src/Ipc.Application.ParcelFlow/ParcelRepository.cs',289,320)]),
 'S09':('T2/T3、原始回执与重启恢复', [('src/Ipc.Application.ParcelFlow/ParcelStages.cs',1,181),('src/Ipc.Application.ParcelFlow/ParcelReceiptCustody.cs',1,80)]),
 'S10':('持久历史与 RCS 请求 ID 分配', [('src/Ipc.Application.ParcelFlow/ParcelHistory.cs',1,86),('src/Ipc.Integrations.SportmasterRcs/RcsDestinationProtocol.cs',1,50)]),
 'S11':('RCS 实现与资格边界', [('src/Ipc.Integrations.SportmasterRcs/SportmasterRcsTaskService.cs',1,100),('src/Ipc.Integrations.SportmasterRcs/modules.json',1,100),('src/Ipc.Integrations.SportmasterRcs/RcsTaskOptions.cs',1,95),('docs/runtime/sportmaster-rcs-task.md',1,105)]),
 'S12':('classic 与新 UI 的读取失效差异', [('src/Ipc.Application.Sportmaster.Desktop/Presentation.cs',1,30),('src/Ipc.Application.ParcelFlow.Desktop/ParcelViewModel.cs',1,185),('src/Ipc.Application.ParcelFlow.Desktop/ShellWindow.xaml.cs',1,58),('src/Ipc.Application.Sportmaster.Desktop/SupplyStationViewModel.cs',1,90)]),
 'S13':('配置唯一权威、校验与受控生效', [('src/Ipc.Platform/ConfigurationRevisions.cs',1,145),('src/Ipc.Application.ParcelFlow/ParcelCommands.cs',100,158),('src/Ipc.Application.ParcelFlow/ParcelConfigurationAudit.cs',1,55),('src/Ipc.Application.ParcelFlow/ParcelConfigurationRules.cs',1,95),('src/Ipc.Application.ParcelFlow/ParcelCapabilityInventory.cs',1,80)]),
 'S14':('纯托管扩展边界', [('src/Ipc.Platform/ExtensionPackages.cs',145,213),('src/Ipc.Platform/ExtensionLoading.cs',1,94),('src/Ipc.Platform/ManagedAssemblyPolicy.cs',54,83)]),
 'S15':('实际能力装配、Production 与维护', [('src/Ipc.Assembly/ParcelCapabilityFactory.cs',1,95),('src/Ipc.Assembly/ParcelCapabilityFactory.cs',125,230),('src/Ipc.Assembly/ParcelCapabilityFactory.cs',228,384)]),
 'S16':('兼容组合、离线扩展与安装', [('src/Ipc.Platform/BusinessCompatibility.cs',1,75),('src/Ipc.Platform/ExtensionStore.cs',55,145),('src/Ipc.Platform/ExtensionStore.cs',155,214),('src/Ipc.Platform/ExtensionStore.cs',235,267),('docs/extensions/developer-guide.md',1,115)]),
 'S17':('Windows 媒介与提权脚本', [('scripts/package-application.py',1,125),('scripts/protect-release.ps1',1,95),('scripts/provision-runtime.ps1',1,90),('scripts/provision-extensions.ps1',1,110)]),
 'S18':('Windows 普通运行、路径与启动故障', [('src/Ipc.Desktop/app.manifest',1,16),('src/Ipc.Desktop/DesktopLaunchOptions.cs',1,90),('src/Ipc.Desktop/ParcelApp.xaml.cs',1,100),('src/Ipc.Platform/MachineRuntimePolicy.cs',1,110)]),
 'S19':('当前随包指南矛盾', [('docs/runtime/architecture-quality-closure-01.md',1,115),('docs/runtime/validation/architecture-quality-closure-01-windows.md',1,50),('src/Ipc.Application.Contracts/Ipc.Application.Contracts.csproj',1,15)]),
 'S20':('相关现有测试的实际范围', [('tests/Ipc.Application.Verification/ArchitectureQuality.Recovery02.cs',211,247),('tests/Ipc.Application.Verification/ApplicationArchitecture.cs',103,130),('tests/Ipc.Application.Verification/ArchitectureQuality.Responsibility.cs',25,50)]),
 'S21':('命名兼容与离线业务事实', [('src/Ipc.Platform/LegacyNamedCapabilities.cs',1,50),('src/Ipc.Application.Contracts/ContractForwarders.cs',1,25),('src/Ipc.Adapters/Compatibility.cs',1,25),('src/Ipc.Application.ParcelFlow/ParcelConsumers.cs',1,95),('src/Ipc.Assembly/ExtensionConsumerReaders.cs',1,65)]),
 'S22':('观察会话、健康与释放', [('src/Ipc.Platform/ObservationSession.cs',1,180),('src/Ipc.Application.ParcelFlow/ParcelHealth.cs',1,110),('src/Ipc.Application.ParcelFlow/ParcelDeviceLifecycle.cs',1,150),('src/Ipc.Application.ParcelFlow/ParcelCommands.cs',200,275)]),
 'S23':('可选能力、状态含义与登录责任', [('src/Ipc.Application.Contracts/ParcelContracts.cs',1,98),('src/Ipc.Application.Contracts/OptionalCapabilities.cs',1,95),('src/Ipc.Application.ParcelFlow/FlowResults.cs',1,95),('src/Ipc.Application.ParcelFlow/ParcelOperators.cs',1,85)]),
 'S24':('容量、积压与备份设施', [('src/Ipc.Application.ParcelFlow/ParcelStorageCapacity.cs',1,40),('src/Ipc.Application.ParcelFlow/ParcelOverload.cs',1,100),('src/Ipc.Platform.Storage/Database.cs',1,180),('src/Ipc.Platform/ExtensionConsumers.cs',1,70)]),
 'S25':('现行组合、整合与历史验证定位', [('docs/runtime/version-compatibility-01.md',1,115),('docs/runtime/parallel-task-reconciliation-01.md',1,180),('docs/runtime/parcel-recovery-p2.md',1,100)]),
 'S26':('UI 原物与真实验收边界', [('docs/ui/STATUS.md',1,95),('docs/ui/ss-ui-vis-001-v1.1/README.md',1,75),('docs/runtime/validation/sportmaster-alternate-ui-windows.md',1,105)]),
 'S27':('资料可访问范围、原决策和缺项', [('docs/baseline/PUBLICATION.md',1,95),('docs/baseline/MISSING.md',1,90),('docs/readiness/decision-pack.md',1,130)]),
 'S30':('日志边界与实际 Parcel 维护命令', [('src/Ipc.Platform/RuntimeJournal.cs',1,36),('src/Ipc.Assembly/ParcelCli.cs',1,140),('src/Ipc.Platform/ExtensionContracts.cs',65,120)]),
 'S29':('锁定构建与执行进程所有权', [('global.json',1,8),('Directory.Build.props',1,20),('scripts/build.sh',1,12),('scripts/build_process.py',1,125)]),
 'S28':('发布所允许的 RCS 可选组合', [('config/compatibility/sportmaster.json',1,160),('src/Ipc.Application.Sportmaster/Ipc.Application.Sportmaster.csproj',1,15)]),
}

def cover():
 story.append(Spacer(1,38))
 para('独立架构与交付审查 · 2026-10-19','label')
 para('Windows 工业客户端\n商业交付质量审查','cover')
 para('WP-IPC-COMMERCIAL-QUALITY-AUDIT-03\nyuan2go/importer-pc','label')
 callout('总体判断', '现有架构适合继续开发，独立 Application、原请求冻结、可靠发送、受控扩展和恢复责任值得保留。当前交付仍处于参考产品向真实现场产品转换阶段。本轮确认 1 项 P1、3 项 P2 代码问题及 1 项 P2 当前操作文档问题；受影响流程的业务准入不通过，当前参考发布不具备指定场景商用交付条件。')
 tab(['审查基线','确认结果'],[
  ['远端最新 main（固定）',SHA],
  ['固定时间','2026-10-19 09:30:38 +08:00；git reflog 可复核。main 提交时间为 2026-10-19 01:54:31 +08:00。'],
  ['实际发布源码',RELEASE+'；与审查 main 的运行实现、配置、打包输入和随包操作指南无差异。'],
  ['实际媒介','Reference reconciliation 1.2.4 预发布；Sportmaster selected Windows x64、自包含 .NET 10.0.13。'],
  ['证据边界','已做静态追踪、当前源码构建、三组既有参考验证、五个缺陷场景探针、真实发布包字节核验；未运行 Windows、真实 SDK、真实设备或现场验收。'],
  ['只读约束','使用隔离 detached 工作树；未修改业务代码、配置、既有测试或设计；未提交、推送、创建/合并变更；未操作生产设备。']
 ],[1,3.6])
 para('结论按“代码缺陷 / 能力未实现 / 环境未验证 / 需求未确认”分别给出。历史 PASS、Windows 延期及原始要求保持原有版本和范围，不倒写旧结论。','small')

cover()
h1('阅读导航')
toc=TableOfContents();toc.levelStyles=[sty['toc']];story.append(toc)
para('正文中的 [Sxx] 可跳转到附录固定源码索引。证据包 README 说明执行命令、探针边界、原始输出以及所有文件 SHA256。CONFIRMED_DEFECT 表示探针成功复现问题，并非产品验证通过。','small')

h1('01 结论、范围与证据可信度')
tab(['维度','独立判断','依据与边界'],[
 ['架构','方向合理，适合继续开发','三个主流程确有独立业务所有者；宿主按构建装配、Platform 无反向项目依赖。共用 ParcelRuntime 属于包裹领域可靠执行机制。[S04][S05]'],
 ['工程质量','可靠性基础已有实现，但关键交错仍有缺口','T1/T2/T3、原始回执、Unknown 不盲重发、配置激活与资源释放有代码和验证。F01 在已知身份矛盾后继续 PLC 请求；F02/F03 暴露隔离及顺序组合缺陷。[S06][S09]'],
 ['AI 工程问题','局部后果明显，未发现全面重写依据','问题来自保护逻辑顺序不合、跨布局保护不一致、离线事实重复和增量文档堆叠，不能以类数、注释或“AI 比例”代替分析。[S12][S19][S21]'],
 ['文档健康','入口和历史定位明显改善；当前操作正文仍需整顿','README/INDEX 诚实标明 Simulation、Windows NOT_RUN 和真实集成缺口。F05 是当前索引并真实随包的指南冲突，不能用历史性质解释掉。[S01][S19][S25]'],
 ['需求符合度','主要业务、双位拓扑和批准延期基本保留','未发现新业务必须经中心总线、把三业务改成一个开关流程，或旧箱/数量/AGV 自动进入新流程。真实设备实体关联、重量政策和维护合同仍有未确认项。[S02][S03][S27]'],
 ['商业距离','已有参考产品实现；尚缺真实组合的交付闭环','真实 Driver/SDK 可执行接入、外部 Unknown 权威处置、Windows 实机和客户支持范围没有被参考测试补足。不能估算剩余百分比或承诺上线日期。[S11][S14][S26]']
],[1,1.5,4])
para('工程构建显式固定 SDK、锁文件、TreatWarningsAsErrors 和 Deterministic；产品打包以固定 git archive 快照构建，所选 Application 使用自身发布入口。build.sh 的旧 Product/参考入口不能直接当作新 Parcel 客户安装步骤。构建子进程所有权和失败/取消清理也有实现；这些机制支持可复核构建，实际 Windows 进程/UAC行为仍需对应环境验证。[S17][S29]')
h2('固定版本与可访问范围')
para('执行开始时工作目录没有已有仓库；09:30:08 +08:00 从远端克隆，09:30:38 +08:00 detached 到 origin/main。审查 HEAD 与远端 main 都为 '+SHA+'，工作树无已跟踪或未提交差异。近期 #27、#29、#30、#31、#32 与整合 #33 均已合并；可访问的当前 open PR 查询为空。未把 PR 分支或旧候选二进制混入当前执行。Git 历史、项目文件、现行文档、已有证据、公开 Release 和实际资产可读取。')
para('审查工作树：/workspace/scratch/56081ee5bcf2/importer-pc-audit03。执行环境为 Ubuntu 24.04 x64，隔离安装 SDK 10.0.402、运行时 10.0.13，符合 global.json 禁止 roll-forward 的版本约束。无 Windows 桌面、工控机、真实设备、厂商 SDK 现场安装、私有服务器及全量客户资料。仓库公开范围仍为 PUBLIC_SUBSET_ONLY，原审查 01 PDF 未取得；本次用户给定的业务基准是直接要求，不能以历史助手解释替代。[S01][S27]')
para('本轮复核近期整合的实际运行含义，包括永久回执身份、旧库未清责任、RCS 数字 ID、可选 UI 的时效保护和实际包闭包。F03、F04 表明“代码合并无冲突”和已有定向 PASS 都不足以保证组合行为正确；不据此推断某一 PR 作者或生成方式。')
h2('验证分层：本轮执行、历史复用与未运行')
tab(['证据层','本轮结果','可以支持的结论'],[
 ['静态代码与配置','通过读取并完成项目引用环检测；未发现 ProjectReference 循环','确认职责、入口、状态及发布限制；不能证明现场协议与物理行为正确。'],
 ['当前源码构建','锁定依赖恢复；Ipc.Application.Verification Release 构建成功，0 警告、0 错误','支持当前源码能够构建所查核心及参考验证程序集；不是全解决方案、全部 Windows 产品新构建。'],
 ['三组既有参考运行','--application-architecture、--parcel-recovery-p2、--sportmaster-rcs 均 exit 0 / PASS','对应原用例的参考行为成立。本轮没有宣称运行全部历史测试。RCS 初次被沙箱 loopback socket 权限阻断，允许本机回环后原组通过。'],
 ['外部小型探针','F01 在两个 Application 复现；F02、F03、F04 各复现一次目标反例','使用当前构建 DLL、真实 Runtime/VM/HTTP 实现及合成输入。只在仓库外添加探针，不改原测试或实现。没有真实设备副作用。'],
 ['实际发布包','独立下载 Windows ZIP 与 ARTIFACTS；全内层 hash、CRC、清单一致','证明下载的媒介完整且含所声明的 WPF、运行时和三包；不等于独立签名验真、已安装激活或 Windows 运行。'],
 ['已有跨构建与历史报告','已读同运行源码的既有发布/跨构建、签名安装和回归证据','按原 SHA、环境和测项继承其范围；不重标本轮 PASS。'],
 ['Windows / SDK / 协议 / 现场','本轮全部未执行；仓库当前亦明确 NOT_RUN / BLOCKED','Windows 交互证据不足；真实组合缺少能力与验收。不得用交叉构建或仿真替代。']
],[1.2,2.5,3.1])

h1('02 需求—设计—实现—交付对应关系')
h2('已知范围与待确认的现场条件')
tab(['范围项','可确认事实','不能自行承诺的内容'],[
 ['Application 与拓扑','Sportmaster left/right 各自 reader；DirectPlc、WcsToPlc 为 main 顺序位。[S03][S04]','增加第三位、任意八位、多 Application 同进程并行业务，均不是当前承诺。'],
 ['业务与可选能力','主流程固定；重量、登录、取图、上传按配置与所属业务规则启用；Sportmaster 无 PLC。','真实场景必须称重与否、测量/配置重量、实体传感器来源、身份有效期、图片留存均须客户确认。不能为规避 F01 改掉真实称重需求。'],
 ['Windows 与位数','本次实际媒介 win-x64；宿主 x64；自包含 .NET 与 WPF 10.0.13。','客户 Windows SKU、build、IoT/LTSC/Enterprise 分支、补丁、x86 SDK、驱动版本、离线依赖包尚无完整批准矩阵。'],
 ['部署与维护','ZIP + PowerShell 7 辅助脚本；普通运行、维护提权、独立配置/数据/包库机制存在。','实际账户、Program Files/ProgramData/数据盘选址、快捷方式、备份介质、离线信任、升级窗口和支持 SLA 尚未形成客户方案。'],
 ['设备与服务','存在 Manual/FileReplay 和参考秤/PLC/取图、实际 RCS HTTP 适配。','相机型号/SDK、秤与 PLC 协议、WCS/RCS/认证目标、超时与幂等/Query/物理完成合同未形成已验组合。'],
 ['负载与保留','有每位有界队列、驻留历史上限、磁盘保留与备份容量检查。','件/秒、突发长度、两位并发比例、图片大小、离线持续时间、日志/原件保留期及恢复时限未确认；不编造吞吐或压测天数。']
],[1,2.1,2.8])
h2('业务基准的五层映射')
tab(['明确需求','有效设计与代码','配置 / 产物','验证与独立判断'],[
 ['一主流程一 Application','19/22 设计；三个 Application.cs 分别定义 Advance、ApplyBusinessReply、恢复和终态。[S02][S04]','条件 ProjectReference / 编译入口、composition、compatibility；Windows ZIP 仅所选 Sportmaster。','静态及当前 architecture 组支持；设计与代码基本一致。'],
 ['Sportmaster：条码 → WCS 有效格口 → 展示，无 PLC','SportmasterFlow 只允许 WCS；有效 slot 与 UnpackRequired 分开；left/right 独立。[S03][S04]','schema3 两 reader；RCS 可选包存在。普通模式不强加图片或称重。','基础参考链路可运行；可选双秤 F02、RCS+异步取图 F03 破坏特定组合独立性。无真实 WCS/RCS 联调证明。'],
 ['DirectPlc：条码及按配置本件重量 → PLC','DirectPlcFlow 禁止 WCS；测量关联与 PLC 终态分开。[S04][S23]','main 顺序位；当前发布是 portable core，没有对应 Windows ZIP。','当前原测试仍有效；等待测量时的身份矛盾被漏隔离，F01。完整 UI 延期继续承认。'],
 ['WcsToPlc：条码/本件重量 → WCS 有效格口 → PLC','WCS T3 提交与后续 PLC 原意图同一聚合提交；无格口不得下 PLC。[S04][S09]','main 顺序位；各能力明确绑定；当前发布是 portable core。','正常参考与恢复行为有证据；F01 在当前 Runtime 复现。真实 PLC 接受/完成合同仍缺。'],
 ['构建选装，安装后选择、编辑并受控生效','Store 安装登记；Schema 表单/完整配置候选；CAS、Pending、资源成功后 Effective。[S13][S15][S16]','三 ipcx 已打包不等于已安装。新提供者必须属于业务已允许组合，必要时重新发布兼容声明。','并非只有接口；现有路径可参考验证。真实 native SDK 无可执行扩展边界。'],
 ['一业务实例服务多个页面/布局','UI 依赖 IParcelApplication，运行实例持有状态；共享窗体不重新起业务。[S12][S18]','classic 默认；Sportmaster supply-station 可选；当前写死部分页面声明。','旧 classic 时效 F04；原 HTML/34 PNG 均非 Windows 截图，原型不能证明 WPF 已验。[S26]'],
 ['旧业务兼容不侵入新业务','Supply/Inspection 保留旧职责；Assembly 中 Supply 为只读消费者与旧库识别用途。[S21]','Supply Storage5 与 Parcel DB6 各用自身工具与操作说明。','未发现旧共享箱/数量/AGV 被自动施加到新主流程；本轮不授予旧产品完整商用结论。']
],[1.2,2.3,2.1,2.4])
para('源码、设计和测试共同采用的 reference AdmissionId、参考 PLC completion、RCS 示例字段，仅能证明实现内部一致。相机回调怎样标识物理同件、称重窗口怎样绑定本件、PLC 何时真正完成，必须由实际设备/协议合同和独立联调确认。不能把三个内部来源相互引用当作业务事实已获客户认可。')

h1('03 实际职责、命名与依赖')
tab(['名称 / 位置','实际职责','判断、兼容影响'],[
 ['Ipc.Platform','生命周期、配置修订、观察会话、设备所有权、受控扩展/机器策略等基座机制','没有 Application ProjectReference；不拥有三种业务下一步。无中心总线也不违反本次基准。[S05][S13][S14]'],
 ['Ipc.Platform.Storage','SQLite 打开、迁移与备份基础设施','ParcelRepository / Supply 分别拥有业务 SQL 和事务语义，未形成跨业务万能业务表。[S08][S24]'],
 ['Ipc.Application.Contracts','包裹业务端口、冻结请求、快照与维护契约','当前实质是 Parcel 家族公共契约，不能理解成任意领域的万能契约；ABI 1.7.0。[S19][S23]'],
 ['Ipc.Application.Sportmaster / DirectPlc / WcsToPlc','各自拥有主流程规则、依赖、回执解释及何时可接下一件','是真实独立业务模块。应用层未直接嵌入相机 SDK / HTTP JSON / PLC 寄存器。[S04]'],
 ['Ipc.Application.ParcelFlow','包裹领域共用执行器、持久化、配置/能力约束、恢复、历史','共享原语合理；多个 partial 仍共享可变状态与 gate，后续变更需理解完整聚合边界。[S06][S09]'],
 ['Ipc.Application.*.Desktop / ParcelFlow.Desktop','所属业务页面、布局与共用表示模型','UI 通过应用契约读状态和发命令；没有发现直接读写 Parcel DB 或调用 Driver。classic 的时效缺口需在共享表示层修复。[S12]'],
 ['Ipc.Drivers','reader、参考秤/PLC/相机的连接、回调与资源实现','符合 Driver 职责；保留部分 Ipc.Adapters namespace 是已发布类型兼容，不应据名字误判为无硬件边界。'],
 ['Ipc.Components / Ipc.Integrations / Ipc.Integrations.SportmasterRcs','参考登录/上传、WCS 和 RCS 外部适配','按用户四分法都属于 Component。目录命名不统一造成阅读成本，但不是额外业务层；文档应给出明确映射。[S11][S15]'],
 ['Ipc.Assembly / Ipc.Desktop','产品构建选择与具体实现装配；CLI / WPF 启动入口','装配处引用具体实现是正常职责；未发现宿主用场地 if/else 替代 Application 主流程。[S05][S18]'],
 ['Ipc.Adapters / LegacyNamedCapabilities','TypeForwardedTo 兼容外壳与保留的旧类型全名','Platform 中有 Ipc.Application.Contracts namespace 不等于反向项目依赖。改名会影响程序集身份、已装包与旧原请求，须有 ABI 迁移窗口。[S21]'],
 ['Ipc.Product / Ipc.Supply / Inspection','旧产品宿主及原业务；新宿主只读兼容消费者','旧程序和数据库操作范围单独保留，不把 station.ps1 用于 Parcel 升级，也不因发布包含 Supply DLL 判定新流程泄漏。[S21]']
],[1.5,2.1,3])
h2('依赖、调用、事件、命令不是同一方向')
para('编译依赖：产品装配入口指向所选 Application、Desktop 和实现；Application 指向 ParcelFlow / Contracts；共用 UI 指向 Contracts；Driver / Component 实现公共端口并使用 Platform 机制。静态 ProjectReference 并集检测未发现环。装配注册表与业务允许提供者集合是显式控制，不是隐形 Service Locator。')
para('运行调用：Application 决定执行哪个业务阶段，再经端口调用 Driver/Component。设备事件则由 Driver 通过固定 ObservationSession / 回调进入所属位队列，由 Application 判定准入并改状态。普通 UI 命令携带显示时的应用 revision，由 Application 执行状态和权限校验；配置草稿与旧账确认另绑定读取时的运行实例、配置修订和相关内容身份；UI 读取快照不会取得业务状态修改权。外部回执由适配端解析成合同结果，再由所属 Flow 解释业务含义，不能由 Component 自行改变主流程。[S04][S06][S09][S12][S22]')
h2('关键 ID 与配置名称的实际含义')
tab(['名称','所标识的对象','误用风险与处理'],[
 ['ApplicationId / Position.Id','业务类型 / 本业务投递位','不能用页面、条码或当前焦点代替位置；拓扑变化属于业务版本变化。'],
 ['Reader.DeviceId / Epoch / SourceEventId','稳定物理来源 / 本次连接代次 / 本次源事件','旧回调不允许因设备同名重新变成当前事件；重连更新 epoch。'],
 ['AdmissionId / OperationId / ParcelCode','本件关联身份 / 内部聚合身份 / 业务条码','条码可重复而实体不同；同 AdmissionId 改内容是冲突，不是新件。F01 正在此边界。'],
 ['PackageId / ModuleId / ExtensionInstance.Id','包身份 / 包入口 / 安装后的逻辑实例','已打包≠已安装；已安装≠已绑定；实例可有独立参数、设备目标和寿命。'],
 ['CapabilityBinding.Target / Contract / Version','原目标 / 协议合同 / 实现版本','与业务版本、ABI、配置 Revision 不同；旧请求必须保留这些原值。'],
 ['kind=integration / plc / weight','外部服务类 Component / PLC Driver / 秤 Driver','integration 是现有序列化契约，不因改目录为 Components 就直接改键值。'],
 ['seed business.json / configuration.json / audit','初始种子 / Effective-Pending 权威信封 / 变更责任记录','只有运行信封是当前配置权威；审计日志是收敛凭据。schema3 旧首位锚点与库存镜像被校验为一致，仍有编辑同步成本。[S13]']
],[1.4,2.1,2.8])

h1('04 数据流、控制流与持久责任')
h2('沿真实入口的完整调用链')
tab(['阶段','实际入口与状态所有者','边界与审查结论'],[
 ['启动装配','ParcelAssembly / ParcelApp → ParcelRuntime.StartAsync → ConfigurationRevisions → ParcelRepository → ParcelCapabilityFactory。[S05][S06][S13][S15]','先核验旧未结责任、配置和原实现身份，再创建/启动设备、探测健康、确认 Effective，最后开放输入。启动完成不等于真实设备资格已获验收。'],
 ['观察与投递位','Driver 的 ObservationSession 固定 DeviceId / epoch；Runtime.Enqueue 按绑定入所属位队列；每位有自己的 worker。[S06][S22]','队列有界，溢出显式记录并阻断；同位顺序、位间分别执行。来源不是由 UI 焦点或扫码文本推导。'],
 ['准入与同件关联','ObserveAsync → 原事件/Admission 索引 → 聚合；MeasurementAsync → 本件绑定秤与测量身份。[S06][S08]','冻结配置、目标、实现、操作员和 acquisition。正常重量不取“最后一次秤值”。但新件准入与原实体冲突检测的顺序有 F01，测量冲突处理范围有 F02。'],
 ['业务规则和主流程','所属 Flow.Advance / ApplyBusinessReply 决定下一阶段及主结果何时完成。[S04]','共享 Runtime 提供持久原语，没有用大量 useWcs/usePlc 开关拼接三种主流程。登录、取图、上传按本业务能力规则处理。'],
 ['T1：原意图冻结','Prepare 形成原请求 ID、目标/合同/实现 hash、配置 hash、payload；纯 WCS preparer 冻结原 wire body。[S06][S10]','Prepare 不是外部发送；T1 事实须在外部调用前持久保存。RCS 当前把入场历史序号误当请求分配顺序，F03。'],
 ['T2：尝试落账','ParcelStages 先提交 Dispatching / attempt / 回执责任，再调用外部端口。[S09]','聚合 SemaphoreSlim 保护决策和事务；ExternalAsync 在远端等待时释放 gate、返回时重新取得。数据库事务不跨 HTTP / PLC 等外部等待。'],
 ['原回执 → T3','先持久保存 raw 与首次回复身份/hash；T3 原子提交结果；WcsToPlc 同时产生冻结 PLC 原意图。[S08][S09]','响应到达、保存原件、解释成功是三个事实。保存失败留下独立回执责任，不可通过最后一条成功结果抹掉。'],
 ['完成 / 待核对','Flow 解释业务结果；本地 raw 恢复、权威 Query 或受权限保护的未发原件处置。[S07][S09]','未知外部结果不等于失败；已尝试不自动重发；未提交 Prepared 也有恢复屏障。Query 证明业务结果不等于补回丢失的 Submit raw。'],
 ['UI 与历史','Snapshot / History → IParcelApplication → 所属 Desktop；普通 UI 命令携带显示时的 revision。[S12][S23]','UI 不拥有业务状态；CAS 阻止旧请求。历史原件可以归档出驻留集合，但身份、原回执和审计没有因内存窗口自动删除。'],
 ['停止 / 退出','Stop 关闭输入、停止来源，等待位 worker / 附属任务 / 外部调用，再释放端口、工厂、DB、lease。[S22]','不提前释放仍执行的能力或原包。F02 终止异常路径也成功释放资源，不能误报为 Stop 泄漏。Windows 原生驱动退出尚待实测。']
],[1.1,2.45,3.25])
h2('识别、格口、PLC 接受与物理完成')
tab(['事实','软件证据可证明什么','不能偷换的含义'],[
 ['已识别 / 已准入','一个带来源、代次、实体身份的观察被业务接收并保存','不等于实物已经成功投递，也不能仅以条码唯一性识别每一件。'],
 ['已保存 / Prepared','原意图和负载已经冻结到本地','不等于尝试发送；未尝试可以在守卫与人工核对后继续。'],
 ['已发送 / 传输成功','有 attempt 或 transport 成功事实','不等于服务业务接受；超时也不证明服务没有产生副作用。'],
 ['WCS 接受 / 格口确定','协议、业务接受且 slot 按合同有效；Sportmaster 显示这一主结果','空/非法 slot 不能当完成；NEED_UNPACK 是 UnpackRequired，非普通格口成功。'],
 ['PLC 接受','控制服务或设备已接受原命令','DirectPlc / WcsToPlc 的顺序位不能仅凭接受就认定物理完成并接下一件。'],
 ['物理完成','需目标 PLC / 传感器合同中的权威证据，或被批准的实物核对程序','参考 peer 的 PhysicalCompleted 只能验证状态机响应，不能证明真实机械已经完成。[S23]']
],[1.1,2.4,2.7])
h2('交错、故障与恢复覆盖')
para('同码不同实体、重复/迟到事件、旧连接回调、跨位来源、旧重量、配置切换、队列溢出和重启责任在代码中都有专门身份/时间/版本/资源守卫，不能概括为“没有工业可靠性”。本轮的新反例说明：存在守卫不代表守卫先后次序和故障范围正确。F01 是原实体冲突被新件守卫遮蔽；F02 是局部数据冲突被提升为共享失败；F03 是并发合法顺序与 ID 高水位不一致。')
para('断网/超时、进程停止或原响应写失败后，已尝试请求保留 Unknown 或回执托管责任；只回放已保存的本地 raw，不再次触发远端副作用。旧数据库普通启动先拒绝未清的旧格式责任；必要的特准恢复走显式原资料核验，不应通过改 DB 版本号跳过。SQL1–5 与旧 ABI 支持窗口须保留，Parcel DB6 不能用旧 Supply Storage5 工具操作。[S08][S09][S19][S25]')
para('磁盘余量和日志/存储失败已有拒绝继续工作的入口，备份具备一致性和容量检查；但本轮没有实际 Windows 断电、磁盘不足、真实驱动卡死、时钟跳变与长期资源曲线证据。若现场对时间同步有跳变，应专项核验基于 UtcNow 的新鲜度/等待判断，而不能在未复现的情况下给它新增高严重度缺陷。[S06][S07][S24]')

h1('05 确认问题清单与可复核反例')
para('优先级按工程后果定义：P1 为放行相关真实动作前必须关闭的身份/副作用正确性风险；P2 为影响指定组合功能、独立性、HMI 可信度或关键维护路径的问题。A 级证据表示固定源码加当前原实现可重复反例；B 级为源码/实际产物直接比对。没有把环境缺失列成代码缺陷。')
tab(['编号','优先级 / 类别','受影响组合','本轮证据'],[
 ['F01','P1 · 代码缺陷','DirectPlc、WcsToPlc，启用本件实测称重且原件 WaitingWeight','A：两个 Application 均出现冲突数 0、PLC attempt 1；无真实硬件动作。'],
 ['F02','P2 · 代码缺陷','Sportmaster 启用独立双秤；一侧重复测量 ID 内容变化','A：左侧冲突导致全局拒收，右侧合法重量 callback=false。'],
 ['F03','P2 · 代码缺陷','Sportmaster RCS + 可选异步取图，左右 T1 准备反序','A：右侧格口成功，左侧唯一 ID 被高水位拒绝，无左侧 POST。'],
 ['F04','P2 · 代码缺陷','三业务共享 classic；Sportmaster classic 为默认布局','A：实际已暂停、snapshot 读取失败时 classic 仍 Ready；业务 CAS 有效。'],
 ['F05','P2 · 当前操作文档缺陷','当前索引的升级/维护与 Windows 验收指南，且随包发行','B：ABI 1.6.0/DB5 文句与实际 ABI 1.7.0/DB6 及旧库守卫矛盾。']
],[0.55,1.15,2.3,2.65])
h2('F01 · 原实体的身份矛盾被新件准入守卫遮蔽')
para('精确位置：src/Ipc.Application.ParcelFlow/ParcelRuntime.cs:218–234（220–221 先 CanAdmit，228–233 才查原身份）；ParcelGuards.cs:26–28；后续 Measurement/Advance 在 ParcelRuntime.cs:258–276、294–304，实际发送在 ParcelStages.cs:33–57。所有位置固定为本报告 SHA。[S06][S07][S09]')
tab(['项目','复核事实'],[
 ['触发','schema3 实测称重。原 AdmissionId=same-entity、条码 ORIGINAL-CODE 已接收并处于 WaitingWeight。同一当前 reader 随后发来新鲜、合法的新事件，AdmissionId 相同而条码改为 CONTRADICTORY-CODE。'],
 ['实际行为','原件未结导致 CanAdmit=false；观察只成为 ObservationBlocked，未形成 IdentityConflict。之后同一实体有效重量到达，DirectPlc 以及 WcsToPlc 都继续到 PlcAccepted。ConflictCount=0、PlcAttempts=1、DeliveredCode=ORIGINAL-CODE。'],
 ['现有防护','没有篡改原码/原请求、没有建第二实体或重复发送，存在通用拒绝审计；已有身份冲突与 CanDispatch 屏障本可复用。'],
 ['影响与范围','已知矛盾身份之后仍能执行尚未发送的外部动作，形成错误关联/控制风险。未证明真实设备已错控，也无法判断两次条码哪一个真实。共享顺序还影响其他未结阶段的可能性属静态推断，未宣称逐一复现。'],
 ['为什么现有 PASS 不覆盖','ArchitectureQuality.Recovery02.cs:231–235 在 SlotResolved 后才制造冲突；其他用例是“太早来的不同新件”。这两种都不是当前 WaitingWeight 原实体内容矛盾。[S20]'],
 ['改进方向','在新件准入判断之前，先验证当前源身份并处理已存在实体的重复/冲突；持久保留原事实和矛盾证据，隔离相关实体/位并阻断未发阶段。不能覆盖原码、撤销已知远端结果或重发 Unknown。'],
 ['复核证据','probes/business/ 的最终 run 目录内 unsettled-identity-direct-plc.json、unsettled-identity-wcs-to-plc.json；源探针与 probe-confirmed.log 一并交付。探针 exit 0 代表 CONFIRMED_DEFECT。']
],[1,5.5])
para('修复后的必要验收：两个业务在等待实测阶段收到同实体改码后，原事实保持、冲突持久、后续 PLC attempt=0；同内容重复仍幂等，提前不同新件仍拒绝，同码合法新实体仍按顺序准入；重启后冲突不会消失。受影响完整业务验收、可执行真实 PLC 联调、现场试点和商用准入均不通过，不能降为“带条件上线”。')

h2('F02 · 一侧测量身份冲突使两个独立投递位全停')
para('精确位置：ParcelRuntime.cs:258–276（270 在判断 WeightPending 前调用 HasMeasurement）；ParcelRepository.cs:309–314 对同 ID 不同内容抛出 InvalidDataException；ParcelRuntime.cs:189–216 的 worker catch 写全局 failure、accepting=0。与 application-architecture-22.md:17–19 的位/设备故障范围要求不符。[S03][S06][S08]')
tab(['项目','复核事实'],[
 ['触发与结果','Sportmaster 两 reader、两独立 scale；左测量 M=2.345 已提交并 SlotResolved，右仍 WaitingWeight。左以同 M 报 3.456 后，系统报告 Application worker failed，右合法重量 callback=false、右 Wcs 仍为空。'],
 ['现有防护','原重量未替换，无错重量发送或重复副作用；系统全局拒绝继续输入；Stop/Dispose 最终 resourcesReleased=true，随后准确报告原 worker 失败。'],
 ['影响','来源明确的局部设备数据冲突扩大为全局可用性/恢复问题，并未生成可持久处置的局部冲突事实。不称重的默认 Sportmaster 不属于本反例范围。'],
 ['修复与验收','在现有身份比较处返回明确冲突结果并记录相关源、原件和位，保持原重量不变，让另一独立位继续。不能吞掉真实数据库不可写/损坏等共享故障。验证变内容重复、相同重复、右位继续、重启持久和清理释放。'],
 ['证据','probes/business/ 的最终 run 目录内 measurement-isolation.json；源码和日志与 F01 共用，探针配置镜像已通过现有校验后才进入目标场景。']
],[1,5.5])

h2('F03 · RCS 请求 ID 高水位与双位异步准备顺序冲突')
para('精确位置：ParcelRuntime.cs:306–325 使用 OperationSequence（313）并在 317 检查新 ID；ParcelHistory.cs:11–44 同时定义全历史最高已分配 ID 与入场历史序号；RcsDestinationProtocol.cs:12–28 使用 base+ordinal。可选取图等待在 ParcelRuntime.cs:250–256 / ParcelImages.cs:30–45。[S06][S07][S10]')
tab(['项目','复核事实'],[
 ['触发','当前 compatibility 声明允许的 RCS + reference camera 组合；左先准入并在可选取图处等待，右后准入先完成取图并准备 WCS 请求。不是为 Sportmaster 新增取图需求。[S28]'],
 ['实际结果','右持久准备并发送 requestId=810000004，得到格口；释放左后生成候选 810000001，被“must exceed durable original allocation 810000004”拒绝。左 State=Blocked、Wcs=null，未建立外部意图或 POST。'],
 ['现有防护','原实体保留，阻断发生在 T1/attempt/HTTP 前；没有 ID 重用、重复副作用或虚假成功，现有未发送原件检查处置可处理阻断。'],
 ['根因与影响','入场序号与实际请求准备顺序不是同一序。较早合法实体唯一 ID 被误当新分配回退，双位组合不能正常推进。普通无异步能力的 RCS 双位不据此判为全面不可用。'],
 ['改进方向','在实际 T1 准备事务中保留独立且持久的数值分配，或以可证明唯一的持久拥有关系替代不合适的顺序假设。保留原请求 ID/范围/归档/备份不重用要求，不能直接删高水位守卫，也不能强制全局串行两位掩盖冲突。'],
 ['证据边界','使用原测试程序集内 Peer / Factory 及实际 RCS HTTP 客户端，仅包装左取图等待；不是签名安装/实设备测试。probes/rcs-order/ 的 run 目录内 result.json 和 Program.cs / probe.log 记录全过程。']
],[1,5.5])
para('必要验收应以实际 T1 准备反序为触发：左右均能取得格口，原 ID 唯一且持久、每件一次发送；重启、归档、恢复、既有 ID 范围和原请求字节不变。测量等其他可选等待可作为设计影响推演，本轮没有把它们计作已复现场景。')

story.append(PageBreak())
h2('F04 · classic 读取失败后仍以旧快照显示 Ready')
para('精确位置：Sportmaster.Desktop/Presentation.cs:9–14 默认 classic；ParcelFlow.Desktop/ParcelViewModel.cs:22–37、112–137、153–180 保留快照且失败 hook 默认为空；ShellWindow.xaml.cs:23–31 仅更新 Message；新的 SupplyStationViewModel.cs:21–32、45–57 已有 Fresh 防护。[S12]')
tab(['项目','复核事实'],[
 ['触发','真 ParcelRuntime 与 reference WCS，原编译 classic / alternate ViewModel；仅在 Snapshot 接口注入 IOException。先取得 Ready / REFERENCE-07，再将真实应用暂停后让 UI 读取失败。'],
 ['实际结果','实际 revision5、Paused=true、Admit=false；classic 仍 revision4、Ready、CanAdmit=true 和旧格口，只增加错误消息。新 supply-station Fresh=false、CanUseWorkspace=false。'],
 ['现有防护','旧 classic Resume 请求被业务 CAS 返回 Conflict，实际仍暂停；恢复读取后 UI 更新正确。没有证明命令绕过权限、准入或重复发送。'],
 ['影响与范围','HMI 状态和可执行入口与实际事实脱节，容易误导依赖画面的操作员。是读取失败未失效的反例，不是本轮复现了旧异步结果覆盖新快照；挂起读取的 TTL 也需要落实。三业务共享 classic 均相关。'],
 ['改进与验收','在共用表示层落实最后成功时间、有限时效和结果顺序；旧事实可显示但明确标旧，限制依赖旧事实的动作，保留独立暂停和业务 CAS。验证失败/挂起/恢复/跨运行实例及原生 UI 行为。'],
 ['证据','probes/classic-ui/run-01/classic-stale-result.json、Program.cs、构建/运行日志。原 VM 有测试用 WPF stand-in；本轮不声称运行 WPF、Dispatcher、HWND 或 Windows。']
],[1,5.5])

h2('F05 · 当前且随包的 ABI / DB 升级指引相互冲突')
para('精确位置：docs/INDEX.md 当前顺序第 3 项；docs/runtime/architecture-quality-closure-01.md:5–7、61、63、109；docs/runtime/validation/architecture-quality-closure-01-windows.md:3、18；实际 Contracts.csproj:1，ParcelRepository.cs:91–106。[S01][S08][S19]')
tab(['矛盾','实际影响与现有防护'],[
 ['当前维护页顶端写 DB6，第63行仍写 ABI1.6.0','当前业务和真实包为 Contracts1.7.0。可能指导错误的兼容/回退计划；真实加载器、版本指南仍会阻止不兼容组合，未证明因此已损坏数据。'],
 ['旧库升级正文与末尾新增限制不一致','正文保留 DB4/5 原责任核验升级说法，末尾追加普通启动拒绝 DB2–5 未结与 CLI target6 / 旧 API default5 区别。实际普通启动对低版本未结先拒绝，特准 custody 路径另有守卫。维护者不能仅靠当前正文形成一致 SOP。'],
 ['当前 Windows 验收页要求 DB5 / 升级 DB5','实际 Parcel DB6。两指南真实随 Windows ZIP 发成 QUALITY-CLOSURE-01.md / QUALITY-WINDOWS-ACCEPTANCE.md，属于当前指导错误，不能归类为旧报告的正常历史状态。'],
 ['修复方向与迁移','先重排现行操作正文和版本入口，使每条命令、前提和失败恢复只有一套当前含义；旧 DB5 操作按原件转为清楚的历史流程并链接原来源。保留原始报告、FAIL/PASS、SHA 和客户要求，不批量改写历史字节。']
],[2,4.5])
para('证据强度为 B：当前源文档与实际下载包、实际公共版本及迁移代码直接比对。不是运行了破坏性升级才得出结论。验收应从同一实际 ZIP 取指南，让维护者仅按当前正文完成一次指定版本升级/恢复演练，并由 CLI / DB / 原件读回证明一致。')

h1('06 能力缺口、未验证环境与未确认需求')
h2('G01 · 真实 SDK / Driver 可执行接入尚未形成')
para('这是能力未实现，不只是“还差一次现场测试”。当前 reader 是 manual/file replay，秤/PLC/相机是 reference 能力；真实发布未见厂商原生 SDK。ExtensionPackages.cs:158–171 拒绝 native/mixed DLL 与 P/Invoke，ExtensionLoading.cs:80 拒绝 LoadUnmanagedDll，ManagedAssemblyPolicy 要求 net10 纯托管 IL。vendor-sdk / system-driver 前置声明只能声明并核证依赖，不能执行设备接入。[S14][S15]')
para('现有 Production 校验要求真实 reader、维护认证、schema3、允许组合及独立资格证据，并拒绝 reference/test-only。它避免把仿真误当生产，应保留。新增纯托管 Driver 有明确道路；若指定设备要求原生 DLL，应在取得型号、SDK、位数与再分发依据后，增加必要受保护原生边界。只有实际存在 x86/x64 冲突、不可取消阻塞或崩溃隔离需要时才选择受监督设备进程，不能预先为所有 Driver 建一层服务框架。')
h2('G02 · RCS 有真实协议实现，但 Unknown 的权威闭环未实现')
para('sportmaster.rcs-task 1.0.4 实现 sorter.task.dest_request 的冻结 HTTP 请求、相关身份/重复 JSON/响应长度校验、格口/拒绝/UnpackRequired/Unknown 解释。它不是空接口。但 manifest 为 Simulation，Query=false，SportmasterRcsTaskService.QueryAsync:55–59 返回 null，不调用 POST 假装 Query。当前没有支持“该次不确定请求远端到底怎样了”的权威查询/证据处置合同，Unknown 又被正确禁止盲重发或普通弃件。[S11][S07][S09]')
para('真实 RCS 断网、半响应或提交后本地 raw 丢失时，可能保留长期未清责任。下一阶段必须取得真正的查询合同，或由客户/协议方明确允许的人工权威结果与原件证据程序；不能自造 endpoint、把超时当失败或把“人工确认”当成补回缺失原响应。NEED_UNPACK 单独保留是正确的；是否需要后续解包业务和现场处置应由指定场景决定，不扩大本次主流程。')
h2('G03 · Windows / 真设备 / 现场均缺直接验证')
para('Windows 验收曾被批准延期，现行索引仍诚实列 NOT_RUN；延期继续保留。自包含 ZIP 含真实 WPF、交叉构建成功与 VM 测试只能证明各自范围。干净目标机、原生 UI、ACL/UAC、多账户/会话、实际设备独占、升级中断、断电和持续作业仍需用同一不可变媒介执行。真实 SDK 加载、通讯、完整业务联调与现场接受是后续独立层级。[S18][S25][S26]')
h2('G04 · 指定商业场景的支持范围未确认')
para('尚缺客户确认的 Windows SKU/build、设备/SDK/协议精确版本、物理实体 Admission 来源、重量政策与精度、PLC 完成/复位、负载/突发/离线时长、保留与备份期、维护账户、网络和凭据托管、升级窗口、恢复时限、再分发和分发信任要求。引用 reference 默认值或 UI 原型不能替代这些事实。DirectPlc 完整操作 UI 延期属于已批准开发范围；到该场景客户交付时，仍必须证明实际界面能完成作业及异常处置。[S23][S26][S27]')
tab(['对象','接口/参考/完整实现','已打包 / 安装 / 绑定 / 激活 / 真可用'],[
 ['Manual/FileReplay reader、reference weight/PLC/camera','参考实现完整，纯模拟输入/peer','部分随 ipcx 打包且有历史参考安装证据；本轮只验包字节，未装。没有真实生产设备资格。'],
 ['RCS 目的格口 Component','具体 HTTP 实现，当前参考合同验证；Query 未实现','1.0.4 在实际 Windows ZIP 中；不能从包存在推导已安装、已绑定或生产可用。'],
 ['认证 / 上传 Component','公共端口和 reference 实现、schema 等扩展道路','实际商业服务、凭据取得方式、授权与完整联调尚无指定组合证据。'],
 ['厂商相机、实际电子秤、PLC','当前仓库没有对应已交付的真实 Driver 组合','native 扩展路径尚受明确拒绝；不能把 prerequisite 描述当作 SDK 已加载。'],
 ['Sportmaster Windows UI','真实 WPF classic + 可选 supply-station','实际 ZIP 含程序集；Windows 原生操作性未执行。'],
 ['DirectPlc / WcsToPlc Windows 交付','有共用/所属 WPF 源码与历史跨构建；DirectPlc 完整 UI 延期','当前公开 Release 只有 portable core；没有这两业务的 Windows ZIP，不能沿用 Sportmaster 包名出货。']
],[1.4,2.15,3])

h1('07 扩展路径与实际修改影响')
para('受控扩展具备从离线包校验、安装登记、schema 读取、实例绑定、配置 CAS 到重启后生效的真实路径。安装不会自动激活，显式注册、精确允许组合和受控重启符合本任务要求。代价是新增此前未允许的提供者组合需要业务兼容声明与发布同步；应在交付能力表中明确，而不是宣传任意插件即插即用。[S13][S15][S16]')
tab(['变更','必须修改 / 同步的位置','是否侵入核心；必要验证'],[
 ['新增 Driver（现有 reader/weight/camera/plc 类型）','独立实现与公共端口；manifest/module/schema/build 声明、依赖锁和签名；业务 compatibility 未覆盖时增加允许集合；设备/位/实例与资格；打包选入、安装和重启。[S15][S16][S17]','通常不改 Platform 或其他业务流程。原生 SDK 受 G01 阻断。验证位数/加载、稳定设备身份、旧回调、同件关联、停止释放、错误组合拒绝。'],
 ['替换 WCS Component','IWcsExtension / IWcsPort，必要时纯 IWcsRequestPreparer；该组件参数和合同、允许组合、Binding Target/Contract/Version；原包保留或清偿后切换。','Application 不应知道 URL/JSON；只有新业务语义超出现有 StageReply 时才演进契约。冻结旧目标/负载/版本，验证超时、回执相关性、查询与恢复。'],
 ['替换认证 Component','ILoginExtension / IOperatorAuthenticator；schema、assurance、Login/MaintenanceLogin、允许集合、凭据来源与权限。','一般无需改框架。验证会话过期、错误 authority/角色、原件操作员冻结；关闭作业登录不得解除维护权限。'],
 ['第四个 Parcel Application','独立 Flow / Desktop；Assembly/Desktop 条件引用与映射；composition、compatibility、seed、锁和文档；package-application.py:16、application_compatibility.py:12 的业务名单。当前还需同步 ParcelConsumers / ReceiptCustody。[S04][S05][S17][S21]','主流程不必改 Platform，但离线业务事实有重复维护成本。超出 Parcel 语义应实现独立 IBusinessRuntime，不扩大共享 stage 枚举去模拟任意流程。'],
 ['增加页面或布局','所属 Desktop/Presentation；当前 ParcelRuntime.cs:50、ShellWindow 导航、composition Views 和发行校验仍需同步。[S06][S12]','多处硬编码是真维护债；页面本身应继续共用同一业务实例，不重新占设备。验证双窗/切页一致性、快照时效与配置 CAS。'],
 ['增加 / 更换设备','Driver 包与资格；stable DeviceId、实例、角色、目标绑定和 topology；清偿旧设备关联后受控迁移。','不能自动用“当前 UI 或最新条码”换位。验证重连 epoch、旧资源释放、旧件原请求及错误绑定拒绝。'],
 ['增加投递位','先确认新拓扑；所属 Flow.PositionRoles、配置校验、独立 reader/能力、离线消费者/UI、负载与资格。[S03][S13][S21]','当前恰为 left/right 或 main，数组长度上限不表示已支持任意八位。增加位属于业务变化，不只是编辑数组。'],
 ['修改参数','既有 schema 表单或完整候选 → 校验 → revision CAS → PendingRestart → 清偿/暂停 → Stop/Start → Effective。新提供者参数改 schema/实现/包；新业务策略字段还需契约/规则/seed/UI/版本。[S13][S15]','无需另建配置系统。schema3 首位兼容锚点与库存镜像虽校验一致，编辑者仍可能多点同步，应在兼容窗口内逐步收敛。']
],[1.12,3.1,2.55])
h2('事实重复与性能债的处理尺度')
para('ParcelConsumers.cs:28、60、73–77 与 ParcelReceiptCustody.cs:62–64 再次列出业务 ID、位数、WCS/PLC 需求和主终态；共享 Runtime/壳也写死页面。新增第四业务时，运行、离线恢复和 UI 会多处同步同一知识。现状能保守拒绝未知版本，并非已确认当前业务错控；应由业务/装配提供小型纯语义描述，保持离线消费者只读、不加载 SDK 的性质，不能改成动态执行插件来证明卸载安全。[S09][S21]')
para('Factory.Requirements / SimulationIdentity 会经 VerifyInstalled 再核验包目录与 hash，部分路径处在共享 gate 内。实际工作量可静态确认，本轮没有目标包下的延时测量，所以列为测量后优化候选。若证据表明它影响 HMI/两位响应，可复用已在激活时验证且被 lease 锁定的不可变 descriptor；安装、激活、维护和信任变化边界仍须完整验证。[S14][S15][S16]')

h1('08 复杂度、AI 工程问题与文档处置')
h2('主要复杂度的责任、成本与安全简化条件')
tab(['对象 / 建议','解决的需求及实际入口','维护成本 / 替代 / 安全条件'],[
 ['独立 Flow + 共享 Runtime\n保留','不同主流程独立所有权，共用包裹身份、事务与恢复；Create / Advance / ApplyBusinessReply。[S04]','共同变化会影响三业务；只集中共用原语和明确语义边界，不复制三套可靠发送，也不用配置工作流合并三业务。'],
 ['T1/T2/T3、原 raw、永久回执身份与 custody\n保留','提交后超时、保存失败、重启不知是否已执行；Stages / Repository / ReceiptRecovery。[S08][S09]','确有较高心智成本。只有真实合同的幂等/权威 Query 和持久事实支持时才能简化，不能把 Unknown 当失败、删原包或以 Query 伪造原 raw。'],
 ['配置 CAS、Pending、资源成功后 Effective\n保留','保存成功与设备启动成功并非同一时刻；ConfigurationRevisions / Start。[S13]','状态和审计收敛需要理解，但有明确故障依据。复用当前权威信封；不加第二配置账或另一个 activation manager。'],
 ['签名、精确依赖、lease、离线消费者\n保留','可信包、版本身份、卸载/回退不丢原件；Store / Loading / ConsumerReaders。[S14][S16][S21]','组合要随发布确定。可缓存被锁定的已验 metadata；不能删除独立 trust、原件引用或 Windows 权限约束。'],
 ['原实体冲突、测量冲突、ID 高水位\n修复','保持物理关联、原测量与外部唯一 ID；Observe / Measurement / Prepare。[S06][S08][S10]','F01–F03 的先后次序/范围错误说明防护叠加需要联合推演。替代是修正现有入口和事务，不是再叠一个管理器。'],
 ['classic / alternate 时效分叉\n合并公共机制候选','两布局都应呈现有效快照；ViewModel / polling。[S12]','新布局的 Fresh 防护没有传播到默认壳。把时效、读序和运行身份处理集中到公共表示层，保留各布局视觉与导航。'],
 ['业务终态 / 页面知识重复\n修复或合并候选','离线恢复需要不启动业务就判断责任；运行展示需要声明页面。[S21]','先集中小型纯业务描述和装配声明，保留旧版本 reader；不要增加万能上下文、反射扫描或新插件发现框架。'],
 ['Reference schema 与 Factory 多处校验\n合并候选','参考 provider 的默认与参数校验','把参考实现自己的 schema/纯校验收回对应提供者；业务所需能力前提仍由 Application/Factory 保留，不删除业务守卫。'],
 ['Adapters / 旧 namespace / Supply 兼容壳\n保留至迁移窗口','已发布类型名、冻结请求与旧库依赖。[S21]','全量改名会改变 ABI/包闭包。仅在支持窗口结束、旧责任和原包处理明确、提供可复核迁移后删除。'],
 ['Store 的永久登记/退休历史\n待确认处置','128 installed、2048 operations、2GiB 的有限保护边界；拒绝不明责任删除。[S16]','长期升级会累积 retired/incoming/消费者。按实际维护频率制定迁移/清偿退役 SOP；不能按年龄自动删旧包/备份，也不先建清理平台。']
],[1.55,2.15,3.1])
h2('AI 工程问题的独立判断')
para('没有估算 AI 生成比例，也没有因注释多、类多或命名长给出负面判定。当前可证实的工程后果是：解决旧故障的保护被局部加入，未覆盖另一个合法顺序/布局；同一业务事实被运行、离线维护、UI 和文档分别维护；有效规范靠连续增量解释累积。F01、F03、F04 与 F05 分别提供了这类后果的直接例子。它们构成需要处理的局部工程债，不能用“工业级防御”合理化，也不足以否定整个架构。')
para('近期工作确有产品进展：三个独立业务、双位 reader、实际 RCS HTTP、可选 WPF UI、原件恢复、参数激活和可核验 Windows 包都不是仅增加报告。下一阶段的重心应转到第一个真实设备/协议组合、操作员可用性与可执行维护过程；在这些入口上收敛现有复杂度，避免持续用新框架维护上一层框架。')
h2('文档与需求处置表（本次不执行清理）')
tab(['处置','对象','理由与迁移条件'],[
 ['保留','README/INDEX 的版本和证据边界；framework/19/22 的四类职责与独立 Application；UI 原物来源','这些当前声明总体诚实，旧 HTML/PNG 明确为设计原型。保留客户要求和已批准的 DirectPlc UI / Windows 延期。[S01][S02][S03][S26]'],
 ['修复','当前维护正文、Windows 验收指南、随包版本和升级步骤','先关闭 F05，使 ABI/DB/CLI/未结旧账前提一致。复用已有 getting-started、版本与维护入口，不另建一套门禁文档。'],
 ['合并候选','19→20→22→quality→后续 PR→RCS 的“当前增量”解释链','按架构、配置、恢复、扩展、Windows 场景整成少量有效正文，保留来源编号和生效条件；不再在操作步骤后无限追加例外。'],
 ['归档 / 历史保留','已按历史定位的工作包、旧候选、旧 FAIL/PASS、旧 SHA 原证据','按形成时事实解释，不批量改成新版本 PASS，不删除原失败。若迁移当前页中的历史段，保留原件路径或明确链接。'],
 ['待确认','Windows/SDK/设备合同、Admission 来源、重量/图片/登录、负载/离线/保存、支持和许可','区分客户明确需求、合理工程选择、尚未证实扩展。禁止从 reference 固定重量、样例请求 ID 范围、旧 Supply 原型推导新商业默认。'],
 ['按真实检查范围解释','资料校验器、清单、原测试和历史整合报告','文档校验通过只证明其实际规则。当前索引已披露资产/公开范围等限制；本轮不把它等同需求正确性、Windows 验收或商业批准。[S25][S27]']
],[1,2.2,3.5])

h1('09 Windows 安装、运行与维护交付')
h2('实际产物已经包含什么')
para('独立读取公开预发布页面与资产。Release 为 Reference reconciliation 1.2.4 (Windows NOT_RUN)，发布于 2026-10-18T17:52:39Z，源 '+RELEASE+'。本轮直接下载 ARTIFACTS.json 和 sportmaster-selected-win-x64.zip；其余资产只核对发布清单和已有证据，没有宣称逐个重新下载。REST 端点返回 403，公开页面和资产直链读取成功。')
tab(['实包项','本轮结果'],[
 ['Windows ZIP','104,170,521 bytes；SHA256='+ZIPHASH],
 ['完整性','740 个 ZIP 文件条目，CRC 正常；739/739 内层 SHA256 正确、没有额外未登记文件；app 251 条、desktop 466 条发行清单 hash 全部匹配。'],
 ['宿主 / 运行时','app/Ipc.Assembly.exe 与 desktop/Ipc.Desktop.exe 为 x64 PE；含 .NETCore.App 与 WindowsDesktop 10.0.13 自包含运行时。托管 DLL 的 PE 0x14c 不能据此判定进程为 x86。'],
 ['业务 UI','真实 Sportmaster.Desktop / ParcelFlow.Desktop WPF 程序集存在；未发现未选 DirectPlc/WcsToPlc 业务 DLL。'],
 ['三个离线包','reference.barcode 1.2.2、reference.parcel-capabilities 2.1.2、sportmaster.rcs-task 1.0.4；各 payload 长度/hash 符合其包清单；包清单声明的公共契约指纹与实际宿主匹配。均为 Simulation / test-only publisher。'],
 ['信任 / 安装边界','本轮未进行独立密码学验签，发布未附其本机独立 trust。两个 EXE 未嵌入 Authenticode。包在 ZIP 中不等于已安装、绑定、激活或拥有生产资格。'],
 ['发布与 main 闭包','release-main-closure.json 对 src/config/scripts/examples、根构建输入与全部随包 Parcel 指南检查为零差异；其余 74 路径差异属 docs/manifest/整合与证据。文档 SHA 变化不能自动判定产物过期。']
],[1.2,5.3])
h2('安装—使用—维护全路径审查')
tab(['环节','已有实现及值得保留之处','缺口 / 应在同一媒介上验证'],[
 ['干净机首次安装','ZIP + PowerShell 7：protect-release / provision-runtime / provision-extensions；受保护只读程序、独立 trust 与包库。[S17]','明确脚本顺序、离线 PS7 前置、运行账户和设备依赖。当前指南还需一份一致、可单独执行的首次安装 SOP；不机械要求 MSI。'],
 ['普通用户与维护提权','app.manifest asInvoker；机器策略固定运行 SID、lease 路径；维护 helper runas、ArgumentList、固定 working directory，结束后回读登记。[S15][S18]','验证 UAC 接受/拒绝、Program Files/ProgramData ACL、错误账户/跨会话、普通用户不可改程序/信任/包；维护能完成但日常不要求管理员。'],
 ['配置与数据定位','配置基于 AppContext.BaseDirectory/config；默认数据为 LocalApplicationData；配置、DB、raw、日志不写进程序发布目录。[S18]','从快捷方式/不同工作目录启动；实际客户选定路径、备份盘与 ACL。未发现自动创建快捷方式和完整修复/卸载 SOP。'],
 ['启动自检 / 故障入口','旧责任/配置/包/依赖验证、资源启动、健康探测后才准入；失败显示 NotReady MessageBox 并 exit2。[S06][S18]','当前不是能一直进入的故障维护壳，启动失败需 CLI/日志/文件维护。验证提示定位到可执行步骤，不能宣传任意故障均可从运行 UI 处置。'],
 ['设备独占 / 多实例','设备所有权、机器级 lease、指定运行账户及停止释放机制存在。[S18][S22]','实际 Windows 多用户/会话、崩溃后 lease 和真实 SDK 独占/句柄释放；不要求无依据的单一全局进程锁。'],
 ['参数编辑与生效','schema 参数和完整 schema3 JSON 可查看修改；校验/CAS/Pending/受控重启/成功确认存在，旧单 reader 表单不覆盖 schema3。[S13]','维护 UI 带较多工程参数、路径、hash 与 JSON；需用现场维护角色走通保存冲突、失败保旧、正确提示及原件屏障。不能误称“无法编辑参数”。'],
 ['升级 / 中断 / 回滚','版本组合、原包引用、备份/恢复/旧库 preflight 与未结原责任保护存在。[S08][S16][S19]','形成旧→新支持矩阵和离线序列；验证升级中断、待生效失败、修复安装、DB 不兼容回退、配置/原包/未结件保留。不要直接覆盖已有程序与旧账。'],
 ['卸载 / 保留数据','包卸载受 active/config/原件/备份消费者引用约束','完整产品卸载、账号变更、备份恢复与 Store 迁移/清偿退役尚缺清晰 SOP。卸载不能删除未清责任、凭据引用或客户历史。']
],[1.05,2.6,3.1])
story.append(PageBreak())
h2('HMI、故障和持续运行')
para('WPF 源码具备作业/历史/维护、左右位、登录可选、暂停恢复、原回执责任与检查处置入口；新 supply-station 关注双位隔离与时效，DirectPlc 完整 UI 延期按原决定保留。F04 是默认 classic 当前真实缺陷，不应与延期混同。最低尺寸/DIP 等代码约束不等于已通过目标分辨率/DPI/触控/HID、焦点、长字段、声音、多窗关闭和 Dispatcher 响应验证。[S12][S18][S26]')
para('工业运行基础包括有界队列、过载明确拒绝、健康有效期、关联 ID、容量检查、原件持久和完整停止释放。参考历史归档只缩小驻留内存，并不自动删除磁盘上所有历史。没有目标负载和持续观测，不能承诺延时、无限存储、长期无泄漏；应以每位响应/积压、共享 gate 等待、线程/句柄/内存、日志/DB/raw 增长及重连退出行为验证所选真实组合。[S06][S22][S24]')
para('诊断、原请求/回执与配置修订有可追溯身份，软件暂停有独立授权语义；软件暂停不是硬件安全停机。扩展 schema 支持 secret-reference，指南要求 credential:名称，UI PasswordBox 使用后清除；仍需在实际认证/HTTP/SDK 组合中验证凭据提供、日志及诊断导出脱敏、支持人员可读范围与离线处置。没有证据表明本轮已完成真实凭据/渗透或供应链漏洞专项审计。[S15][S16][S23]')
para('RuntimeJournal 有 256 项有界队列、约 5 MB 文件轮转和三代旧日志；日志失败/队满会关闭准入，权威业务事实仍在 SQLite。此策略需要在目标突发负载下证明不会因诊断路径不必要地停工，当前没有测量反例。本轮未找到 Parcel 专用的一键诊断包导出动作；现有身份、日志和原件可以取证，客户维护 SOP 应明确需要收集哪些文件、如何脱敏和验证完整性，一键按钮不是强制形式。[S30]')
h2('适用工程实践的边界')
para('微软官方文档说明 .NET 的 Windows 支持同时取决于 OS 与运行时支持状态；实际 win-x64 包必须对应客户确认的 Windows SKU/build，不能笼统承诺所有 Windows 10/11。Windows x64 进程不能直接加载 x86 DLL，因此 SDK 位数是实际接入约束。AssemblyLoadContext 是程序集加载/身份机制，不是恶意插件的安全或可靠性沙箱；现有受信包政策有必要。下列官方资料仅用于解释适用边界，不代表获得任何工业安全认证。')
para('SQLite WAL 面向同主机共享内存协调；客户若计划把业务 DB 放到网络共享，需要另行评估。备份应使用一致性机制并与原包/配置/未清回执一起形成可恢复组合；不能只复制正在写的单个 DB 文件。这些是交付方案评估条件，未把未知的客户网络盘计划当作当前代码缺陷。')

h1('10 按 Application 与交付组合的准入')
para('“通过”表示本表指定层级的必要项已满足；“有条件通过”只允许已列明的低风险参考范围；“不通过”表示存在确定缺陷或缺少不可替代的交付能力；“证据不足”表示相应环境/事实尚未直接验证。允许隔离复现与继续开发，不等于相关业务验收通过。所有商用判断绑定当前 1.2.4 / Contracts1.7.0 / Parcel DB6 及所列组合。')
tab(['Application / 组合','继续开发','参考软件实验室','真实设备完整联调','受控现场试点','指定场景商用'],[
 ['Sportmaster：基础双 reader → reference WCS，未启用受影响可选能力','通过','有条件通过','不通过（必要能力未交付）','不通过','不通过'],
 ['Sportmaster：actual RCS HTTP 适配 + 合成 peer / reader，无额外异步能力','通过','有条件通过（协议参考范围）','不通过（必要能力未交付）','不通过','不通过'],
 ['Sportmaster：双位实测称重组合','通过','不通过（隔离验收 F02；允许调试）','不通过当前组合验收','不通过','不通过'],
 ['Sportmaster：RCS + 已复现异步取图组合','通过','不通过（双位反序 F03）','不通过当前组合验收','不通过','不通过'],
 ['DirectPlc：启用本件实测称重','通过','不通过（完整业务 F01）','不通过可执行联调准入','不通过','不通过'],
 ['WcsToPlc：启用本件实测称重','通过','不通过（完整业务 F01）','不通过可执行联调准入','不通过','不通过'],
 ['DirectPlc / WcsToPlc：其他已允许的纯参考重量组合','通过','有条件通过（原参考路径范围）','不通过（必要能力未交付）','不通过','不通过']
],[2.5,0.65,1.5,1.6,0.75,0.75])
para('真实设备完整联调以当前交付实现为对象：必要真实 Driver/合同组合未交付，因此不通过；Windows/真实设备环境另外未验证。架构具备开展接入开发的条件已由“继续开发通过”表达。本表“现场试点”指实际接收客户实物并决定分拣/发送控制的运行；单独只读采集、回放或影子观察可作为后续研发步骤，但不能借其允许性宣称完整业务现场准入。即便某默认参考配置没有触发 F01，也不能把真实称重需求换成固定重量来取得商业通过。')
h2('各组合的通过项、阻断、可接受限制与待验证项')
tab(['组合','已通过项','阻断 / 可接受限制 / 待验证'],[
 ['所有三 Application 的继续开发','独立流程、无项目环、当前验证工程构建与三组参考运行；配置和持久恢复基础具备。','通过是工程可维护开发结论，不能沿用为现场批准。F01–F05 按工作包关闭；不要求全面重写或合并三业务。'],
 ['Sportmaster 基础参考软件链路','两个明确 reader/位、WCS 有效格口与结果、无 PLC、共享原件和配置保护。','条件：仅 Simulation、合成 peer/输入、不承担现场动作，记录 F04/F05，支持人员明知限制。真实准入阻断：G01/G03/G04；若选 RCS 再加 G02。无需额外要求展图或长期留图。'],
 ['Sportmaster 双秤 / RCS+取图','对应能力可绑定、原重量/原 ID 保留、错误时拒绝继续副作用。','当前功能验收阻断：F02 或 F03，不能把它们作为“可接受限制”继续承诺独立位。可在隔离环境复现、修复，不授予现场通过。'],
 ['DirectPlc / WcsToPlc 实测组合','主流程正确分立、重量按本件关联、PLC 接受与完成分开、原请求一次尝试。','阻断：F01；真实 reader/秤/PLC/WCS/身份/完成合同 G01/G04，以及 G03 和相应 Windows 发行包缺失。完整 DirectPlc UI 延期可接受于开发，不接受于未证明可操作的商业交付。'],
 ['其他允许的纯参考组合','现有 reference 运行和恢复在其原测项内有效。','只限合成实验室。不能从参考的 Quantity/slot/固定重量/物理完成默认推导真实合同；目标场景未确认时真实兼容仍是证据不足。'],
 ['实际 Sportmaster Windows ZIP','源—包闭包、hash/CRC、WPF/自包含运行时/三包元数据完整性核验通过。','Windows 安装/普通账户/UI/升级恢复证据不足；Simulation/test-only 不能 Production。待验证：目标 Windows 与实际设备合同完整链路。没有 MSI 或签名本身不单独判架构失败。'],
 ['旧 Supply / Inspection','保留与新业务隔离的兼容职责，离线只读消费者角色已静态核对。','本轮没有对旧产品完整工艺、Windows 环境和现场重新验收，商业条件为证据不足；不继承或撤销旧版本的原范围结论。']
],[1.55,2.15,3.4])
callout('本轮可授予的范围', '工程继续开发：通过。指定的纯参考软件链路：有条件通过。已复现缺陷组合的业务验收：不通过。Windows 实机可操作性：证据不足。当前 Simulation 媒介用于真实现场试点或指定场景商用：不通过。任何重新放行都应引用修复后的固定源、实际媒介 hash、配置/DB 版本和目标环境证据。')

h1('11 下一阶段工作包与复核标准')
para('先整理相关现行文档，再调整实现；保留原始要求、原失败、固定 SHA 和历史证据。本轮不执行下列变更。以下工作包以交付能力为目标，不要求全面重写、新增总线、通用工作流、强制 MSI、自动更新或额外治理平台。WP-00 完成后，WP-01/02/03 可按独立文件边界并行；真实组合和 Windows 交付必须汇合到同一不可变候选。')

h2('WP-A03-00 · 现行规范与首个交付组合定稿')
tab(['项目','工作包内容'],[
 ['目标 / 依赖','关闭 F05；形成客户、实现和维护人员都能引用的当前版本/能力/操作范围。输入本报告、原要求、INDEX 有效规范与实际 release；它先于实现修改。'],
 ['范围','整理当前架构、Application/拓扑、参数激活、扩展、恢复和 Windows 指南；明确 ABI1.7.0/DB6、普通升级与 custody 特准路径；单独列旧 Supply Storage5。确认一个首先交付的 Application/Windows/SDK/协议组合及重量/实体/负载/离线/保留/维护约束。'],
 ['迁移','保留原文/原 SHA/原 PASS/FAIL，可将历史说明链接回已有归档；不回写客户要求，不批量把旧报告更新成“已完成”。当前随包文档只能从已整理有效正文生成或复制。'],
 ['必要验证','逐条核对当前正文中的命令、默认值、版本、目录和失败恢复入口；对仍待确认项明确责任方/材料，不填 reference 值。用实际打包结果核对随包指南。'],
 ['可复核验收','一张准确的支持组合表；一份读者无需按十几个增量页推理的当前安装/配置/升级/恢复路径；现行有效文档中不再相互要求 ABI1.6/1.7 或 DB5/6；历史原件 hash 不变。']
],[1.05,5.65])

h2('WP-A03-01 · 输入身份冲突与独立位隔离')
tab(['项目','工作包内容'],[
 ['目标 / 依赖','关闭 F01 与 F02；依赖 WP-00 对原实体/新件准入和故障范围的明确正文。'],
 ['范围','调整现有 ObserveAsync 原身份处理顺序；把测量同 ID 不同内容变成现有持久冲突/审计的明确结果，按设备/位/实体隔离。复用已有 CanDispatch、IdentityConflict 和权限处置；不添加万能 manager。'],
 ['迁移','原条码、重量、T1 payload、已发结果和 Unknown 不重写。若现有表能承载则不为此强制升库；必要新增字段须版本化并可读旧资料。历史 ObservationBlocked 若未保存新矛盾正文，不能倒填伪造原事实。'],
 ['必要测试','两 PLC 应用 WaitingWeight 同 Admission 改码；同内容重复；提前不同实体；同码不同合法实体；右位在左测量冲突时继续；重启后冲突持久；共享存储故障仍全局关闭；停止最终释放资源。'],
 ['可复核验收','F01 两场景新冲突可追溯且 PLC attempts=0；未发 WCS/PLC 阶段不前进，已经发生的远端事实不撤销。F02 原重量不变、右位正常推进、局部冲突可授权核对；没有吞数据库异常或自动重发。交付新的固定源码与同反例结果。']
],[1.05,5.65])

h2('WP-A03-02 · RCS 持久 ID 与实际 T1 顺序一致')
tab(['项目','工作包内容'],[
 ['目标 / 依赖','关闭 F03，保持 ID 不重用和双位独立；依赖 WP-00 的 RCS ID 范围/目标/原请求说明。'],
 ['范围','将实际 T1 准备时的持久 ID 拥有/分配与业务入场序号分开；保持适配端纯准备和 wire body 冻结。选择最小可证明实现，不强制全局串行或重造调度器。'],
 ['迁移','识别现有 resident/archive/backup 中原数值 ID 和边界；新分配不能重用旧已准备或已发送 ID。必要分配记录采用明确 schema 版本与只读 preflight，旧业务原请求保持原 ID/原字节。'],
 ['必要测试','本轮左取图等待、右先 T1 的原反例；相反顺序；重启未发/已发；归档和恢复；范围耗尽与错误 base；既有原请求重放只回放本地结果，不新增 HTTP。'],
 ['可复核验收','两位均得到其自己的有效格口，每件唯一 ID、一次 POST；原分配持久可核验；任何范围或存储失败在外部副作用前明确阻断；不删除高水位/唯一性保护以获得表面 PASS。']
],[1.05,5.65])

h2('WP-A03-03 · 默认 HMI 的快照时效与操作提示')
tab(['项目','工作包内容'],[
 ['目标 / 依赖','关闭 F04，使 classic 和可选布局共享基本事实时效；依赖 WP-00 的 UI 状态含义。'],
 ['范围','共用 ViewModel 处理最后成功时间、读取挂起/异常/恢复、运行实例/revision 顺序；旧快照明确标旧并限制依赖其事实的动作。保留各布局视觉和同一业务实例；DirectPlc 完整 UI 的延期单列。'],
 ['迁移','不改业务 DB 或已存状态，不自动恢复运行；用户选择的布局参数保持兼容。任何 UI 简化仍通过 IParcelApplication，不能直连 Driver/DB。'],
 ['必要测试','本轮实际暂停后 snapshot 失败；读取挂起超过有效期；晚返回旧读；实例更换；恢复新快照；独立暂停路径和业务 CAS；在所选 Windows/DPI 实际点击。'],
 ['可复核验收','任何无有效新快照期间不得把 Ready/旧格口呈现为当前可靠事实；依赖事实的操作不可用或被明确拒绝；错误提示告诉操作员如何核对；恢复不会自动重发或解除业务责任。']
],[1.05,5.65])

h2('WP-A03-04 · 第一个真实设备 / 协议组合')
tab(['项目','工作包内容'],[
 ['目标 / 依赖','从 reference 走到一个精确且可重复的真实组合；依赖 WP-00 支持矩阵，动作相关路径先关闭 WP-01，RCS 可选反序组合先关闭 WP-02。'],
 ['范围','取得真实相机/reader SDK、设备协议与许可；实现最小必要 Driver/native 边界和真实 Admission 来源。接入所选 WCS/RCS/认证；若是 PLC 应用，明确地址/编码、接收/物理完成/复位与同件重量合同。RCS 必须补足权威 Unknown 处置合同和可执行入口。'],
 ['迁移','新真实包不冒用 reference 包/实例/资格；独立签名与受保护依赖，精确更新 compatibility。旧配置和未结原件保持原目标/原实现，先清偿或使用已定义原包恢复，不能原地把 Simulation 改成 Production。'],
 ['必要测试','SDK 位数与首次加载；设备通讯；断连/旧回调/重连/停止；左右独立实体与同码；真实服务超时/重复/错回执；提交已接受但本地保存失败；Query 或批准的人工证据闭环；实际 PLC 完成与重启实物核对。'],
 ['可复核验收','同一包/配置/DB/Windows/SDK/设备标识的完整证据；从现场传感/扫码到主业务结果每个身份可追溯；异常没有错控、丢失责任、重复副作用或无依据清除；Unknown 处置由真实协议方/客户确认。Production 资格来自这套独立证据。']
],[1.05,5.65])

h2('WP-A03-05 · Windows 安装、升级与操作闭环')
tab(['项目','工作包内容'],[
 ['目标 / 依赖','形成客户能安装、操作、维护和恢复的不可变 Windows 媒介；依赖 WP-00 与 WP-03，真实设备通过需汇合 WP-04。'],
 ['范围','按所选业务构建实际 win-x64 包（DirectPlc/WcsToPlc 需要自己的包）；明确 PS7/厂商运行库、脚本顺序、SID、目录/ACL、快捷方式和离线信任；完善安装、升级、中断、回退、修复、卸载保留数据 SOP；按场景完成必要 HMI。'],
 ['迁移','程序版本目录与运行数据分离；版本切换和 DB 回退按支持矩阵；configuration Pending 失败保旧；原包、raw、备份和未清责任完整保留。旧 Supply 数据只用自己的迁移链。'],
 ['必要测试','干净目标机普通账户首次安装/启动；UAC 同意/拒绝与错误 SID；不同 cwd/快捷方式；多会话/独占；无 SDK/配置无效/DB 不可写/磁盘不足；升级关键点中断与恢复；目标分辨率/DPI/焦点/触控/声音/关闭。'],
 ['可复核验收','每条操作以真实窗口/日志/文件/DB/配置读回作证，且全部引用同一 ZIP SHA256。常见失败能由指定维护角色按随包 SOP 恢复，日常作业不依赖管理员；没有以交叉构建或 PNG 原型替代 Windows 证据。']
],[1.05,5.65])

h2('WP-A03-06 · 目标负载、现场试点与商业支持')
tab(['项目','工作包内容'],[
 ['目标 / 依赖','验证已确认的负载和故障可恢复性，形成按组合的试点/商业准入；依赖 WP-01–05 对所选场景完成。'],
 ['范围','定义正常/突发/离线/保留时长与维护窗口；观测每位延时、隔离、积压、资源、磁盘和日志；明确备份验证、Store 容量/退役、依赖维护、分发信任/许可和客户支持交接。以真实风险确定验证时长，不机械要求固定若干天。'],
 ['迁移','试点版本、配置、DB、设备/SDK 和合同版本全部锁定；暂停/回退和原件人工核对步骤先准备；历史数据/凭据不随卸载丢失。只在客户授权下运行现场，审查本身不操作生产。'],
 ['必要测试','目标满载与合理突发；一位设备故障时另一位表现；长响应/网络断连、进程退出和受控断电恢复；低磁盘/DB 失败；多次重连/停止；按真实保留期估算并核验磁盘增长、备份可恢复。'],
 ['可复核验收','没有未关闭的错控、丢件责任、重复副作用或无法恢复关键风险；资源与磁盘趋势满足已确认阈值；故障提示/诊断/恢复 SOP 实际可执行；版本追踪、已知限制、维护责任与厂商再分发依据齐全。逐组合给准入，不写笼统“工业级认证通过”。']
],[1.05,5.65])
para('可以延后的事项：全量目录/命名重整、第四业务预造框架、任意热插拔、全品牌 SDK 平台、自动更新、统一插件子进程化与无目标的超长压力工程。可以在相关扩展发生时做的小范围收敛：业务离线纯语义、页面声明、参考 schema 事实源和已验 metadata 缓存。优先使既定业务在真实 Windows 工控机上可交付、可核对、可恢复。')

h1('12 审查证据与复现说明')
h2('证据包内容与解释')
tab(['目录 / 文件','用途和限制'],[
 ['baseline.json / environment/','完整 SHA、git reflog、只读工作树状态、Ubuntu 与 .NET 环境。基线时间和提交时间分开记录。'],
 ['original-verification/','当前源码锁定恢复/构建、三组既有验证原始日志。原 PASS 只支持原组检查范围。'],
 ['probes/business/','F01 两业务、F02 双位测量的最小外部探针源码、构建日志、最终运行和完整快照 JSON。'],
 ['probes/rcs-order/','F03 实际 RCS 客户端与合成 HTTP peer，左取图等待导致 T1 反序；源码、日志和完整结果。'],
 ['probes/classic-ui/','F04 原 ViewModel/Runtime，注入 Snapshot IOException；无原生 WPF 运行。'],
 ['probes/referenced-dlls.json','当前探针实际引用 DLL 的身份/hash；证据包不复制运行时或构建二进制。'],
 ['setup-not-product-failures/','业务探针初次缺 SQLite 原生解析路径、第二次合成配置缺角色镜像，以及 RCS 首次 sandbox loopback 拒绝，均明确非产品失败；纠正环境/夹具后才取得目标证据。'],
 ['release-artifacts/','实际下载包核验、内层清单、版本闭包、公开页面元数据、ARTIFACTS、随包当前指南和三个包 manifest。没有把未下载资产标记成本轮实测。'],
 ['static-analysis/ / source-index.json / source-excerpts.txt','项目引用图与环检测、F05 原行、所有正文固定 SHA 精确来源。源码摘录是审查证据，完整源可在固定提交检索。'],
 ['review-notes/ / report-source/','三路独立审查原笔记、报告生成源/内容记录。原笔记中的相对任务编号由 evidence-summary 映射为 F01–F05。'],
 ['README.txt / evidence-summary.json / SHA256SUMS','范围、命令、探针和验证状态区别；原文件复制清单与最终证据每文件 hash。没有 SDK/NuGet/cache/bin/obj、整个仓库或 104 MB 发布 ZIP。']
],[1.8,4.7])
para('本次已执行的主验证命令：dotnet restore tests/Ipc.Application.Verification/Ipc.Application.Verification.csproj --locked-mode；dotnet build 同一项目 -c Release --no-restore -m:1 -nr:false；执行 Release/net10.0/Ipc.Application.Verification.dll . 后分别加 --application-architecture、--parcel-recovery-p2、--sportmaster-rcs。实际环境变量与日志见证据 README。没有向现有测试添加用例或反向修改代码使其通过。')
para('探针通过独立工程引用本轮原 Release DLL。业务探针需要正确 SQLite native resolver；RCS 需要本机 loopback socket 权限；VM 探针引用测试编译的表示模型而不启动 Windows。迁移到另一审查机器时，只替换 scratch 根路径、按固定 SHA 重建并校验引用身份；不能把探针中的合成输入/凭据/地址搬到生产。独立复现的 exit 0 表示反例被成功确认。')
h2('实际发布资产索引')
relurl='https://github.com/yuan2go/importer-pc/releases/tag/reference-reconciliation-20261019-21e6cae'
story.append(Paragraph('<link href="'+relurl+'" color="#176676">Reference reconciliation 1.2.4 · 固定预发布页面</link>',sty['body']))
for name in ['sportmaster-selected-win-x64.zip','direct-plc-core.zip','wcs-to-plc-core.zip','sportmaster-core.zip','sportmaster-selected-portable.zip']:
 artifact=next(x for x in json.loads((WORK/'windows/release-artifact-table.json').read_text()) if x['File']==name)
 para(name+' — '+str(artifact['Bytes'])+' bytes — '+('本轮下载实测' if artifact['ThisAuditDownloadVerified'] else '发布清单/已有证据；本轮未重新下载')+'\nSHA256 '+artifact['RecordedSha256'],'small')
para('ARTIFACTS.json 实测 SHA256=f813d2f85c5d047811885d11c29274024008e893e3153229eb925112495f3a5a。发布清单 hash 证明特定字节身份，不自动证明发布者信任；信任/签名、现场验收和可商用均分别判断。','small')

h1('附录 A · 固定 SHA 精确源码索引')
para('以下全部仓库引用固定为 '+SHA+'。每个路径均提供可点击永久链接；精确摘录及有效行范围同步存入 source-index.json / source-excerpts.txt。长文件按相关范围节选；历史报告只用于对应版本的事实与证据边界。','small')
source_index=[]; excerpts=[]
for sid,(title,entries) in sorted(sources.items()):
 story.append(Paragraph('<a name="src-'+sid+'"/>'+esc(sid+' · '+title),sty['h2']))
 for path,start,end in entries:
  fp=REPO/path
  lines=fp.read_text(encoding='utf-8-sig').splitlines()
  end=min(end,len(lines))
  if start>end: raise ValueError((sid,path,start,end))
  url=BASE+path+'#L'+str(start)+'-L'+str(end)
  label=path+':'+str(start)+'–'+str(end)
  story.append(Paragraph('<link href="'+html.escape(url,quote=True)+'" color="#176676">'+esc(label)+'</link>',sty['small']))
  source_index.append({'id':sid,'topic':title,'path':path,'start_line':start,'end_line':end,'sha':SHA,'url':url,'source_sha256':hashlib.sha256(fp.read_bytes()).hexdigest()})
  excerpts.append(sid+' '+title+'\n'+url+'\n'+'\n'.join(f'{i}: {lines[i-1]}' for i in range(start,end+1))+'\n')

h1('附录 B · 官方技术依据与适用性')
external=[
 ('Microsoft · Install .NET on Windows','https://learn.microsoft.com/en-us/dotnet/core/install/windows','用于 Windows / .NET 支持组合判断。必须核对具体 SKU/build 和当前运行时支持条件；本报告不承诺未确认的 OS 范围。'),
 ('Microsoft · .NET support policy','https://dotnet.microsoft.com/en-us/platform/support/policy/dotnet-core','用于 .NET 10 支持与维护政策边界；自包含部署仍需要明确运行时更新责任。'),
 ('Microsoft · Create a .NET application with plugins','https://learn.microsoft.com/en-us/dotnet/core/tutorials/creating-app-with-plugin-support','用于 AssemblyLoadContext 的加载边界判断。程序集隔离不等于不受信代码的安全/可靠性沙箱。'),
 ('Microsoft · Process Interoperability','https://learn.microsoft.com/en-us/windows/win32/winprog64/process-interoperability','用于解释 x64 进程不能直接加载 x86 DLL；实际 SDK 位数、驱动和桥接需求必须先确认。'),
 ('SQLite · Write-Ahead Logging','https://www.sqlite.org/wal.html','用于 WAL 的同主机条件与并发边界；不是对客户尚未确认的网络盘方案作预判。'),
 ('SQLite · Online Backup API','https://www.sqlite.org/backup.html','用于一致性备份的原则；还必须把本项目配置、原包、raw 和未清责任纳入实际恢复流程。'),
]
for title,url,scope in external:
 h2(title)
 story.append(Paragraph('<link href="'+url+'" color="#176676">'+esc(url)+'</link>',sty['small']))
 para(scope)
para('检索日期：2026-10-19。以上为官方技术资料的适用边界，不是 IEC/ISO/功能安全/网络安全认证声明。安全控制、可信分发、许可和客户 SLA 均须按实际合同及系统边界确定。')

class AuditDoc(BaseDocTemplate):
 def afterFlowable(self,flowable):
  if isinstance(flowable,Paragraph) and flowable.style.name=='h1':
   text=flowable.getPlainText()
   if text=='阅读导航': return
   key='section-'+hashlib.sha1(text.encode()).hexdigest()[:12]
   self.canv.bookmarkPage(key)
   self.canv.addOutlineEntry(text,key,level=0,closed=False)
   self.notify('TOCEntry',(0,text,self.page,key))

def page(c,doc):
 c.saveState()
 if doc.page>1:
  c.setStrokeColor(colors.HexColor('#C9D7DD'));c.setLineWidth(.5);c.line(M,H-34,W-M,H-34)
  c.setFont('NotoSC',7.2);c.setFillColor(GREY)
  c.drawString(M,H-26,'WP-IPC-COMMERCIAL-QUALITY-AUDIT-03')
  c.drawRightString(W-M,H-26,'独立审查 · yuan2go/importer-pc')
 c.setStrokeColor(colors.HexColor('#C9D7DD'));c.line(M,33,W-M,33)
 c.setFont('NotoSC',7);c.setFillColor(GREY)
 c.drawString(M,21,'固定源 '+SHA[:12]+' · 只读审查 · 2026-10-19')
 c.drawRightString(W-M,21,str(doc.page))
 c.restoreState()

def main():
 OUT.parent.mkdir(parents=True,exist_ok=True)
 ev=WORK/'evidence';ev.mkdir(exist_ok=True)
 (ev/'source-index.json').write_text(json.dumps(source_index,ensure_ascii=False,indent=2)+'\n')
 (ev/'source-excerpts.txt').write_text('\n'.join(excerpts))
 (ev/'report-source').mkdir(exist_ok=True)
 (ev/'report-source/report-content.json').write_text(json.dumps(content,ensure_ascii=False,indent=2)+'\n')
 doc=AuditDoc(str(OUT),pagesize=A4,leftMargin=M,rightMargin=M,topMargin=49,bottomMargin=46,title='WP-IPC-COMMERCIAL-QUALITY-AUDIT-03 · Windows 工业客户端独立架构与交付审查',author='Independent audit',subject='yuan2go/importer-pc · '+SHA)
 frame=Frame(M,46,CW,H-95,id='normal',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
 doc.addPageTemplates(PageTemplate(id='audit',frames=frame,onPage=page))
 doc.multiBuild(story)
 print(json.dumps({'pdf':str(OUT),'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'sources':len(source_index),'content_blocks':len(content)},ensure_ascii=False))

if __name__=='__main__': main()
